<?php
require_once $_SERVER['DOCUMENT_ROOT']."/vendor/autoload.php";
?>
<!DOCTYPE html>
<html lang="ko">
<head>
    <?php require_once $ROOT_PATH_.'/assets/include/head.php'; ?>
</head>
<body id="main">

<article class="global-wrap">
    <?php require_once $ROOT_PATH_.'/assets/include/gnb.php'; ?>
    <nav class="lnb">
        <ul>
            <li><a href="#ideaContest" data-idx="0"><span class="sr-only">Idea Contest</span></a></li>
            <li><a href="#mission" data-idx="1"><span class="sr-only">Mission</span></a></li>
            <li><a href="#aboutTheContest" data-idx="2"><span class="sr-only">About The Contest</span></a></li>
        </ul>
    </nav>

    <div class="bg">
        <div class="idea-contest"></div>
        <div class="mission"><span></span></div>
        <div class="about-the-contest"><span></span></div>
    </div>

    <div class="swiper-container">
        <div class="swiper-wrapper">
            <div class="swiper-slide idea-contest">
                <section id="ideaContest">
                    <a href="#">
                        <img src="/assets/images/main/btn_idea_contest.png" alt="TV CF VIEW">
                    </a>
                </section>
            </div>
            <div class="swiper-slide mission">
                <section id="mission">
                    <p>
                        <img src="/assets/images/main/p_mission.png" alt="">
                    </p>
                    <a href="/about/application.php">
                        <img src="/assets/images/main/btn_mission.png" alt="orientation">
                    </a>
                </section>
            </div>
            <div class="swiper-slide about-the-contest">
                <section id="aboutTheContest">
                    <p>
                        <img src="/assets/images/main/p_about_the_contest.png" alt="">
                    </p>
                    <a href="/about/application.php">
                        <img src="/assets/images/main/btn_about_the_contest.png" alt="SCHEDULE VIEW">
                    </a>
                </section>
            </div>
        </div>

        <div class="swiper-button-prev"></div>
        <div class="swiper-button-next"></div>
    </div>

    <aside id="main-movie" class="modal modal-movie" tabindex="-1" role="dialog">
        <div class="modal-backdrop"></div>
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <h2 class="title">
                    <span>
                        SK이노베이션 Big Picture of Innovation 60”
                    </span>
                </h2>

                <div class="movie-wrap">
                    <div class="movie"></div>
                    <div class="prevnext">
                        <button type="button" class="prev">
                            <span class="sr-only">이전</span>
                        </button>
                        <button type="button" class="next">
                            <span class="sr-only">다음</span>
                        </button>
                    </div>
                    <div class="sns">
                        <h3>TV/CF Share</h3>
                        <ul>
                            <li>
                                <a href="#" class="facebook" data-sns="facebook">
                                    <span class="sr-only">facebook</span>
                                </a>
                            </li>
                            <li>
                                <a href="#" class="twitter" data-sns="twitter">
                                    <span class="sr-only">twitter</span>
                                </a>
                            </li>
                            <li>
                                <a href="#" class="copyurl" data-sns="copyurl">
                                    <span class="sr-only">copyurl</span>
                                </a>
                            </li>
                        </ul>
                    </div>
                    <div class="list">
                        <ul>
                            <li>
                                <a href="https://youtu.be/cnjNYiaT6S8">
                                    <img src="http://img.youtube.com/vi/cnjNYiaT6S8/mqdefault.jpg" alt="">
                                    <span>60"Ver</span>
                                </a>
                            </li>

                        </ul>
                    </div>
                </div>

                <div class="modal-close" aria-label="close">
                    <a href="#">
                        <span class="sr-only">닫기</span>
                    </a>
                </div>
            </div>
        </div>
    </aside>
    <?php require_once $ROOT_PATH_.'/sitemanager/assets/include/footer.php'; ?>
</article>
</body>
</php>
