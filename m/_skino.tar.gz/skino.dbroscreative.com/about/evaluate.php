<?php
require_once $_SERVER['DOCUMENT_ROOT']."/vendor/autoload.php";
?>
<!DOCTYPE html>
<html lang="ko">
<head>
    <?php require_once $ROOT_PATH_.'/assets/include/head.php'; ?>
</head>
<body id="about-evaluate">
<article class="global-wrap">
    <?php require_once $ROOT_PATH_.'/assets/include/gnb.php'; ?>
    <div class="global-container">
        <div class="global-content">
            <div class="content-header">
                <h2 class="title">
                    <img src="/assets/images/about/h_about.png" alt="about the contest">
                </h2>
                <nav class="lnb">
                    <ul>
                        <li class="application">
                            <a href="/about/application.php">
                                모집요강
                            </a>
                        </li>
                        <li class="evaluate">
                            <a href="/about/evaluate.php">
                                심사 및 시상안내
                            </a>
                        </li>
                    </ul>
                </nav>
            </div>
            <section class="board-view">
                <div class="date">2016.05.14</div>
                <div class="content">
                    <h3>NOTICE</h3>
                    <h4>제63기 정기주주총회 소집통지</h4>
                    <strong>2016년3월25일(금요일)오전9시</strong>
                    <p>
                        5. 경영참고사항 등 비치
                        상법 제542조의4에 의거하여 경영참고사항 등은 당사의 인터넷 홈페이지(www.hitejinro.com) 및 금융위원회, 한국거래소에 전자공시
                        되어 있으며, 당사의 본사,  ㈜하나은행 증권대행부에 비치하오니 참조하시기 바랍니다.
                    </p>
                    <p>
                        6. 실질주주의 의결권 행사에 관한 사항
                        가. 증권회사 계좌를 통하여 주식을 소유하고 있는 실질주주께서는 아래의 ‘의사표시통지서’에 의해 우편 또는 팩스의 방법으로
                        주주총회일 5일전까지 통지하여 주시기 바랍니다.
                        나. 의사표시 통지서를 송부하지 않은 주식에 대해서는 ‘자본시장과 금융투자업에 관한 법률 제18조’에 따라 동법의 종전규정 제314조
                        제5항에 의거하여 한국 예탁결제원에 의결권 행사를 요청할 예정입니다. 이 경우 한국예탁결제원은 동법 시행령의 종전규정
                        제317조 제1항에 의거하여 한국예탁결제원을 제외한 참석주 식수의 찬반 비율에 따라 Shadow Voting 방식으로 의결권을 행사합니다.
                    </p>
                    <div class="sns">
                        <a href="#" class="twitter">twitter</a>
                        <a href="#" class="facebook">facebook</a>
                    </div>
                </div>
            </section>
            <div class="board-bottom">
                <nav class="page-control">
                    <a href="#" class="prev">이전 글</a>
                    <a href="#" class="next">다음 글</a>
                </nav>
                <a href="notice-list.php" class="btn-list"><img src="/assets/images/board/btn_board_list.gif" alt="목록가기"></a>
            </div>
        </div>
    </div>
    <?php require_once $ROOT_PATH_.'/sitemanager/assets/include/footer.php'; ?>
</article>
</body>
</html>
