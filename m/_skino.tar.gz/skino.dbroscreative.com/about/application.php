<?php
require_once $_SERVER['DOCUMENT_ROOT']."/vendor/autoload.php";
?>
<!DOCTYPE html>
<html lang="ko">
<head>
    <?php require_once $ROOT_PATH_.'/assets/include/head.php'; ?>
</head>
<body id="about-application">
<article class="global-wrap">
    <?php require_once $ROOT_PATH_.'/assets/include/gnb.php'; ?>
    <div class="global-container">
        <div class="global-content">
            <div class="content-header">
                <h2 class="title">
                    <img src="/assets/images/about/h_about.png" alt="about the contest">
                </h2>
                <nav class="lnb">
                    <ul>
                        <li class="application">
                            <a href="/about/application.php">
                                모집요강
                            </a>
                        </li>
                        <li class="evaluate">
                            <a href="/about/evaluate.php">
                                심사 및 시상안내
                            </a>
                        </li>
                    </ul>
                </nav>
            </div>
            <section class="contest-wrap">
                <div class="cont-area">
                    <ul>
                        <li class="area-1">
                            <h3>공모대상</h3>
                            <div>
                                <strong>대한민국 청년 개인 또는 팀</strong>
                                <p>
                                    4인 이내, 팀으로 응모할 경우 온라인 접수
                                    및 출품을 위해 팀원 중 1인을 팀장으로 지정하여 진행
                                </p>
                            </div>
                            <div class="txt-wrap">
                                <p>- 군복무자도 공모가능</p>
                                <p>- 광고업계 종사자, 외국인 공모 불가</p>
                                <p class="txt">
                                    광고업계 종사자란, 한국광고총연합회
                                    에서 발간하는 광고인명록에 등록된 광
                                    고회사, 전문서비스회사등 관련 회사 및
                                    회원 단체에 속해있는 사람
                                </p>
                            </div>
                        </li>
                        <li class="area-2">
                            <h3>공모주제</h3>
                            <div>
                                <strong>에너지 화학 회사인 SK이노베이션을 알리기 위한 Big Picture Campaign</strong>
                                <p>1차 (Big Picture of Innovation X 김정기),</p>
                                <p>2차 (FACT-IM PACT X Garip Ay)를 이어나갈,</p>
                                <p>3차 캠페인 영상 아이디어</p>
                                </p>
                            </div>
                            <div class="txt-wrap">
                                <p>- 군복무자도 공모가능</p>
                                <p>- 광고업계 종사자, 외국인 공모 불가</p>
                                <p class="txt">
                                    광고업계 종사자란, 한국광고총연합회
                                    에서 발간하는 광고인명록에 등록된 광
                                    고회사, 전문서비스회사등 관련 회사 및
                                    회원 단체에 속해있는 사람
                                </p>
                            </div>
                        </li>
                        <li class="area-3">
                            <h3>제출방법</h3>
                            <div>
                                <strong>대한민국 청년 개인 또는 팀</strong>
                                <p>
                                    4인 이내, 팀으로 응모할 경우 온라인 접수
                                    및 출품을 위해 팀원 중 1인을 팀장으로 지정하여 진행
                                </p>
                            </div>
                            <div class="txt-wrap">
                                <p>- 군복무자도 공모가능</p>
                                <p>- 광고업계 종사자, 외국인 공모 불가</p>
                                <p class="txt">
                                    광고업계 종사자란, 한국광고총연합회
                                    에서 발간하는 광고인명록에 등록된 광
                                    고회사, 전문서비스회사등 관련 회사 및
                                    회원 단체에 속해있는 사람
                                </p>
                            </div>
                        </li>
                    </ul>
                </div>
            </section>
            <nav class="pagination">
                <ul>
                    <li>
                        <a href="#" class="bu prev">
                            <span>이전</span>
                        </a>
                    </li>
                    <li>
                        <strong>
                            1
                        </strong>
                    </li>
                    <li>
                        <a href="#">
                            2
                        </a>
                    </li>
                    <li>
                        <a href="#">
                            3
                        </a>
                    </li>
                    <li>
                        <a href="#">
                            4
                        </a>
                    </li>
                    <li>
                        <a href="#">
                            5
                        </a>
                    </li>
                    <li>
                        <a href="#" class="bu next">
                            <span>다음</span>
                        </a>
                    </li>
                </ul>
            </nav>
        </div>
    </div>
    <?php require_once $ROOT_PATH_.'/sitemanager/assets/include/footer.php'; ?>
</article>
</body>
</html>
