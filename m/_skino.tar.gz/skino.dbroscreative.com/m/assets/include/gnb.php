<div class="inner">
    <header class="global-header">
        <div class="global-header-inner">
            <h1 class="logo">
                <a href="/">
                    <span class="sr-only">SK innovation</span>
                </a>
            </h1>

            <button type="button" class="gnb-menu">
                <span class="sr-only">메뉴</span>
            </button>
        </div>
    </header>
    <h2 class="title">
        <img src="/m/assets/images/board/h_board.png" alt="Board">
    </h2>
</div>
