<div class="content-header">
    <nav class="lnb">
        <ul>
            <li class="notice">
                <a href="/m/board/notice-list.php">
                    NOTICE
                </a>
            </li>
            <li class="faq">
                <a href="/m/board/faq.php">
                    FAQ
                </a>
            </li>
            <li class="qna">
                <a href="/m/board/qna-list.php">
                    Q&amp;A
                </a>
            </li>
        </ul>
    </nav>
</div>
