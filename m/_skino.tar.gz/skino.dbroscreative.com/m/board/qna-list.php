<?php
/* =============================================================================
'   작 성 자 : DEV GROUP - JUHYUN
'   날    짜 : 2017-05-08
'   용    도 : 프론트 > Q&A 게시판 리스트 (list-qna.php)
'   Copyright 2017, Group IDD. All rights are reserved
' =============================================================================*/
require_once $_SERVER['DOCUMENT_ROOT']."/vendor/autoload.php";

use \Groupidd\Model\ModelBase;
use \Groupidd\Common\CommonFunc;
use \Groupidd\Library\Validator;

$pageNo     = isset($_GET['page']) && $_GET['page'] != '' ? $_GET['page'] : 1;

$db = new ModelBase();

$db->from('BOARD');
$db->where('board_type', 'qna');
$db->where('del_date', NULL, 'IS');

$countList = $db->getCountAll();    // 전체 게시물 수
$db->init();

// paging
$perPage = 7;      // 한 페이지에 보여질 리스트 수
$pageSize	= intval($countList/$perPage);
if($pageSize * $perPage != $countList) $pageSize = $pageSize+1;
$currentPage = $pageNo == 1 ? 0 : ($pageNo*$perPage)-$perPage;

$db->select('seq, title, reg_name, comment, reg_date');
$db->from('BOARD');
$db->where('board_type', 'qna');
$db->where('del_date', NULL, 'IS');
$db->orderby('seq', 'DESC');
$db->limit($perPage, $currentPage );
$boardList = $db->getAll();
$db->close();
?>
<!DOCTYPE html>
<html lang="ko">
<head>
    <?php require_once $ROOT_PATH_.'/m/assets/include/head.php'; ?>
</head>
<body id="board-qna-list">
<article class="global-wrap">
    <?php require_once $ROOT_PATH_.'/m/assets/include/gnb.php'; ?>
    <div class="global-container">
        <div class="global-content">
            <?php require_once $ROOT_PATH_.'/m/assets/include/gnb-board.php'; ?>
            <section class="board-list">
                <table class="table">
				    <caption>Q&A 리스트</caption>
    				<tbody>
                        <?php
                        foreach($boardList as $row ) {
                        ?>
                        <tr>
                            <td class="content">
                                <a href="/m/board/qna-view.php?seq=<?=$row['seq']?>" class="link">
                                    <?=$row['comment'] == null ? '<span class="icon standby">대기중</span>' : '<span class="icon complete">답변완료</span>'?>
                                    <p class="cont"><?=CommonFunc::cutUtf8Str($row['title'], 50, '...')?></p>
                                    <div class="q-date"><?=substr($row['reg_date'], 0, 10)?><br><?=$row['reg_name']?></div>
                                </a>
                            </td>
                        </tr>
                        <?php
                        }
                        ?>
                    </tbody>
                </table>
            </section>
            <div class="board-bottom">
                <?=CommonFunc::getPaging($pageNo, $perPage, $pageSize, '')?>
                <div class="group-button">
                    <a href="/m/board/qna-write.php" class="write"><span>질문 작성</span></a>
                </div>
            </div>
        </div>
    </div>
    <?php require_once $ROOT_PATH_.'/m/assets/include/footer.php'; ?>
</article>
</body>
</html>
