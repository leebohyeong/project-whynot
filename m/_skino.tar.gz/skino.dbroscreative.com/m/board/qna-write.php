<?php
/* ==============================================================================
'   작 성 자 : DEV GROUP - JUHYUN
'   날    짜 : 2017-05-08
'   용    도 : 프론트 > Q&A 게시물 쓰기 (write-qna.php)
'   Copyright 2017, Group IDD. All rights are reserved
' =============================================================================== */
require_once $_SERVER['DOCUMENT_ROOT']."/vendor/autoload.php";

use \Groupidd\Model\ModelBase;
use \Groupidd\Common\CommonFunc;
use \Groupidd\Library\Validator;

$pageNo     = isset($_GET['page']) && $_GET['page'] != '' ? $_GET['page'] : 1;

?>
<!DOCTYPE html>
<html lang="ko">
<head>
    <?php require_once $ROOT_PATH_.'/m/assets/include/head.php'; ?>
</head>
<body id="board-qna-write">
<article class="global-wrap">
    <?php require_once $ROOT_PATH_.'/m/assets/include/gnb.php'; ?>
    <div class="global-container">
        <div class="global-content">
            <?php require_once $ROOT_PATH_.'/m/assets/include/gnb-board.php'; ?>
            <form id="form_qna_write" method="post" action="/board/write-proc.php">
            <section class="board-write">
                <dl class="list-write">
                    <dt>
                        <label for="title">제목</label>
                    </dt>
                    <dd>
                        <input type="text" name="title" value="" maxlength="50">
                    </dd>
                    <dt>
                        <label for="writer">작성자</label>
                    </dt>
                    <dd>
                        <input type="text" name="reg_name" value="" maxlength="10">
                    </dd>
                    <dt>
                        <label for="desc">문의 내용</label>
                    </dt>
                    <dd>
                        <textarea name="content" rows="11"></textarea>
                    </dd>
                </dl>
            </section>
            </form>
            <div class="board-bottom">
                <div class="group-button">
                    <a href="javascript:;" class="cancel"><span>취소</span></a>
                    <a href="javascript:;" class="write"><span>질문 작성</span></a>
                </div>
            </div>
        </div>
    </div>
    <?php require_once $ROOT_PATH_.'/m/assets/include/footer.php'; ?>
</article>
<script>
$(function() {

    var isValid = function () {
        if (!$.trim($('[name=title]').val())) {
            alert('제목을 입력해 주세요');
            $('[name=title]').focus();
            return false;
        }

        if (!$.trim($('[name=reg_name]').val())) {
            alert('작성자를 입력해 주세요');
            $('[name=reg_name]').focus();
            return false;
        }

        if (!$.trim($('[name=content]').val())) {
            alert('내용을 입력해 주세요');
            $('[name=content]').focus();
            return false;
        }
        return true;
    }

    $('.group-button a:first').on('click', function () {
        if(confirm('글 작성을 취소하시겠습니까?')) {
            location.href = "/m/board/qna-list.php?page=<?=$pageNo?>";
        }
        return;
    })

    // 폼 등록
    $('.group-button a:last').on('click', function () {
        var form = $('#form_qna_write');
        if (isValid()) {
            if (confirm('등록 하시겠습니까?')){
                $.ajax({
                    async: false,
                    type: form.attr('method'),
                    url: form.attr('action'),
                    dataType: "json",
                    data:  form.serialize(),
                    success: function (res) {
                        // 성공시
                        alert( res.msg );
                        if(res.result){
                            window.location = '/m/board/qna-list.php';
                        }
                    },
                    error: function (jqXHR, textStatus, errorThrown) {
                        console.log('Q&A 글 작성 폼 전송 에러');
                    }
                });
            }
        }
        return false;
    })
})

</script>
</body>
</html>
