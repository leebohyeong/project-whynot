<?php
/* =============================================================================
'   작 성 자 : DEV GROUP - JUHYUN
'   날    짜 : 2017-05-08
'   용    도 : 프론트 > 공지사항 게시판 리스트 (list-notice.php)
'   Copyright 2017, Group IDD. All rights are reserved
' =============================================================================*/
require_once $_SERVER['DOCUMENT_ROOT']."/vendor/autoload.php";

use \Groupidd\Model\ModelBase;
use \Groupidd\Common\CommonFunc;
use \Groupidd\Library\Validator;

?>
<!DOCTYPE html>
<html lang="ko">
<head>
    <?php require_once $ROOT_PATH_.'/m/assets/include/head.php'; ?>
</head>
<body id="board-faq">
<article class="global-wrap">
    <?php require_once $ROOT_PATH_.'/m/assets/include/gnb.php'; ?>
    <div class="global-container">
        <div class="global-content">
            <?php require_once $ROOT_PATH_.'/m/assets/include/gnb-board.php'; ?>
            <section class="faq-list">
                <dl>
                    <dt>
                        <a href="#">
                            <span>Q.</span>
                            한 팀(사람)이 여러 작품을 내도 되나요?
                        </a>
                    </dt>
                    <dd class="cont">
                        <span>A.</span>
                        <p>한 팀(사람)이 출품할 수 있는 작품의 수는 제한이 없으며,
                        팀 구성원은 최소 1명에서 최대 4명까지 가능합니다.
                        한 명이 복수의 팀으로 참가하는 것은 불가능 합니다</p>
                    </dd>
                    <dt>
                        <a href="#">
                            <span>Q.</span>
                            접수번호/비밀번호를 분실하였습니다.
                        </a>
                    </dt>
                    <dd class="cont">
                        <span>A.</span>
                        <p>한 팀(사람)이 출품할 수 있는 작품의 수는 제한이 없으며,
                        팀 구성원은 최소 1명에서 최대 4명까지 가능합니다.
                        한 명이 복수의 팀으로 참가하는 것은 불가능 합니다</p>
                    </dd>
                    <dt>
                        <a href="#">
                            <span>Q.</span>
                            접수 신청이 끝난 후 주소나 전화번호 등의 접수 신청이 끝난 후 주소나 전화번호 등의
                        </a>
                    </dt>
                    <dd class="cont">
                        <span>A.</span>
                        <p>한 팀(사람)이 출품할 수 있는 작품의 수는 제한이 없으며,
                        팀 구성원은 최소 1명에서 최대 4명까지 가능합니다.
                        한 명이 복수의 팀으로 참가하는 것은 불가능 합니다</p>
                    </dd>
                    <dt>
                        <a href="#">
                            <span>Q.</span>
                            제출한 작품이나 기획서를 수정하여 다시 제출한 작품이나
                        </a>
                    </dt>
                    <dd class="cont">
                        <span>A.</span>
                        <p>한 팀(사람)이 출품할 수 있는 작품의 수는 제한이 없으며,
                        팀 구성원은 최소 1명에서 최대 4명까지 가능합니다.
                        한 명이 복수의 팀으로 참가하는 것은 불가능 합니다</p>
                    </dd>
                    <dt>
                        <a href="#">
                            <span>Q.</span>
                            응모 신청은 반드시 온라인으로 해야하나요?
                        </a>
                    </dt>
                    <dd class="cont">
                        <span>A.</span>
                        <p>한 팀(사람)이 출품할 수 있는 작품의 수는 제한이 없으며,
                        팀 구성원은 최소 1명에서 최대 4명까지 가능합니다.
                        한 명이 복수의 팀으로 참가하는 것은 불가능 합니다</p>
                    </dd>
                    <dt>
                        <a href="#">
                            <span>Q.</span>
                            SK이노베이션은 어떤 회사인가요?
                        </a>
                    </dt>
                    <dd class="cont">
                        <span>A.</span>
                        <p>한 팀(사람)이 출품할 수 있는 작품의 수는 제한이 없으며,
                        팀 구성원은 최소 1명에서 최대 4명까지 가능합니다.
                        한 명이 복수의 팀으로 참가하는 것은 불가능 합니다</p>
                    </dd>
                    <dt>
                        <a href="#">
                            <span>Q.</span>
                            Big Picture 캠페인은 무엇인가요?
                        </a>
                    </dt>
                    <dd class="cont">
                        <span>A.</span>
                        <p>한 팀(사람)이 출품할 수 있는 작품의 수는 제한이 없으며,
                        팀 구성원은 최소 1명에서 최대 4명까지 가능합니다.
                        한 명이 복수의 팀으로 참가하는 것은 불가능 합니다</p>
                    </dd>
                </dl>
            </section>
        </div>
    </div>

    <footer class="global-footer">
        <p class="copyright">COPYRIGHT &copy;SKINNOVATION CO.,LTD ALL RIGHTS RESERVED.</p>
    </footer>
</article>
</body>
</html>
