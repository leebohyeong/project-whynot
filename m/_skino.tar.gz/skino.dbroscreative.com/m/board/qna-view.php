<?php
/* ==============================================================================
'   작 성 자 : DEV GROUP - JUHYUN
'   날    짜 : 2017-05-08
'   용    도 : 프론트 > Q&A 게시물 상세 (view-qna.php)
'   Copyright 2017, Group IDD. All rights are reserved
' ================================================================================= */
require_once $_SERVER['DOCUMENT_ROOT']."/vendor/autoload.php";

use \Groupidd\Model\ModelBase;
use \Groupidd\Common\CommonFunc;
use \Groupidd\Library\Validator;

$pageNo     = isset($_GET['page']) && $_GET['page'] != '' ? $_GET['page'] : 1;
$seq        = isset($_GET['seq']) ? $_GET['seq'] : '';

if( !$seq ) {
    CommonFunc::jsAlert('잘못된 접근입니다.','location.href="/m/board/qna-list.php";');
    exit();
}

$db = new ModelBase();
$db->select('seq, title, content, comment, reg_name, reg_date, del_date');
$db->from('BOARD');
$db->where('seq', $seq);
$db->where('del_date', NULL, 'IS');
$boardData = $db->getOne();
$db->init();

if( empty($boardData) ) {
    CommonFunc::jsAlert('게시물이 존재하지 않습니다.','location.href="/m/board/qna-list.php";');
    exit();
}

// 이전글, 다음글
$db->select('seq');
$db->from('BOARD');
$db->where('seq', $seq, '<');
$db->where('del_date', NULL, 'IS');
$db->where('board_type', 'qna');
$db->orderby('seq', 'DESC');
$db->limit(1);
$prevSeq = $db->getOne();
$db->init();

$db->select('seq');
$db->from('BOARD');
$db->where('seq', $seq, '>');
$db->where('del_date', NULL, 'IS');
$db->where('board_type', 'qna');
$db->orderby('seq');
$db->limit(1);
$nextSeq = $db->getOne();
$db->init();

// 조회수 업데이트
$boardInfo['view_count'] = 'view_count + 1';
$db->from('BOARD');
$db->where('seq', $seq);
$db->update($boardInfo, null);
$db->close();

?>
<!DOCTYPE html>
<html lang="ko">
<head>
    <?php require_once $ROOT_PATH_.'/m/assets/include/head.php'; ?>
</head>
<body id="board-qna-view">
<article class="global-wrap">
    <?php require_once $ROOT_PATH_.'/m/assets/include/gnb.php'; ?>
    <div class="global-container">
        <div class="global-content">
            <?php require_once $ROOT_PATH_.'/m/assets/include/gnb-board.php'; ?>
            <section class="board-view">
                <dl>
                    <dt class="title">
                        <strong class="sr-only">질문</strong>
                        <?=$boardData['title']?>
                    </dt>
                    <dd class="info">
                        <strong class="sr-only">상세 정보</strong>
                        <em>&#183; 작성자</em>
                        <p>
                            <?=$boardData['reg_name']?>
                        </p>
                        <em>&#183; 작성일</em>
                        <p>
                            <?=substr($boardData['reg_date'], 0, 10)?>
                        </p>
                        <em>&#183; 내용</em>
                        <p>
                            <?=nl2br($boardData['content'])?>
                        </p>
                    </dd>
                    <dd class="cont">
                        <strong class="sr-only">답변</strong>
                        <p>
                            <?php
                            if ( !$boardData['comment'] ) {
                            ?>
                            상담은 접수된 건부터 순차적으로 진행됩니다. 답변 완료 시까지는 평균적으로 영업일 기준 2일이 소요되며,<br>
                            문의가 많은 경우 다소 지연될 수 있습니다.
                            <?php
                            } else {
                                echo nl2br($boardData['comment']);
                            }
                            ?>
                        </p>
                    </dd>
                </dl>
            </section>
            <div class="board-bottom">
                <nav class="page-control">
                    <?php
                    if( empty($prevSeq) ) {
                        echo '<a href="javascript:;" onclick="alert(\'처음 글입니다.\');" class="prev"><span>이전 글</span></a>';
                    } else {
                    ?>
                    <a href="/m/board/view-qna.php?seq=<?=$prevSeq['seq']?>" class="prev"><span>이전 글</span></a>
                    <?php
                    }
                    if( empty($nextSeq) ) {
                        echo '<a href="javascript:;" onclick="alert(\'마지막 글입니다.\');" class="next"><span>다음 글</span></a>';
                    } else {
                    ?>
                    <a href="/m/board/view-qna.php?seq=<?=$nextSeq['seq']?>" class="next"><span>다음 글</span></a>
                    <?php
                    }
                    ?>
                </nav>
                <a href="/m/board/qna-list.php" class="list"><span>목록보기</span></a>
            </div>
        </div>
    </div>
    <?php require_once $ROOT_PATH_.'/m/assets/include/footer.php'; ?>
</article>
</body>
</html>
