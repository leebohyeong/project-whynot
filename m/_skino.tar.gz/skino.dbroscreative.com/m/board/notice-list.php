<?php
/* =============================================================================
'   작 성 자 : DEV GROUP - JUHYUN
'   날    짜 : 2017-05-08
'   용    도 : 프론트 > 공지사항 게시판 리스트 (list-notice.php)
'   Copyright 2017, Group IDD. All rights are reserved
' =============================================================================*/
require_once $_SERVER['DOCUMENT_ROOT']."/vendor/autoload.php";

use \Groupidd\Model\ModelBase;
use \Groupidd\Common\CommonFunc;
use \Groupidd\Library\Validator;

$pageNo             = isset($_GET['page']) && $_GET['page'] != '' ? $_GET['page'] : 1;

$db = new ModelBase();

$db->from('BOARD');
$db->where('board_type', 'notice');
$db->where('del_date', NULL, 'IS');

$countList = $db->getCountAll();    // 전체 게시물 수
$db->init();

// 상단 노출 게시물
$db->select('seq, title, content, reg_name, comment, reg_date');
$db->where('board_type', 'notice');
$db->where('del_date', NULL, 'IS');
$db->where('top_YN', 'Y');
$db->orderby('seq');
$topBoardList = $db->getAll();    // 상단 노출 게시물 수
$db->init();

// paging
$perPage = 7-count($topBoardList);      // 한 페이지에 보여질 리스트 수
$pageSize	= intval($countList/$perPage);
if($pageSize * $perPage != $countList) $pageSize = $pageSize+1;
$currentPage = $pageNo == 1 ? 0 : ($pageNo*$perPage)-$perPage;

$db->select('seq, title, content, reg_name, comment, reg_date');
$db->from('BOARD');
$db->where('board_type', 'notice');
$db->where('del_date', NULL, 'IS');
$db->where('top_YN', 'N');
$db->orderby('seq', 'DESC');
$db->limit($perPage, $currentPage );
$boardList = $db->getAll();
$db->close();
?>
<!DOCTYPE html>
<html lang="ko">
<head>
    <?php require_once $ROOT_PATH_.'/m/assets/include/head.php'; ?>
</head>
<body id="board-notice-list">
<article class="global-wrap">
    <?php require_once $ROOT_PATH_.'/m/assets/include/gnb.php'; ?>
    <div class="global-container">
        <div class="global-content">
            <?php require_once $ROOT_PATH_.'/m/assets/include/gnb-board.php'; ?>
            <section class="board-list">
                <table class="table">
				    <caption>공지사항 리스트</caption>
    				<tbody>
                        <?php
                        foreach($topBoardList as $row) {
                        ?>
                        <tr>
                            <td class="content">
                                <a href="/m/board/notice-view.php?seq=<?=$row['seq']?>&page=<?=$pageNo?>" class="link">
                                    <span class="date"><?=substr($row['reg_date'], 0, 10)?></span>
                                    <p><?=$row['title']?></p>
                                </a>
                            </td>
                        </tr>
                        <?php
                        }
                        foreach($boardList as $row) {
                        ?>
                        <tr>
                            <td class="content">
                                <a href="/m/board/notice-view.php?seq=<?=$row['seq']?>&page=<?=$pageNo?>" class="link">
                                    <span class="date"><?=substr($row['reg_date'], 0, 10)?></span>
                                    <p><?=$row['title']?></p>
                                </a>
                            </td>
                        </tr>
                        <?php
                        }
                        ?>
                    </tbody>
                </table>
            </section>
            <div class="board-bottom">
                <?=CommonFunc::getPaging($pageNo, $perPage, $pageSize, '')?>
            </div>
        </div>
    </div>
    <?php require_once $ROOT_PATH_.'/m/assets/include/footer.php'; ?>
</article>
</body>
</html>
