<?php
require_once $_SERVER['DOCUMENT_ROOT'] . "/vendor/autoload.php";

session_unset();
Header("Location:/sitemanager/login.php");

exit();

?>