<?php
require_once $_SERVER['DOCUMENT_ROOT'] . "/vendor/autoload.php";

use \Groupidd\Model\ModelBase;
use \Groupidd\Common\CommonFunc;
use \Groupidd\Library\Validator;

$result = array();

$adminInfo= array();
$adminInfo['admin_id'] = isset($_POST['admin_id'])? $_POST['admin_id'] : '';
$adminInfo['admin_pw'] = isset($_POST['admin_pw'])? $_POST['admin_pw'] : '';

$validator = new Validator($adminInfo);

$validator->rule('required', 'admin_id')->message('ID는 필수 입력값입니다.');
$validator->rule('required', 'admin_pw')->message('PW는 필수 입력값입니다.');



if($validator->validate()) {       		// validation 성공
	$adminInfo = $validator->data(); 	//데이터 받아오기
	$adminId = $adminInfo['admin_id'];
	$adminPw = $adminInfo['admin_pw'];
} else {        // validation 실패

	$result['message'] = '잘못된 접근입니다.';
	$result['result'] = false;
	echo json_encode($result);
	exit();
}

// if ($adminId == '' || $adminPw == ''){
//     // CommonFunc::jsAlert('잘못된 접근입니다.', "location.href='login.php';");
// 	// exit();
// }

//비밀번호 암호화
$adminpwEnCode = hash('sha512',$adminPw);

//db 시작
$db = new ModelBase();
$db-> select("admin_pw, admin_lv, use_YN, default_pw_YN, login_fail_cnt, login_last_date, admin_name");
$db-> from("ADMIN_MEMBERS");
$db-> where("admin_id", $adminId);
$adminRs = $db->getOne();				//result

$db-> init();

if (!$adminRs){
	$msg = "일치하는 정보가 없습니다.";
	// CommonFunc::jsAlert($msg, "location.href='login.php';");
	// exit();
	$result['message'] = $msg;
	$result['result'] = false;
	echo json_encode($result);
    exit();

}else{

	if($adminRs['use_YN'] == 'N'){
		$msg = "사용 잠금 계정입니다.";

		//log
		// $insert = array('admin_id'=>$adminId , 'ip'=>$USER_IP_ , 'success_YN'=>'N');
		// $db->from("ADMIN_LOGIN_LOG");
		// $db->insert($insert);
		// $db->init();

		// CommonFunc::jsAlert($msg, "location.href='login.php';");
		// exit;

		$result['message'] = $msg;
		$result['result'] = false;
		echo json_encode($result);
        exit();
	}

	if($adminRs['default_pw_YN'] == 'Y'){
		$msg = "비밀번호 설정 초기화";

		$result['message'] = $msg;
		$result['result'] = false;
		echo json_encode($result);
        exit();
	}

	if( $adminRs['login_fail_cnt'] >= 5){
		$msg	="비밀번호입력 초과회수가 5회 이상이므로 계정 잠금 처리 되었습니다. <br> 계속 이용하고 싶으시면 슈퍼관리자에게 문의하여 주시기 바랍니다.";

		$update = array('use_YN'=>'N');
		$db->from('ADMIN_MEMBERS');
		$db->where('admin_id',$adminId);
		$db->update($update);
		$db->init();

		//log
		// $insert = array('admin_id'=>$adminId , 'ip'=>$USER_IP_ , 'success_YN'=>'N');
		// $db->from("ADMIN_LOGIN_LOG");
		// $db->insert($insert);
		// $db->init();

		// CommonFunc::jsAlert($msg, "location.href='login.php';");
		// exit;
		$result['message'] = $msg;
		$result['result'] = false;
		echo json_encode($result);
        exit();
	}

	//마지막 로그인 날짜 확인
	$last = new Datetime($adminRs['login_last_date']);
	$now = new Datetime(date('Y-m-d h:i:s'));
	$diff = date_diff($last,$now);

	if( $diff->days >= 30){
		$msg = "30일 이상 접근 기록이 없어 잠금 계정 처리 되었습니다.";

		$update = array('use_YN'=>'N');
		$db->from('ADMIN_MEMBERS');
		$db->where('admin_id',$adminId);
		$db->update($update);
		$db->init();

		// CommonFunc::jsAlert($msg, "location.href='login.php';");
		// exit;
		$result['message'] = $msg;
		$result['result'] = false;
		echo json_encode($result);
	}

	// 로그인 성공
	if($adminpwEnCode == $adminRs['admin_pw']){

		$_SESSION['ADMIN_ID'] = $adminId;
		$_SESSION['ADMIN_NM'] = $adminRs['admin_name'];
		$_SESSION['ADMIN_LV'] = $adminRs['admin_lv'];  //L1 = 슈퍼  L2 = 대행사  L3 =개발자

		$date = date('y-m-d h:i:s');
		$update = array('login_fail_cnt'=>'0','login_last_date'=> $date );
		$db->from('ADMIN_MEMBERS');
		$db->where('admin_id',$adminId);
		$db->update($update);
		$db->init();

		$result['result'] = true;
		echo json_encode($result);

		// //log
		// $insert = array('admin_id'=>$adminId , 'ip'=>$USER_IP_ , 'success_YN'=>'Y');
		// $db->from("ADMIN_LOGIN_LOG");
		// $db->insert($insert);
		// $db->init();

	}else{
		// 로그인 실패
		$update = array('login_fail_cnt'=>'login_fail_cnt + 1');
		$db->from('ADMIN_MEMBERS');
		$db->where('admin_id',$adminId);
		$db->update($update);
		$db->init();

		//log
		// $insert = array('admin_id'=>$adminId , 'ip'=>$USER_IP_ , 'success_YN'=>'N');
		// $db->from("ADMIN_LOGIN_LOG");
		// $db->insert($insert);
		// $db->init();

		$msg = "비밀 번호 입력 오류";
		$result['message'] = $msg;
		$result['result'] = false;
		echo json_encode($result);
		// CommonFunc::jsAlert($msg, "location.href='login.php';");
		exit;
	}
}
