<?php
/* ==============================================================================
'   작 성 자 : DEV GROUP - JUHYUN
'   날    짜 : 2017-04-28
'   용    도 : 관리자 > Q&A 게시판 리스트 (qna-list.php)
'   Copyright 2017, Group IDD. All rights are reserved
' ===============================================================================*/
require_once $_SERVER['DOCUMENT_ROOT']."/vendor/autoload.php";

use \Groupidd\Model\ModelBase;
use \Groupidd\Common\CommonFunc;
use \Groupidd\Library\Validator;

$pageNo     = isset($_GET['page']) && $_GET['page'] != '' ? $_GET['page'] : 1;

$searchType         = isset($_GET['search_type']) ? $_GET['search_type'] : '';
$searchInfo['text'] = isset($_GET['search_text']) ? $_GET['search_text'] : '';


$db = new ModelBase();

if ( $searchInfo['text'] != '' ) {
    $validator = new Validator($searchInfo);
    $validator->rule('required', 'text');
    if($validator->validate()) {       		// validation 성공
        $searchInfo = $validator->data();
        $searchType = $searchType == 'title' ? 'title' : 'content';
        $db->like($searchType, $searchInfo['text']);
    }
}

$db->from('BOARD');
$db->where('board_type', 'qna');
$countList = $db->getCountAll();     // 전체 게시물 수

// paging
$perPage = 15;      // 한 페이지에 보여질 리스트 수
$pageSize	= intval($countList/$perPage);
if($pageSize * $perPage != $countList) $pageSize = $pageSize+1;
$currentPage = $pageNo == 1 ? 0 : ($pageNo*$perPage)-$perPage;

$db->select('seq, title, comment, reg_date, del_date, view_count', true);
$db->orderby('SEQ', 'DESC');
$db->limit($perPage, $currentPage );
$boardList = $db->getAll();
$db->close();
?>
<!DOCTYPE html>
<html>
<head>
	<?php require_once $ROOT_PATH_.'/sitemanager/assets/include/head.php'; ?>
    <script>
        var page = 'board-notice-list';
    </script>
</head>
<body class="lginnotek-admin-body">
	<article class="lginnotek-admin-wrap">
		<?php require_once $ROOT_PATH_.'/sitemanager/assets/include/gnb.php'; ?>
		<div class="container">
			<?php require_once $ROOT_PATH_.'/sitemanager/assets/include/lnb.php'; ?>
			<section class="content">
				<div>
					<header id="sub-header" class="top-area">
						<h3 class="sub-title">Q&A</h3>
						<div class="breadcrumbs">
							<ol>
							</ol>
						</div>
					</header>

					<div class="setting">
						<form id="" action="" method="get">
							<ul>
								<li class="full">
									<select name="search_type" id="search_type">
                                        <!--option value="">전체</option-->
										<option value="title" <?=CommonFunc::getSelected($searchType, 'title')?>>제목</option>
                                        <option value="content" <?=CommonFunc::getSelected($searchType, 'content')?>>내용</option>
									</select>
									<input type="text" name="search_text" maxlength="50" value="<?=$searchInfo['text']?>">
								</li>
							</ul>
							<div class="btn-area">
								<button type="submit" class="btn btn-big-gray-1">검색</button>
							</div>
						</form>
					</div>

					<div class="notice-list">
                        <form id="listForm" method="post">
                        <input type="hidden" name="page" value="<?=$pageNo?>">
                        <input type="hidden" name="search_type" value="<?=$_GET['search_type']?>"
                        <input type="hidden" name="search_text" value="<?=$_GET['search_text']?>"
						<div class="control-1">
							<div>
								<a href="javascript:;" onclick="delList();" class="btn btn-small2-gray-3">선택노출해제</a>
							</div>
						</div>

                        <div class="table-style-1">
                            <table>
                                <colgroup>
                                    <col width="60">
                                    <col width="60">
                                    <col width="*">
                                    <col width="100">
                                    <col width="100">
                                    <col width="100">
                                    <col width="100">
                                </colgroup>
                                <thead>
                                    <tr>
                                        <th><input type="checkbox" id="checked_all"></th>
                                        <th>번호</th>
                                        <th>제목</th>
                                        <th>답변여부</th>
                                        <th>작성일</th>
                                        <th>노출여부</th>
                                        <th>조회수</th>
                                    </tr>
                                </thead>
                                <tbody>
                                <?php
                                $i = 0;
                                foreach( $boardList as $row ) {
                                    $bunho=$countList-($i+$currentPage);
                                ?>
                                    <tr>
                                        <td><input type="checkbox" name="chk_list[]" value="<?=$row['seq']?>"></td>
                                        <td><?=$bunho?></td>
                                        <td class="text-left">
                                            <a href="qna-view.php?seq=<?=$row['seq']?>&page=<?=$pageNo?>&search_type=<?=$searchType?>&search_text=<?=$searchInfo['text']?>"><?=$row['title']?>
                                            </a>
                                        </td>
                                        <td><?=$row['comment'] == null || $row['comment'] == '' ? '답변대기' : '답변완료'?></td>
                                        <td><?=date('Y-m-d', strtotime($row['reg_date']))?></td>
                                        <td><?=$row['del_date'] == null ? '노출' : '비노출'?></td>
                                        <td><?=number_format($row['view_count'])?></td>
                                    </tr>
                                <?php
                                    $i++;
                                }
                                ?>
                                </tbody>
                            </table>
                        </div>
						<div class="page-nav">
                        <?=CommonFunc::getPaging($pageNo, $perPage, $pageSize, '&search_type='.$searchType.'&search_text='.$searchInfo['text'])?>
						</div>
                        </form>
					</div>
				</div>
                <?php require_once $ROOT_PATH_.'/sitemanager/assets/include/footer.php'; ?>
			</section>
		</div>
	</article>
    <script>
    $(function() {
        // 검색
        $('.btn-area button').on('submit', function() {
            if(!$.trim($('[name=search_text]').val())) {
                alert('검색어를 입력해 주세요.');
                $('[name=search_text]').focus();
                return false;
            }
        });

        //체크박스 클릭
        $("#checked_all").on('click', function() {
            if($("#checked_all").prop("checked")){
                $("[name='chk_list[]']").prop("checked", true);
            }else{
                $("[name='chk_list[]']").prop("checked", false);
            }
        });
    })

    function delList(){
        if (confirm('노출해제 하시겠습니까?')){
            $('#listForm').attr('action','del-proc.php');
            $('#listForm').submit();
        }
    }
    </script>
</body>
</html>
