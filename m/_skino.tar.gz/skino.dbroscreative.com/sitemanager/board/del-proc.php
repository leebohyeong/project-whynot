<?php
/* ==============================================================================
'   작 성 자 : DEV GROUP - JUHYUN
'   날    짜 : 2017-04-28
'   용    도 : 관리자 > 게시판 (del-proc.php)
'   Copyright 2017, Group IDD. All rights are reserved
' ================================================================================= */
require_once $_SERVER['DOCUMENT_ROOT']."/vendor/autoload.php";

use \Groupidd\Model\ModelBase;
use \Groupidd\Common\CommonFunc;
use \Groupidd\Library\Validator;

$boardType  = isset($_POST['board_type']) ? $_POST['board_type'] : '';
$pageNo     = isset($_POST['page']) ? $_POST['page'] : 1;
$chkList    = isset($_POST['chk_list']) ? $_POST['chk_list'] : '';

if (!$chkList) {
    CommonFunc::jsAlert('잘못된 접근입니다.', 'history.back();');
    exit();
}

$validator = new Validator($chkList);
foreach( $chkList as $value ) {
    $validator->rule('integer', $value);
    if($validator->validate()) {       		// validation 성공
        $delList = $validator->data();
    } else {
        CommonFunc::jsAlert('잘못된 접근입니다.', 'history.back();');
        exit();
    }
}
$db = new ModelBase();

$updateInfo['del_date'] = date('Y-m-d H:i:s');

$db->from('BOARD');
$db->whereIn('seq', $delList);

if ( $db->update($updateInfo) ) {
    if ( $boardType == 'notice' ) {
        CommonFunc::jsAlert('삭제되었습니다.', 'location.href="notice-list.php?page='.$pageNo.'&search_type='.$_POST['search_type'].'&search_text='.$_POST['search_text'].'"');
    } else {
        CommonFunc::jsAlert('노출 해제되었습니다.', 'location.href="qna-list.php?page='.$pageNo.'&search_type='.$_POST['search_type'].'&search_text='.$_POST['search_text'].'"');
    }
} else {
    if ( $boardType == 'notice' ) {
        CommonFunc::jsAlert('삭제에 실패했습니다.', 'location.href="notice-list.php?page='.$pageNo.'&search_type='.$_POST['search_type'].'&search_text='.$_POST['search_text'].'"');
    } else {
        CommonFunc::jsAlert('노출 해제에 실패했습니다.', 'location.href="qna-list.php?page='.$pageNo.'&search_type='.$_POST['search_type'].'&search_text='.$_POST['search_text'].'"');
    }
}

$db->close();
