<?php
/* ==============================================================================
'   작 성 자 : DEV GROUP - YOIIJH
'   날    짜 : 2017-04-28
'   용    도 : 관리자 > 게시판 (view.php)
'   Copyright 2017, Group IDD. All rights are reserved
' ================================================================================= */
require_once $_SERVER['DOCUMENT_ROOT']."/vendor/autoload.php";

use \Groupidd\Model\ModelBase;
use \Groupidd\Common\CommonFunc;

$seq        = isset($_GET['seq']) ? $_GET['seq'] : '';

if( !$seq ) {
    CommonFunc::jsAlert('잘못된 접근입니다.','location.href="qna-list.php";');
    exit();
}

$db = new ModelBase();
$db->from('BOARD');
$db->select('seq, title, content, comment, reg_date, del_date');
$db->where('seq', $seq);
$boardData = $db->getOne();
$db->close();
?>
<!DOCTYPE html>
<html>
<head>
	<?php require_once $ROOT_PATH_.'/sitemanager/assets/include/head.php'; ?>
    <script>
        var page = 'board-qna-view';
    </script>
</head>
<body class="lginnotek-admin-body">
	<article class="lginnotek-admin-wrap">
		<?php require_once $ROOT_PATH_.'/sitemanager/assets/include/gnb.php'; ?>
		<div class="container">
			<?php require_once $ROOT_PATH_.'/sitemanager/assets/include/lnb.php'; ?>
			<section class="content">
				<div>
					<header id="sub-header" class="top-area">
						<h3 class="sub-title"></h3>
						<div class="breadcrumbs">
							<ol>
							</ol>
						</div>
					</header>
                    <div class="writing">
                        <form id="form_board_modify" method="post" action="mod-proc.php">
                        <input type="hidden" name="seq" value="<?=$boardData['seq']?>">
                        <input type="hidden" name="board_type" value="qna">
                    	<table>
                    		<colgroup>
                    			<col width="100">
                    			<col width="*">
                                <col width="100">
                                <col width="200">
                    		</colgroup>
                    		<tbody>
                    			<tr>
                    				<th>NO.</th>
                    				<td><?=$boardData['seq']?></td>
                                    <th>작성일</th>
                    				<td><?=date('Y-m-d', strtotime($boardData['reg_date']))?></td>
                    			</tr>
                    			<tr>
                    				<th>제목</th>
                    				<td colspan="3"><?=$boardData['title']?></td>
                    			</tr>
                    			<tr>
                    				<th>내용</th>
                    				<td colspan="3"><?=nl2br($boardData['content'])?></td>
                    			</tr>
                                <tr>
                                    <th>답변</th>
                                    <td colspan="3"><textarea name="comment"><?=$boardData['comment']?></textarea></td>
                                </tr>
                    		</tbody>
                    	</table>
                        </form>
                    	<div class="control-1">
                    		<div>
                                <a href="javascript:;" class="btn btn-small2-red-1" data-view="<?=$boardData['del_date'] == null ? 'hide' : 'show'?>"  data-seq = "<?=$boardData['seq']?>" id="view"><?=$boardData['del_date'] == null ? '질문숨김' : '질문노출'?></a>
                    			<a href="javascript:;" onclick="formSubmit();" class="btn btn-small2-red-1">답변등록</a>
                                <a href="qna-list.php?page=<?=$_GET['page']?>" class="btn btn-small2-gray-3">목록</a>
                    		</div>
                    	</div>
                    </div>

				</div>
                <?php require_once $ROOT_PATH_.'/sitemanager/assets/include/footer.php'; ?>
			</section>
		</div>
	</article>
    <script>
    $(function() {
        $('#view').on('click', function () {
            var statusMsg = $('#view').data().view == 'hide' ? '숨김' : '노출';
            if(confirm(statusMsg+' 처리 하시겠습니까?')) {
                $.ajax({
                    async: false,
                    type: 'post',
                    url: 'qna-view-proc.php',
                    data: {
                        seq : $('#view').data().seq,
                        view_status : $('#view').data().view
                    },
                    success: function (res) {
                        var result = $.parseJSON(res);
                        alert(statusMsg+result.msg);
                        if ( result.result ) {
                            location.href = "qna-view.php?seq=<?=$_GET['seq']?>&page=<?=$_GET['page']?>&search_type=<?=$_GET['search_type']?>&search_text=<?=$_GET['search_text']?>";
                        }
                    },
                    error: function (jqXHR, textStatus, errorThrown) {
                        console.log('질문 보기 오류');
                    }
                });
            }
        });
    });

    function delQna(){
        if (confirm('삭제 하시겠습니까?')){
            $('#listForm').attr('action','del-proc.php');
            $('#listForm').submit();
        }
    }

    function formSubmit() {
        if (!$.trim($('textarea').val())) {
            alert('답변을 입력해 주세요.');
            $('textarea').focus();
            return;
        }

        if (confirm('등록 하시겠습니까?')){
            $('#form_board_modify').submit();
        }
    }
    </script>
</body>
</html>
