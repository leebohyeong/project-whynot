<?php
/* ==============================================================================
'   작 성 자 : DEV GROUP - JUHYUN
'   날    짜 : 2017-04-28
'   용    도 : 관리자 > 게시물 수정 처리 (mod-proc.php)
'   Copyright 2017, Group IDD. All rights are reserved
' ================================================================================= */
require_once $_SERVER['DOCUMENT_ROOT']."/vendor/autoload.php";

// config - namespace
use \Groupidd\Common\CommonFunc;
use \Groupidd\Model\ModelBase;
use \Groupidd\Library\Validator;

$seq                            = isset($_POST['seq'])? $_POST['seq'] : '';
$pageNo                         = isset($_POST['page']) ? $_POST['page'] : 1;
$boardType                      = isset($_POST['board_type']) ? $_POST['board_type'] : '';

// config - request params
$boardInfo                      = array();
if ( $boardType == 'notice' ) {
    $boardInfo['top_YN']            = isset($_POST['top_YN'])? $_POST['top_YN'] : '';   // 상단노출
    $boardInfo['title']             = isset($_POST['title'])? $_POST['title'] : '';             // 제목
    $boardInfo['content']           = isset($_POST['content'])? $_POST['content'] : '';         // 내용
} else if ( $boardType == 'qna' ) {
    $boardInfo['comment']           = isset($_POST['comment']) ? $_POST['comment'] : '';        // 답변
} else {
    $boardInfo['image']             = isset($_POST['image'])? $_POST['image'] : '';             // 이미지 썸네일
    $boardInfo['event_start_date']  = isset($_POST['event_start_date'])? $_POST['event_start_date'] : '0000-00-00';   // 이벤트 시작일
    $boardInfo['event_end_date']    = isset($_POST['event_end_date'])? $_POST['event_end_date'] : '0000-00-00';       // 이벤트 종료일
}

if ( !$seq ) {
    CommonFunc::jsAlert('잘못된 접근입니다.',"location.href='list.php';");
    exit();
}

//validation 검사
$validator = new Validator($boardInfo);
if ( $boardType == 'qna' ) {
    $validator->rule('required', 'comment')->message('답변은 필수 입력값입니다.');
} else {
    $validator->rule('required', 'title')->message('제목은 필수 입력값입니다.');
    $validator->rule('required', 'content')->message('내용은 필수 입력값입니다.');
}

$db = new ModelBase();

if($validator->validate()) {       		// validation 성공
    $boardInfo = $validator->data(); 	//데이터 받아오기
	// database 처리
	$db->from('BOARD');
    $db->where('seq', $seq);
	if ( $db->update($boardInfo) ) {
        if ( $boardType == 'qna' ) {
            CommonFunc::jsAlert('답변이 등록 되었습니다.','window.location="'.$boardType.'-view.php?board_type='.$boardType.'&seq='.$seq.'&page='.$pageNo.'";');
		} else {
            CommonFunc::jsAlert('게시물이 수정 되었습니다.','window.location="'.$boardType.'-view.php?board_type='.$boardType.'&seq='.$seq.'&page='.$pageNo.'";');
        }
	} else {
        if ( $boardType == 'qna' ) {
            CommonFunc::jsAlert('답변 등록에 실패했습니다.','');
		} else {
            CommonFunc::jsAlert('게시물 수정에 실패하였습니다. 확인 후 다시 시도해 주세요.','');
        }
	}
	$db->init();
} else {        // validation 실패
	CommonFunc::jsAlert($validator->errors(),'');
    exit;
}
