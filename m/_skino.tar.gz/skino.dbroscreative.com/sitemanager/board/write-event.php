<?php
require_once $_SERVER['DOCUMENT_ROOT']."/vendor/autoload.php";

use \Groupidd\Model\ModelBase;
use \Groupidd\Common\CommonFunc;
/*
if($ADMIN_ID_== "" || $ADMIN_LV_== ""){
    CommonFunc::jsAlert('잘못된 접근입니다.', "location.href='login.php';");
    exit();
}

if( $ADMIN_LV_!= "L1"){
    CommonFunc::jsAlert('잘못된 접근입니다.',"location.href='account-list.php';");
    exit();
}
*/
$model = new ModelBase();
$model->from('BOARD');
$model->select("*");
$users = $model->getAll();

?>
<!DOCTYPE html>
<html>
<head>
	<?php require_once $ROOT_PATH_.'/sitemanager/assets/include/head.php'; ?>
</head>
<body class="lginnotek-admin-body">
	<article class="lginnotek-admin-wrap">
		<?php require_once $ROOT_PATH_.'/sitemanager/assets/include/gnb.php'; ?>
		<div class="container">
			<?php require_once $ROOT_PATH_.'/sitemanager/assets/include/lnb.php'; ?>
			<section class="content">
				<div>
					<header id="sub-header" class="top-area">
						<h3 class="sub-title"></h3>
						<div class="breadcrumbs">
							<ol>
							</ol>
						</div>
					</header>

					<div class="writing">
						<form action="" method="">
							<table>
								<colgroup>
									<col width="125">
									<col width="*">
								</colgroup>
								<tbody>
									<tr>
										<th>상단노출</th>
										<td><label><input type="radio" name="top_YN" value="Y">Y</label><label><input type="radio" name="top_YN" value="N">N</label></td>
									</tr>
									<tr>
										<th>제목</th>
										<td colspan="3">
											<input type="text">
										</td>
									</tr>
									<tr>
										<th>내용</th>
										<td colspan="3">
											<!--div class="editor">
												<!-- 에디터 -->
											<!--/div-->
                                            <textarea></textarea>
										</td>
									</tr>
								</tbody>
							</table>
							<div class="control-1">
								<div>
									<a href="#" class="btn btn-small2-red-1">등록</a>
									<!--a href="#" class="btn btn-small2-red-1">수정</a-->
									<a href="#" class="btn btn-small2-gray-3">목록</a>
								</div>
							</div>
						</form>
					</div>
				</div>
                <?php require_once $ROOT_PATH_.'/sitemanager/assets/include/footer.php'; ?>
			</section>
		</div>
	</article>
</body>
</html>
