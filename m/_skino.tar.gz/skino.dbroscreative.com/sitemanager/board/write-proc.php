<?php
/* ==============================================================================
'   작 성 자 : DEV GROUP - JUHYUN
'   날    짜 : 2017-04-28
'   용    도 : 관리자 > 게시물 등록 처리 (write-proc.php)
'   Copyright 2017, Group IDD. All rights are reserved
' ================================================================================= */
require_once $_SERVER['DOCUMENT_ROOT']."/vendor/autoload.php";

// config - namespace
use \Groupidd\Common\CommonFunc;
use \Groupidd\Model\ModelBase;
use \Groupidd\Library\Validator;

// config - request params
$boardInfo                      = array();
$boardInfo['top_YN']            = isset($_POST['top_YN'])? $_POST['top_YN'] : '';   // 상단노출
$boardInfo['board_type']        = isset($_POST['board_type'])? $_POST['board_type'] : '';   // 게시판 타입(notice, qna, event)
$boardInfo['title']             = isset($_POST['title'])? $_POST['title'] : '';             // 제목
$boardInfo['content']           = isset($_POST['content'])? $_POST['content'] : '';         // 내용
$boardInfo['image']             = isset($_POST['image'])? $_POST['image'] : '';             // 이미지 썸네일
$boardInfo['event_start_date']  = isset($_POST['event_start_date'])? $_POST['event_start_date'] : '0000-00-00';   // 이벤트 시작일
$boardInfo['event_end_date']    = isset($_POST['event_end_date'])? $_POST['event_end_date'] : '0000-00-00';       // 이벤트 종료일

$board_type                     = isset($_POST['board_type']) ? $_POST['board_type'] : '';

if( !$board_type ) {
    CommonFunc::jsAlert('게시판 타입 오류입니다.','');
}

//validation 검사
$validator = new Validator($boardInfo);
$validator->rule('required', 'title')->message('제목은 필수 입력값입니다.');
$validator->rule('required', 'content')->message('내용은 필수 입력값입니다.');

$db = new ModelBase();

if($validator->validate()) {       		// validation 성공
    $boardInfo = $validator->data(); 	//데이터 받아오기
    $boardInfo['reg_id']    = $ADMIN_ID_;  //등록한 아이디 컬럼 추기
    $boardInfo['reg_date']  = date('Y-m-d H:i:s');      // 게시물 등록일
	// database 처리
	$db->from('BOARD');
	if ( $db->insert($boardInfo) ) {
		CommonFunc::jsAlert('게시물이 등록 되었습니다.','window.location="'.$boardInfo['board_type'].'-list.php?board_type='.$board_type.'";');
	} else {
		CommonFunc::jsAlert('게시물 등록에 실패하였습니다. 확인 후 다시 시도해 주세요.','');
	}
} else {        // validation 실패
	CommonFunc::jsAlert($validator->errors(),'');
}
$db->close();
