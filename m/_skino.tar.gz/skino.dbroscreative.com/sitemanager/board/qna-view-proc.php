<?php
/* ==============================================================================
'   작 성 자 : DEV GROUP - JUHYUN
'   날    짜 : 2017-04-28
'   용    도 : 관리자 > 게시판 (write.php)
'   Copyright 2017, Group IDD. All rights are reserved
' ================================================================================= */
require_once $_SERVER['DOCUMENT_ROOT']."/vendor/autoload.php";

use \Groupidd\Model\ModelBase;
use \Groupidd\Common\CommonFunc;
use \Groupidd\Library\Validator;

$pageNo             = isset($_POST['page']) ? $_POST['page'] : 1;
$viewStatus         = isset($_POST['view_status']) ? $_POST['view_status'] : '';
$boardInfo['seq']   = isset($_POST['seq']) ? $_POST['seq'] : '';

$validator = new Validator($boardInfo);
$validator->rule('integer', 'seq');

if($validator->validate()) {       		// validation 성공
    $boardInfo = $validator->data();
} else {
    $resultData['result']   = false;
    $resultData['msg']      = '데이터 seq가 누락되었습니다.';
    echo json_encode($resultData);
    exit();
}

$db = new ModelBase();

$updateInfo['del_date'] = $viewStatus == 'hide' ? date('Y-m-d H:i:s') : null;

$db->from('BOARD');
$db->where('seq', $boardInfo['seq']);

if ( $db->update($updateInfo) ) {
    $resultData['result']   = true;
    $resultData['msg']      = ' 처리 되었습니다.';
} else {
    $resultData['result']   = false;
    $resultData['msg']      = ' 처리에 실패했습니다.';
}

$db->close();
echo json_encode($resultData);
exit();
