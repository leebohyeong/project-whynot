<?php
/* ==============================================================================
'   작 성 자 : DEV GROUP - YOIIJH
'   날    짜 : 2017-04-28
'   용    도 : 관리자 > 게시판 (view.php)
'   Copyright 2017, Group IDD. All rights are reserved
' ================================================================================= */
require_once $_SERVER['DOCUMENT_ROOT']."/vendor/autoload.php";

use \Groupidd\Model\ModelBase;
use \Groupidd\Common\CommonFunc;

$seq                = isset($_GET['seq']) ? $_GET['seq'] : '';

if( !$seq ) {
    CommonFunc::jsAlert('잘못된 접근입니다.','location.href="notice-list.php"');
    exit();
}

$db = new ModelBase();
$db->from('BOARD');
$db->select('seq, title, content, comment, reg_date, del_date');
$db->where('seq', $seq);
$boardData = $db->getOne();
$db->close();
?>
<!DOCTYPE html>
<html>
<head>
	<?php require_once $ROOT_PATH_.'/sitemanager/assets/include/head.php'; ?>
    <script>
        var page = 'board-notice-view';
    </script>
</head>
<body class="lginnotek-admin-body">
	<article class="lginnotek-admin-wrap">
		<?php require_once $ROOT_PATH_.'/sitemanager/assets/include/gnb.php'; ?>
		<div class="container">
			<?php require_once $ROOT_PATH_.'/sitemanager/assets/include/lnb.php'; ?>
			<section class="content">
				<div>
					<header id="sub-header" class="top-area">
						<h3 class="sub-title"></h3>
						<div class="breadcrumbs">
							<ol>
							</ol>
						</div>
					</header>

                    <div class="writing">
                    	<table>
                    		<colgroup>
                                <col width="100">
                    			<col width="*">
                    		</colgroup>
                    		<tbody>
                    			<tr>
                                    <th>작성일</th>
                    				<td><?=date('Y-m-d', strtotime($boardData['reg_date']))?></td>
                    			</tr>
                    			<tr>
                    				<th>제목</th>
                    				<td><?=$boardData['title']?></td>
                    			</tr>
                    			<tr>
                    				<th>내용</th>
                    				<td><?=nl2br($boardData['content'])?></td>
                    			</tr>
                    		</tbody>
                    	</table>
                    	<div class="control-1">
                    		<div>
                    			<a href="notice-mod.php?seq=<?=$boardData['seq']?>" class="btn btn-small2-red-1">수정</a>
                                <a href="notice-list.php?page=<?=$_GET['page']?>&search_type=<?=$_GET['search_type']?>&search_text=<?=$_GET['search_text']?>" class="btn btn-small2-gray-3">목록</a>
                    		</div>
                    	</div>
                    </div>

				</div>
                <?php require_once $ROOT_PATH_.'/sitemanager/assets/include/footer.php'; ?>
			</section>
		</div>
	</article>
</body>
</html>
