<?php
/* ==============================================================================
'   작 성 자 : DEV GROUP - JUHYUN
'   날    짜 : 2017-04-28
'   용    도 : 관리자 > 게시판 (write.php)
'   Copyright 2017, Group IDD. All rights are reserved
' ================================================================================= */
require_once $_SERVER['DOCUMENT_ROOT']."/vendor/autoload.php";

use \Groupidd\Model\ModelBase;
use \Groupidd\Common\CommonFunc;
/*
if($ADMIN_ID_== "" || $ADMIN_LV_== ""){
    CommonFunc::jsAlert('잘못된 접근입니다.', "location.href='login.php';");
    exit();
}

if( $ADMIN_LV_!= "L1"){
    CommonFunc::jsAlert('잘못된 접근입니다.',"location.href='account-list.php';");
    exit();
}
*/
$seq        = isset($_GET['seq']) ? $_GET['seq'] : '';
$boardType  = 'notice';
// $boardType  = isset($_GET['board_type']) ? $_GET['board_type'] : '';

if( !$seq ) {
    CommonFunc::jsAlert('잘못된 접근입니다.','location.href="list.php?notice='.$boardType.'";');
    exit();
}

$db = new ModelBase();
$db->from('BOARD');
$db->select('seq, title, content, top_YN');
$db->where('seq', $seq);
$boardData = $db->getOne();
$db->close();
?>
<!DOCTYPE html>
<html>
<head>
	<?php require_once $ROOT_PATH_.'/sitemanager/assets/include/head.php'; ?>
</head>
<body class="lginnotek-admin-body">
	<article class="lginnotek-admin-wrap">
		<?php require_once $ROOT_PATH_.'/sitemanager/assets/include/gnb.php'; ?>
		<div class="container">
			<?php require_once $ROOT_PATH_.'/sitemanager/assets/include/lnb.php'; ?>
			<section class="content">
				<div>
					<header id="sub-header" class="top-area">
						<h3 class="sub-title"></h3>
						<div class="breadcrumbs">
							<ol>
							</ol>
						</div>
					</header>

					<div class="writing">
						<form id="form_board_modify" method="post" action="mod-proc.php">
                            <input type="hidden" name="seq" value="<?=$_GET['seq']?>">
                            <input type="hidden" name="page" value="<?=$_GET['page']?>">
                            <input type="hidden" name="board_type" value="<?=$boardType?>">

                            <table>
                                <colgroup>
                                    <col width="125">
                                    <col width="*">
                                </colgroup>
                                <tbody>
                                    <tr>
                                        <th>상단노출</th>
                                        <td>
                                            <label><input type="radio" name="top_YN" value="Y" <?=$boardData['top_YN'] == 'Y' ? 'checked="true"' : '' ?>>Y</label>
                                            <label><input type="radio" name="top_YN" value="N" <?=$boardData['top_YN'] == 'N' ? 'checked="true"' : '' ?>>N</label>
                                        </td>
                                    </tr>
                                    <tr>
                                        <th>제목</th>
                                        <td colspan="3">
                                            <input type="text" name="title" value="<?=$boardData['title']?>">
                                        </td>
                                    </tr>
                                    <tr>
                                        <th>내용</th>
                                        <td colspan="3">
                                            <textarea name="content"><?=$boardData['content']?></textarea>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>


							<div class="control-1">
								<div>
                                    <button type="submit" class="btn btn-small2-red-1" onclick="formSubmit();">수정</button>
									<!--a href="#" class="btn btn-small2-red-1">수정</a-->
									<a href="notice-list.php?board_type=<?=$boardType?>&page=<?=$_GET['page']?>" class="btn btn-small2-gray-3">목록</a>
								</div>
							</div>
						</form>
					</div>
				</div>
                <?php require_once $ROOT_PATH_.'/sitemanager/assets/include/footer.php'; ?>
			</section>
		</div>
	</article>
<script>
var isValid = function () {
    if (!$.trim($('[name=title]').val())) {
        alert('제목을 입력해 주세요');
        $('[name=title]').focus();
        return false;
    }

    if (!$.trim($('[name=content]').val())) {
        alert('내용을 입력해 주세요');
        $('[name=content]').focus();
        return false;
    }
    return true;
}

// 폼 등록
function formSubmit() {
    if (isValid()) {
        if (confirm('수정 하시겠습니까?')){
            $('#form_board_modify').submit();
        }
    }
    return false;
}
</script>
</body>
</html>
