<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=Edge">
<title><?php echo $SITE_NAME_?> ADMIN</title>
<meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1, user-scalable=no">
<meta name="author" content="Group IDD">
<meta name="description" content="<?php echo $SITE_NAME_?> ADMIN">
<meta name="keywords" content="<?php echo $SITE_NAME_?> ADMIN">
<meta name="format-detection" content="telephone=no">
<meta name="format-detection" content="address=no">

<meta name="author" content="<?php echo $SITE_NAME_?> ADMIN">
<meta property="og:title" content="<?php echo $SITE_NAME_?> ADMIN">
<meta property="og:site_name" content="<?php echo $SITE_NAME_?> ADMIN">
<meta property="og:image" content="">
<meta property="og:type" content="website">
<meta property="og:url" content="">
<meta property="og:description" content="">

 <link rel="stylesheet" href="http://code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
<link rel="stylesheet" href="/sitemanager/assets/css/lginnotek-admin.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
<script src="/sitemanager/assets/js/sitemanager.js"></script>
<!--[if lt IE 9]>
    <script src="//cdnjs.cloudflare.com/ajax/libs/html5shiv/3.7.3/html5shiv.min.js"></script>
<![endif]-->
