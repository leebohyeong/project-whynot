<header class="header">
	<h1>
		<img src="../assets/images/logo.png" alt="sitemanager logo">
	</h1>
	<p><span><?=$ADMIN_ID_?></span> 관리자님 좋은 하루 되세요</p>
	<div class="user-menu">
		<a href="#" class="btn btn-small-gray-1">HOME</a>
		<a href="/sitemanager/logout.php" class="btn btn-small-gray-2">LOGOUT</a>
	</div>
</header>
<nav class="gnb">
    <ul>
    </ul>
</nav>
