<section class="lnb">
    <h2></h2>
    <nav>
        <ul>
        </ul>
    </nav>
</section>
