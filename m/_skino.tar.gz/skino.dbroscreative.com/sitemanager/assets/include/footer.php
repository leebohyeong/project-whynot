 <footer>
    <p class="footer">Copyrightⓒ 2017 LG Innotek. All Rights Reserved</p>
</footer>