$(function () {
	var $window = $(window),
		$document = $(document),
		$body = $('body'),
		pageName = document.URL.substring(document.URL.lastIndexOf("/") + 1, document.URL.length);
		firstName = page.split('-')[0],
		fullName = page.replace(/\.\w*$/g, '');
	var gnbData = [
		{
			name: '접수확인',
			//url: '../receipt/receipt-list.php'
            url: 'javascript:alert(\'준비중\');'
		},
		{
			name: '게시판',
			url: '../board/notice-list.php'
		},
		{
			name: 'Admin 관리',
			url: 'javascript:alert(\'준비중\');'
		}
	],
	lnbData = [
		//접수확인
		[
			{
				name: '접수확인',
				url: '../receipt/receipt-list.php'
			}//,
			// {
			// 	name: 'Product Line',
			// 	url: 'main_product.html'
			// }
		],
		//게시판
		[
			{
				name: '공지사항',
				url: '../board/notice-list.php'
			},
			{
				name: 'Q&A',
				url: '../board/qna-list.php'
			},
			{
				name: 'EVENT',
				url: 'javascript:alert(\'준비중\');'
			}
		],
		//관리자
		[
			{
				name: '계정 관리',
				url: '../admin/account-list.php'
			},
			{
				name: '로그인 관리',
				url: 'admin-login-list.php'
			},
			{
				name: '이력관리',
				url: 'admin-history-list.php'
			}
		]
	],
	subHeaderData = [
		{
			title: 'Top 배너',
			course: 'Main@Top 배너@상세'
		},
		{
			title: 'Product Line',
			course: 'Main@Product Line@상세'
		},
		{
			title: '카테고리 설정',
			course: 'Product@카테고리 설정@리스트'
		},
		{
			title: '메인 페이지 관리',
			course: 'Product@메인페이지관리@상세'
		},
		{
			title: '상세 페이지 관리',
			course: 'Product@상세페이지관리@리스트'
		},
		{
			title: '상세 페이지 관리',
			course: 'Product@상세페이지관리@상세'
		},
		{
			title: '카테고리',
			course: 'Support@카테고리@리스트'
		},
		{
			title: '다운로드',
			course: 'Support@다운로드@리스트'
		},
		{
			title: '다운로드',
			course: 'Support@다운로드@자료등록/수정'
		},
		{
			title: '파트너',
			course: 'Support@파트너@리스트'
		},
		{
			title: '파트너',
			course: 'Support@파트너@상세'
		},
		{
			title: 'Others',
			course: 'Support@Others@리스트'
		},
		{
			title: 'Others',
			course: 'Support@Others@상세'
		},
		{
			title: 'Open Source',
			course: 'Support@Open Source@리스트'
		},
		{
			title: 'Open Source',
			course: 'Support@Open Source@상세'
		},
		{
			title: 'NEWS & NOTICE',
			course: 'News&Notice@리스트'
		},
		{
			title: 'NEWS & NOTICE',
			course: 'News&Notice@리스트@상세'
		},
		{
			title: '계정 관리',
			course: '관리자 관리@계정 관리@리스트'
		},
		{
			title: '계정 관리',
			course: '관리자 관리@계정 관리@상세'
		},
		{
			title: '로그인 관리',
			course: '관리자 관리@로그인 관리@리스트'
		},
		{
			title: '이력 관리',
			course: '관리자 관리@이력 관리@리스트'
		}
	];

	var util = {
		modal: {
			show: function (target) {
				$body.addClass('open-modal');

				target.addClass('in');

				clearTimeout(this.timer);
				this.timer = setTimeout(function () {
					target.addClass('on');
				}, 50);
			},
			hide: function (target) {
				this.body.removeClass('open-modal');

				target = target ? target : this.elem;

				target.removeClass('in on');
			},
			toggle: function (target, notClose) {
				var that = this;

				this.hide();
				this.show(target);
				target.off();

				if (notClose) return false;

				target.on('click', '.modal-backdrop, .modal-close a', function (e) {
					e.preventDefault();
					that.hide(target);
				});
			},
			init: function () {
				var that = this;

				this.elem = $('.modal');
				this.body = $body;

				$document
					.on('click', '[data-api="modal"]', function (e) {
						e.preventDefault();
						that.toggle($($(this).attr('href')));
					});
			}
		},
		datepicker: function () {
			$.each($('[data-api="date-picker"]'), function () {
				var dateInput = $(this).find('input'),
					from,
					to,
					dateFormat = 'yy-mm-dd',
					getDate = function (element) {
						var date;

						try {
							date = $.datepicker.parseDate(dateFormat, element.value);
						} catch (error) {
							date = null;
						}
						return date;
					};

				dateInput.datepicker({
					defaultDate: '+1w',
					dateFormat: dateFormat
				});

				if (dateInput.length > 1) {
					from = dateInput.eq(0);
					to = dateInput.eq(1);

					from.on('change', function () {
						to.datepicker('option', 'minDate', getDate(this));
					});

					to.on('change', function () {
						from.datepicker('option', 'maxDate', getDate(this));
					});
				}
			});
		},
		gnb: function () {
			var wrap = $('.gnb ul');
			for(var i = 0; i < gnbData.length; i++) {
				wrap
					.append('<li data-idx="'+i+'"><a href="'+gnbData[i].url+'">'+gnbData[i].name+'</a></li>');
			}

			switch (firstName) {
				case 'main':
					wrap
						.find('[data-idx="0"] a')
						.addClass('on');
				break;
				case 'product':
					wrap
						.find('[data-idx="1"] a')
						.addClass('on');
				break;
				case 'support':
					wrap
						.find('[data-idx="2"] a')
						.addClass('on');
				break;
				case 'news':
					wrap
						.find('[data-idx="3"] a')
						.addClass('on');
				break;
				case 'admin':
					wrap
						.find('[data-idx="4"] a')
						.addClass('on');
				break;
				default: '데이터가 없습니다.'
			}
		},
		lnb: function () {
			var lnb = $('.lnb');
			switch (firstName) {
				case 'receipt':
					var mainTitle = gnbData[0].name.replace(/\s[^A-Za-z가~힣]*$/g,'');

					lnb
						.find('h2')
						.append(mainTitle);

					for (var i = 0; i < lnbData[0].length; i++) {
						$('.lnb ul')
							.append('<li data-lnb="'+i+'"><a href="'+ lnbData[0][i].url +'">'+ lnbData[0][i].name +'</a></li>');
					}
				break;
				case 'board':
					var mainTitle = gnbData[1].name.replace(/\s[^A-Za-z가~힣]*$/g,'');
					lnb
						.find('h2')
						.append(mainTitle);

					for (var i = 0; i < lnbData[1].length; i++) {
						$('.lnb ul')
							.append('<li><a href="'+ lnbData[1][i].url +'">'+ lnbData[1][i].name +'</a></li>');
					}
				break;
				case 'admin':
					var mainTitle = gnbData[2].name.replace(/\s[^A-Za-z가~힣]*$/g,'');
					lnb
						.find('h2')
						.append(mainTitle);

					for (var i = 0; i < lnbData[3].length; i++) {
						$('.lnb ul')
							.append('<li><a href="'+ lnbData[2][i].url +'">'+ lnbData[2][i].name +'</a></li>');
					}
				break;
				default: '데이터가 없습니다.'
			};
		},
		subHeader: function () {
			var lnb = $('.lnb'),
				subHeader = $('#sub-header'),
				breadcrumbs = $('.breadcrumbs ol');

			switch (fullName) {
				case 'main_top_benner':
					var course = subHeaderData[0].course.split('@');

					subHeader
						.find('.sub-title')
						.append(subHeaderData[0].title);

					for(var i = 0; i < course.length; i++) {
						breadcrumbs
							.append('<li>'+ course[i] +'</li>');
					}
				break;
				case 'main_product':
					var course = subHeaderData[1].course.split('@');

					subHeader
						.find('.sub-title')
						.append(subHeaderData[1].title);

					for(var i = 0; i < course.length; i++) {
						breadcrumbs
							.append('<li>'+ course[i] +'</li>');
					}
				break;
				case 'product_category':
					var course = subHeaderData[2].course.split('@');

					subHeader
						.find('.sub-title')
						.append(subHeaderData[2].title);

					for(var i = 0; i < course.length; i++) {
						breadcrumbs
							.append('<li>'+ course[i] +'</li>');
					}
				break;
				case 'product_main_division':
					var course = subHeaderData[3].course.split('@');

					subHeader
						.find('.sub-title')
						.append(subHeaderData[3].title);

					for(var i = 0; i < course.length; i++) {
						breadcrumbs
							.append('<li>'+ course[i] +'</li>');
					}
				break;
				case 'product_detail_list':
					var course = subHeaderData[4].course.split('@');

					subHeader
						.find('.sub-title')
						.append(subHeaderData[4].title);

					for(var i = 0; i < course.length; i++) {
						breadcrumbs
							.append('<li>'+ course[i] +'</li>');
					}
				break;
				case 'product_detail_register':
					var course = subHeaderData[5].course.split('@');

					subHeader
						.find('.sub-title')
						.append(subHeaderData[5].title);

					for(var i = 0; i < course.length; i++) {
						breadcrumbs
							.append('<li>'+ course[i] +'</li>');
					}
				break;
				case 'support_category_division':
					var course = subHeaderData[6].course.split('@');

					subHeader
						.find('.sub-title')
						.append(subHeaderData[6].title);

					for(var i = 0; i < course.length; i++) {
						breadcrumbs
							.append('<li>'+ course[i] +'</li>');
					}
				break;
				case 'support_download_list':
					var course = subHeaderData[7].course.split('@');

					subHeader
						.find('.sub-title')
						.append(subHeaderData[7].title);

					for(var i = 0; i < course.length; i++) {
						breadcrumbs
							.append('<li>'+ course[i] +'</li>');
					}
				break;
				case 'support_download_register':
					var course = subHeaderData[8].course.split('@');

					subHeader
						.find('.sub-title')
						.append(subHeaderData[8].title);

					for(var i = 0; i < course.length; i++) {
						breadcrumbs
							.append('<li>'+ course[i] +'</li>');
					}
				break;
				case 'support_partner_list':
					var course = subHeaderData[9].course.split('@');

					subHeader
						.find('.sub-title')
						.append(subHeaderData[9].title);

					for(var i = 0; i < course.length; i++) {
						breadcrumbs
							.append('<li>'+ course[i] +'</li>');
					}
				break;
				case 'support_partner_register':
					var course = subHeaderData[10].course.split('@');

					subHeader
						.find('.sub-title')
						.append(subHeaderData[10].title);

					for(var i = 0; i < course.length; i++) {
						breadcrumbs
							.append('<li>'+ course[i] +'</li>');
					}
				break;
				case 'support_others_list':
					var course = subHeaderData[11].course.split('@');

					subHeader
						.find('.sub-title')
						.append(subHeaderData[11].title);

					for(var i = 0; i < course.length; i++) {
						breadcrumbs
							.append('<li>'+ course[i] +'</li>');
					}
				break;
				case 'support_others_register':
					var course = subHeaderData[12].course.split('@');

					subHeader
						.find('.sub-title')
						.append(subHeaderData[12].title);

					for(var i = 0; i < course.length; i++) {
						breadcrumbs
							.append('<li>'+ course[i] +'</li>');
					}
				break;
				case 'support_source_list':
					var course = subHeaderData[13].course.split('@');

					subHeader
						.find('.sub-title')
						.append(subHeaderData[13].title);

					for(var i = 0; i < course.length; i++) {
						breadcrumbs
							.append('<li>'+ course[i] +'</li>');
					}
				break;
				case 'support_source_register':
					var course = subHeaderData[14].course.split('@');

					subHeader
						.find('.sub-title')
						.append(subHeaderData[14].title);

					for(var i = 0; i < course.length; i++) {
						breadcrumbs
							.append('<li>'+ course[i] +'</li>');
					}
				break;
				case 'news_notice_list':
					var course = subHeaderData[15].course.split('@');

					subHeader
						.find('.sub-title')
						.append(subHeaderData[15].title);

					for(var i = 0; i < course.length; i++) {
						breadcrumbs
							.append('<li>'+ course[i] +'</li>');
					}
				break;
				case 'news_notice_register':
					var course = subHeaderData[16].course.split('@');

					subHeader
						.find('.sub-title')
						.append(subHeaderData[16].title);

					for(var i = 0; i < course.length; i++) {
						breadcrumbs
							.append('<li>'+ course[i] +'</li>');
					}
				break;
				case 'admin_account_list':
					var course = subHeaderData[17].course.split('@');

					subHeader
						.find('.sub-title')
						.append(subHeaderData[17].title);

					for(var i = 0; i < course.length; i++) {
						breadcrumbs
							.append('<li>'+ course[i] +'</li>');
					}
				break;
				case 'admin_account_register':
					var course = subHeaderData[18].course.split('@');

					subHeader
						.find('.sub-title')
						.append(subHeaderData[18].title);

					for(var i = 0; i < course.length; i++) {
						breadcrumbs
							.append('<li>'+ course[i] +'</li>');
					}
				break;
				case 'admin_login_list':
					var course = subHeaderData[19].course.split('@');

					subHeader
						.find('.sub-title')
						.append(subHeaderData[19].title);

					for(var i = 0; i < course.length; i++) {
						breadcrumbs
							.append('<li>'+ course[i] +'</li>');
					}
				break;
				case 'admin_history_list':
					var course = subHeaderData[20].course.split('@');

					subHeader
						.find('.sub-title')
						.append(subHeaderData[20].title);

					for(var i = 0; i < course.length; i++) {
						breadcrumbs
							.append('<li>'+ course[i] +'</li>');
					}
				break;
				default: '데이터가 없습니다.'
			}
		}
	};
	window.util = util;

	var lgInnotek = {
		login: function () {
			var wrap = $('.lginnotek-admin-login'),
			height = $window.height();

			wrap.height(height);

			$(window).resize(function(){
				height = $window.height(),
				wrap.height(height);
			});

			//util.modal.toggle($('#pw-popup'), true);
		},
		main: function () {

		},
		product: function () {
			$('.writing')
				.on('click', '.search', function () {
					util.modal.toggle($('#search-popup'));
					return false;
				});
		},

		init: function () {
			util.modal.init();
			util.datepicker();
			util.gnb();
			util.lnb();
			util.subHeader();

			this.login();
			this.product();
		}
	};

	lgInnotek.init();

});
