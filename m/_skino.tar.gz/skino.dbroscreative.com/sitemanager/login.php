<?php
require_once $_SERVER['DOCUMENT_ROOT'] . "/vendor/autoload.php";

?>
<!DOCTYPE html>
<html>
<head>
	<?php require_once $ROOT_PATH_.'/sitemanager/assets/include/head.php'; ?>
    <script>
    var page = '';
    </script>
</head>
<body>
	<article class="lginnotek-admin-login">
		<section class="login">
			<header>
				<h1><img src="#" alt="SK Innovation"></h1>
				<p><?=$SITE_NAME_?> &amp; 관리자 페이지 입니다.</p>
			</header>
			<div>
				<form id="formLogin" action="/sitemanager/login-proc.php" method="post">
					<input type="text" placeholder="아이디" name="admin_id" id="admin_id">
					<input type="password" placeholder="비밀번호" name="admin_pw" id="admin_pw">
					<!-- <input type="submit" value="LOGIN"> -->
					<a href="#">LOGIN</a>
				</form>
			</div>
			<p class="text">ID&middot;PW를 잊으신 경우 02-563-4482로 문의 주시기바랍니다.</p>
		</section>
		<div class="vertical-section"></div>

		<!-- 비밀번호 설정 팝업 -->
		<!-- 모달 util.modal.toggle($('#pw-popup'), true); 작동 -->
		<aside id="pw-popup" class="modal" tabindex="-1" role="dialog">
			<div class="modal-backdrop"></div>
			<div class="modal-dialog" role="document">
				<div class="modal-content">
					<div class="content-area">
						<h2>비밀번호 설정</h2>
						<form action="" method="">
							<ul class="input-area">
								<li>
									<input type="password" placeholder="이전 패스워드">
								</li>
								<li>
									<input type="password" placeholder="변경 패스워드">
								</li>
								<li>
									<input type="password" placeholder="변경 패스워드 확인">
								</li>
							</ul>
							<a href="#" class="confirm">확인</a>
						</form>
					</div>
				</div>
			</div>
		</aside>
		<script>
			$('#formLogin a').on('click', function(event) {
				event.preventDefault(); 
				// console.log($('#admin_id').val());
				// $('#formLogin').submit();
				$.ajax({
                    async: false,
					//contentType: false,
					// processData: false,
					url: '/sitemanager/login-proc.php',
					type: 'post',
					dataType: 'json',
					data: {
						admin_id : $('#admin_id').val(),
						admin_pw : $('#admin_pw').val()
					},
					success: function (res) {
	                    // 성공시
	                    console.log(res);
	                    if(res.result){
	                        window.location = 'board/notice-list.php';
	                    }else{
		                    alert( res.message );
	                    }
	                },
	                error: function (jqXHR, textStatus, errorThrown) {
	                    console.log('계정 관리 폼 전송 에러');
	                }

				});
			});

			// $(function () {
				// $('#{{id}}'), {{id}}은 모달의 아이디에요

				// 현재 활성화 되어있는 모달 모두 비활성화 후 지정 모달 활성화
				//Util.modal.toggle($('#modal-test'));
				// 현재 활성화 되어있는 모달 모두 비활성화 후 지정 모달 활성화, 비활성화 이벤트는 따로 잡아야 합니다.
				// Util.modal.toggle($('#modal-test'), true);

				// 지정 모달 활성화, 비활성화 이벤트는 따로 잡아야 합니다.
				// Util.modal.show($('#modal-test'));

				// 지정 모달 비활성화
				// Util.modal.hide($('#modal-test'));
				// 모달 비활성화
				// Util.modal.hide();

				// util.modal.toggle($('#pw-popup'), true);

				// });
			//});
		</script>
	</article>
</body>
</html>
