<?php 
require_once __DIR__ . "/../../vendor/autoload.php";

use \Groupidd\Model\ModelBase;
use \Groupidd\Common\CommonFunc;
use \Groupidd\Library\Validator;

$db = new ModelBase();
$PageNo	= isset($_GET["Page"]) ? (int)$_GET["Page"] : 1;	

if($ADMIN_ID_ == "" || $ADMIN_LV_== ""){
	//잘못된 접근
    CommonFunc::jsAlert('잘못된 접근입니다.', "location.href='login.php';");
	exit();
}
if(preg_match("/[^0-9]/",$PageNo)){
	CommonFunc::jsAlert('잘못된 접근입니다.','history.back()');
	exit();
};

//인젝션 검사
$adminInfo = array(
    'admin_id'	 => isset($_SESSION['ADMIN_ID'])? $_SESSION['ADMIN_ID'] : '', 	// 관리자 아이디
    'admin_lv'   => isset($_SESSION['ADMIN_LV'])? $_SESSION['ADMIN_LV'] : '',   // 관리자 이름
	'search'     => isset($_GET['search'])? $_GET['search'] : '', 				// 검색
	'searchText' => isset($_GET['searchText'])? $_GET['searchText'] : '',   	// 검색어
	'level' 	 => isset($_GET['level'])? $_GET['level'] : ''     				// 권한
);

$validator = new Validator($adminInfo);

$data = $validator->data();

$db-> from("ADMIN_MEMBER");
$db->where('del_date',NULL, 'IS');
$db->orderby('seq','DESC');
// $db->mode('test');
if($ADMIN_LV_ != 'L1'){
	$db-> where("admin_id", $ADMIN_ID_);
}

if( $data['search'] != '' && $data['searchText'] != ''){
	
	if ($data['search'] == 'admin_id' || $data['search'] == 'admin_name') {
		//like
		$db-> like($data['search'],$data['searchText']);
	}else{
		echo "잘못된 접근입니다.";
	}
}

// if($data['level'] !== 'A'){
// 	// $db-> where('admin_lv',$data['level']);	
// }

if($data['level']=='L1'){
	$db-> where('admin_lv','L1');
}elseif($data['level']=='L2'){
	$db-> where('admin_lv','L2');
}elseif($data['level']=='L3'){
	$db-> where('admin_lv','L3');
}elseif($data['level']=='A'){
	//모든
}else{
	// ???
}
// 전체개수 query
$countList = $db->getCountAll();
//page
$perPage = 10;
$currentPage = ($PageNo-1) * $perPage; 
$db->select("seq, admin_id, admin_name, admin_lv, department, admin_tel, use_YN", true);
// limit 추가 query
$db->limit($perPage, $currentPage );
$adminLists = $db->getAll();
$db->init();

//history log
$db->from('ADMIN_HISTORY_LOG');
$insert_history = array();
$insert_history['admin_id']= $ADMIN_ID_;
$insert_history['ip']      = $USER_IP_;
$insert_history['depth_1'] = '계정관리';
$insert_history['depth_2'] = '리스트';
$insert_history['work']    = '열람';
$db->insert($insert_history);
$db->init();

?>
<!DOCTYPE html>
<html>
<head>
    <?php require_once $ROOT_PATH_.'/sitemanager/assets/include/head.php'; ?>
	<script type="text/javascript">
		var page = 'admin_account_list';

		function Fn_Search(){
			$('#form1').submit();
		}

		function FnDel(){
	  	  if (confirm('삭제 하시겠습니까?')){
			$('#form2').attr('action', 'delete-proc.php');
			$('#form2').submit();
			}
		}
		function FnAdd(){
			$('#form2').attr('action', 'account-register.php');
			$('#form2').submit();
		}

		jQuery(document).ready(function($) {
			$("#check_all").on('change', function(e){
				var is_checked = $(this)[0].checked;
				$("#form2").find("input[type='checkbox']").not(this).prop('checked', is_checked);
			});
			
		});
	</script>
</head>
<body class="lginnotek-admin-body">
	<article class="lginnotek-admin-wrap">
	
    <?php require_once $ROOT_PATH_.'/sitemanager/assets/include/gnb.php'; ?>

		<div class="container">
    <?php require_once $ROOT_PATH_.'/sitemanager/assets/include/lnb.php'; ?>
			

			<section class="content">
				<div>
					<header id="sub-header" class="top-area">
						<h3 class="sub-title"></h3>
						<div class="breadcrumbs">
							<ol>
							</ol>
						</div>
					</header>

					<div class="sub-area">
						<select name="" id="">
							<option value="">국문</option>
							<option value="">영문</option>
						</select>
					</div>
					<?php 
						if($ADMIN_LV_ == 'L1'){ 
						?>
					<div class="setting">

						<form id="form1" action="" method="get">
							<ul>
								<li class="even">
									<strong>아이디/이름</strong>
									<div>
										<select name="search" id="">
											<option value="admin_id" <?=@$data['search'] == 'admin_id'? 'selected="selected"':''; ?> >아이디</option>
											<option value="admin_name" <?=@$data['search'] == 'admin_name'? 'selected="selected"':''; ?> >이름</option>
										</select>
										<input type="text" name="searchText" value="<?=@$data['searchText']?>">
									</div>
								</li>
								<li class="odd">
									<strong>권한</strong>
									<div>
										<select name="level" id="">
											<option value="A">전체</option>
											<option value="L1" <?=@$data['level'] == 'L1'? 'selected="selected"':''; ?>>슈퍼관리자</option>
											<option value="L2" <?=@$data['level'] == 'L2'? 'selected="selected"':''; ?>>대행사</option>
											<option value="L3" <?=@$data['level'] == 'L3'? 'selected="selected"':''; ?>>개발사</option>
										</select>
									</div>
								</li>
							</ul>
						</form>
						<div class="btn-area">
							<a href="#" class="btn btn-big-gray-1" onclick="Fn_Search();">검색</a>
						</div>
					
					</div>
					<?php 	} 	?>
					<div class="notice-list">
						<form id="form2" action="" method="post">
							<div class="control-1">
								<p>총 <span><?=$countList?></span>건이 검색 되었습니다.</p>
						<?php 
							if($ADMIN_LV_ == 'L1'){ 
						?>
								<div>
									<a href="#" class="btn btn-small2-gray-3" onclick="FnDel();">선택삭제</a>
									<a href="#" class="btn btn-small2-red-1" onclick="FnAdd();">등록</a>
								</div>
							<?php 	} 	?>
							</div>
							<div class="table-style-1">
								<table>
									<colgroup>
										<col width="45">
										<col width="*">
										<col width="100">
										<col width="100">
										<col width="100">
										<col width="150">
										<col width="80">
									</colgroup>
									<thead>
										<tr>
											<th><input type="checkbox" id="check_all"></th>
											<th>아이디</th>
											<th>이름</th>
											<th>권한</th>
											<th>부서</th>
											<th>연락처</th>
											<th>노출여부</th>
										</tr>
									</thead>
									<tbody>
									<?php 
									if($adminLists){
										foreach ($adminLists as $row) {
											echo '<tr>';
											echo '<td><input type="checkbox" name="idx[]" value="'.$row['seq'].'"></td>';
											// echo '<td><input type="checkbox"></td>';
											echo '<td><a href="/sitemanager/admin/account-modify.php?seq='.$row['seq'].'">'.$row['admin_id'].'</a></td>';
											echo '<td><a href="/sitemanager/admin/account-modify.php?seq='.$row['seq'].'">'.$row['admin_name'].'</td>';
											echo '<td>'.$row['admin_lv'].'</td>';
											echo '<td>'.$row['department'].'</td>';
											echo '<td>'.$row['admin_tel'].'</td>';
											echo '<td>'.$row['use_YN'].'</td>';
											echo '</tr>';
										}
									}else{
										echo '<tr><td colspan="14">데이터가 없습니다.</td></tr>';
									}

									?>
									</tbody>
								</table>
							</div>
							<?php 
								if($ADMIN_LV_ == 'L1'){ 
							?>
							<div class="control-1">
								<div>
									<a href="#" class="btn btn-small2-gray-3" onclick="FnDel();">선택삭제</a>
									<a href="#" class="btn btn-small2-red-1" onclick="FnAdd();">등록</a>
								</div>
							</div>
							<?php 	} 	?>
						</form>

						<!-- <div class="page-nav"> -->
							<?php 
							$pageSize = ceil($countList /$perPage);
							$page = CommonFunc::getPaging($PageNo, $perPage, $pageSize,'&search='.$data['search'].'&searchText='.$data['searchText'].'&level='.$data['level']);

							echo $page;

							?>
							<!-- <a href="#" class="first"><span class="sr-only">맨 처음으로</span></a>
							<a href="#" class="prev"><span class="sr-only">이전</span></a>
							<a href="#" class="on">1</a>
							<a href="#">2</a>
							<a href="#">3</a>
							<a href="#">4</a>
							<a href="#">5</a>
							<span>...</span>
							<a href="#">34</a>
							<a href="#" class="next"><span class="sr-only">다음</span></a>
							<a href="#" class="last"><span class="sr-only">맨 마지막으로</span></a> -->
						<!-- </div> -->
					</div>
				</div>
        <?php require_once $ROOT_PATH_.'/sitemanager/assets/include/footer.php'; ?>

			</section>
		</div>
	</article>
</body>
</html>
