<?php
require_once __DIR__ . "/../../vendor/autoload.php";

use \Groupidd\Model\ModelBase;
use \Groupidd\Common\CommonFunc;

if( $ADMIN_LV_!= "L1"){
    CommonFunc::jsAlert('잘못된 접근입니다.',"location.href='account-list.php';");
    exit();
}
if($ADMIN_ID_ == "" || $ADMIN_LV_== ""){
	//잘못된 접근
    CommonFunc::jsAlert('잘못된 접근입니다.', "location.href='login.php';");
	exit();
}

$arrSeq	= $_POST['idx'];

if (!$arrSeq)
{
	CommonFunc::jsAlert("삭제할 데이터가 없습니다.","location.href='account-list.php';");
	exit();
}

if($ADMIN_ID_ == "" || $ADMIN_LV_ == ""){
	//잘못된 접근
	CommonFunc::jsAlert('잘못된 접근입니다.', "location.href='login.php';");
	// Header("Location:/sitemanager/admin/login.php");
	exit();
}

if( $ADMIN_LV_ != "L1"){
	//잘못된 접근
	CommonFunc::jsAlert('잘못된 접근입니다.',"location.href='account-list.php';");
	// Header("Location:/sitemanager/admin/login.php");
	exit();
}

$db = new ModelBase();
$db->from('ADMIN_MEMBER');
$db->whereIn('seq', $arrSeq);

// $db->mode('test');
$db->delete();
$db->init();

	CommonFunc::jsAlert('삭제되었습니다.',"location.href='account-list.php';");

$db->from('ADMIN_HISTORY_LOG');

$insert_history = array();
$insert_history['admin_id']= $ADMIN_ID_;
$insert_history['ip']      = $USER_IP_;
$insert_history['depth_1'] = '계정관리';
$insert_history['depth_2'] = '리스트';
$insert_history['work']    = '삭제';

$db->insert($insert_history);

$db->init();

?>