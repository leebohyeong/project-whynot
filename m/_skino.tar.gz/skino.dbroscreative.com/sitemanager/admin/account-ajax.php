<?php
require_once __DIR__ . "/../../vendor/autoload.php";

// config - namespace
use \Groupidd\Common\CommonFunc;
use \Groupidd\Model\ModelBase;
use \Groupidd\Library\Validator;

$db = new ModelBase();
$work = $_POST['work'];

switch ( $work ) {
	case 'insert':
		$adminInfo = $_POST;
		$adminInfo['admin_pw'] = hash('sha512',$adminInfo['admin_pw']); //비밀번호 암호화
		$validator = new Validator($adminInfo);							//

		$validator->rule('alphaNum','admin_id')->message('아이디 형식은 알파벳과 숫자만 가능합니다');
		$validator->rule('lengthBetween','admin_id',6,12)->message('아이디는 최소6자에서 12자까지 가능합니다.');
		$validator->rule('required', 'admin_name')->message('이름은 필수 입력값입니다.');
		$validator->rule('email', 'email')->message('메일 주소 형식이 잘못되었습니다.');
		// $validator->rule('admin_tel', 'admin_tel')->message('휴대폰 번호 형식이 잘못되었습니다.');

		if($validator->validate()) {        // validation 성공
		    // clear data call (data)
		    $data = $validator->data();
		    $data['admin_tel']= $data['phone1'].$data['phone2'].$data['phone3'];

		    $data['reg_id'] = $ADMIN_ID_;
			unset($data['phone1']);
			unset($data['phone2']);
			unset($data['phone3']);
			unset($data['work']);

			// database 처리
			$db -> from('ADMIN_MEMBER');
			$result = array();
			if ( $db -> insert($data) ) {
				$result['result'] = true;
				$result['message'] = '회원이 등록 되었습니다.';
			} else {
				$result['result'] = false;
				$result['message'] = '회원 등록에 실패하였습니다. 확인 후 다시 시도해 주세요.';
			}

			$db-> init();
			$result['result'] = true;
			echo json_encode($result);
		} else {                            // validation 실패
		    // Errors
		    $result = array();
		    $result['messages'] = $validator->errors();
		    $result['result'] = false;
			echo json_encode($result);
		    
		    exit;
		}


		//history log 
		$db->from('ADMIN_HISTORY_LOG');
		$insert_history = array();
		$insert_history['admin_id']= $ADMIN_ID_;
		$insert_history['ip']      = $USER_IP_;
		$insert_history['depth_1'] = '계정관리';
		$insert_history['depth_2'] = '상세';
		$insert_history['work']    = '등록';
		$db->insert($insert_history);
		$db->init();

		break;

	case 'update':
		// config - request params

		$adminInfo = $_POST;
		$adminInfo['admin_pw'] = hash('sha512',$adminInfo['admin_pw']);

		$validator = new Validator( $adminInfo );
		$data = $validator->data();
		unset($data['work']);
		
		if($data['admin_pw'] == ''){
			unset($data['admin_pw']);
		}

		$data['admin_tel']= $data['phone1'].$data['phone2'].$data['phone3'];
		$data['mod_id']	  = $ADMIN_ID_;
		unset($data['phone1']);
		unset($data['phone2']);
		unset($data['phone3']);
		// database 처리
		$db -> from('ADMIN_MEMBER');
		$db -> where('seq', $data['seq']);

		unset($data['seq']);

		$result = array();
		if ( $db-> update($data) ) {
			$result['result'] = true;
			$result['message'] = '수정되었습니다.';
		} else {
			$result['result'] = false;
			$result['message'] = '정보 수정에 실패하였습니다. 확인 후 다시 시도해 주세요.';
		}

		echo json_encode($data);
		$db-> init();


		//history log 
		$db->from('ADMIN_HISTORY_LOG');
		$insert_history = array();
		$insert_history['admin_id']= $ADMIN_ID_;
		$insert_history['ip']      = $USER_IP_;
		$insert_history['depth_1'] = '계정관리';
		$insert_history['depth_2'] = '상세';
		$insert_history['work']    = '수정';
		$db->insert($insert_history);
		$db->init();

		break;

	case 'check_exist_id':
		$result = array();
		$result['exist'] = true;
		$result['msg'] = '있다';
		echo json_encode($result);
		break;
	default:
		# code...
		break;
}