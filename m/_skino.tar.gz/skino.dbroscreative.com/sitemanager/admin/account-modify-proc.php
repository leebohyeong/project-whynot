<?php
/* ==============================================================================
'   작 성 자 : DEV GROUP - MOJITO
'   날    짜 : 2017-04-18
'   용    도 : 관리자 > 관리자 계정 등록 처리 (account-register-proc.php)
'   Copyright 2017, Group IDD. All rights are reserved
' ================================================================================= */
require_once __DIR__ . "/../../vendor/autoload.php";

// config - namespace
use \Groupidd\Common\CommonFunc;
use \Groupidd\Model\ModelBase;
use \Groupidd\Library\Validator;

// config - request params
$adminInfo			 	= array();
$adminInfo['admin_id'] 	= isset($_POST['admin_id'])? $_POST['admin_id'] : ''; 		// 관리자 아이디
$adminInfo['admin_pw']  = isset($_POST['admin_pw'])? $_POST['admin_pw'] : ''; 		// 관리자 비밀번호
$adminInfo['admin_name']= isset($_POST['admin_name'])? $_POST['admin_name'] : ''; 	// 관리자 이름
$adminInfo['email'] 	= isset($_POST['email'])? $_POST['email'] : '';				// 관리자 이메일
$adminInfo['admin_tel'] = isset($_POST['phone1'])? $_POST['phone1'] : '';			// 관리자 번호
$adminInfo['admin_tel'].= isset($_POST['phone2'])? $_POST['phone2'] : '';			// 관리자 번호
$adminInfo['admin_tel'].= isset($_POST['phone3'])? $_POST['phone3'] : '';			// 관리자 번호
$adminInfo['ip'] 		= isset($_POST['access_ip'])? $_POST['ip'] : '';			// 관리자 아이피
$adminInfo['department']= isset($_POST['department'])? $_POST['department'] : '';	// 관리자 부서
$adminInfo['admin_lv']  = isset($_POST['admin_lv'])? $_POST['admin_lv'] : '';	// 관리자 레벨
$adminInfo['note'] 		= isset($_POST['note'])? $_POST['note'] : '';				// 비고
$adminInfo['use_YN'] 	= isset($_POST['use_YN'])? $_POST['use_YN'] : '';			// 관리자 사용여부
$adminInfo['admin_pw'] 	= hash('sha512',$adminInfo['admin_pw']);					//비밀번로 암호화
$adminInfo['reg_date']	= date('Y-m-d H:i:s');

//validation 검사
$validator = new Validator($adminInfo);
$validator->rule('alphaNum','admin_id')->message('아이디 형식은 알파벳과 숫자만 가능합니다');
$validator->rule('lengthBetween','admin_id',6,12)->message('아이디는 최소6자에서 12자까지 가능합니다.');
$validator->rule('required', 'admin_name')->message('이름은 필수 입력값입니다.');
$validator->rule('email', 'email')->message('메일 주소 형식이 잘못되었습니다.');
$validator->rule('phone', 'phone')->message('휴대폰 번호 형식이 잘못되었습니다.');

$db = new ModelBase();

if($validator->validate()) {       		// validation 성공
    $adminInfo = $validator->data(); 	//데이터 받아오기
    $adminInfo['reg_id'] = $ADMIN_ID_;  //등록한 아이디 컬럼 추기
	// database 처리
	$db -> from('ADMIN_MEMBER');
	$db -> where('seq', $adminInfo['seq']);
	unset($adminInfo['seq']);

	if ( $db -> update($adminInfo) ) {
		CommonFunc::jsAlert('회원 정보가 수정 되었습니다.','window.location="account-list.php";');
	} else {
		CommonFunc::jsAlert('정보 수정에 실패하였습니다. 확인 후 다시 시도해 주세요.','');
	}
	$db-> init();
} else {               					// validation 실패
    $result = array();
	CommonFunc::jsAlert($validator->errors(),'');
    exit;
}

//history log 
$db->from('ADMIN_HISTORY_LOG');
$insert_history = array();
$insert_history['admin_id']= $ADMIN_ID_;
$insert_history['ip']      = $USER_IP_;
$insert_history['depth_1'] = '계정관리';
$insert_history['depth_2'] = '상세';
$insert_history['work']    = '수정';
$db->insert($insert_history);
$db->init();