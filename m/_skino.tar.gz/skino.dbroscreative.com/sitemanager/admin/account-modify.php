<?php 
require_once __DIR__ . "/../../vendor/autoload.php";

use \Groupidd\Model\ModelBase;
use \Groupidd\Common\CommonFunc;

if($ADMIN_ID_ == "" || $ADMIN_LV_== ""){
    CommonFunc::jsAlert('잘못된 접근입니다.', "location.href='login.php';");
    exit();
}

if(preg_match("/[^0-9]/",$_GET['seq'])){
    CommonFunc::jsAlert('잘못된 접근입니다.',"location.href='account-list.php';");
    exit();
};

$seq = isset($_GET['seq'])? $_GET['seq'] : "";

$db = new ModelBase();
$db->select('admin_id, admin_name, admin_tel, department, email, ip, note, admin_lv, use_YN, reg_date');
$db->from('ADMIN_MEMBER');
$db->where('seq',$seq);

$result = $db->getOne();

if($ADMIN_ID_!= $result['admin_id']){
    if( $ADMIN_LV_!= "L1" ){
        CommonFunc::jsAlert('잘못된 접근입니다.',"location.href='account-list.php';");
        exit();
    }
}

$tel = $result['admin_tel'];
$phone1 = substr($tel,0,3);
$phone2 = substr($tel,3,4);
$phone3 = substr($tel,7,4);

$db->init();

//history log 
$db->from('ADMIN_HISTORY_LOG');
$insert_history = array();
$insert_history['admin_id']= $ADMIN_ID_;
$insert_history['ip']      = $USER_IP_;
$insert_history['depth_1'] = '계정관리';
$insert_history['depth_2'] = '상세';
$insert_history['work']    = '열람';

$db->insert($insert_history);

$db->init();



?>

<!DOCTYPE html>
<html>
<head>
    <?php require_once $ROOT_PATH_.'/sitemanager/assets/include/head.php'; ?>
    <script>
        var page = 'admin-account-register';
    </script>
</head>
<body class="lginnotek-admin-body">
<article class="lginnotek-admin-wrap">
    <header class="header">
        <h1>
            <img src="../assets/images/logo_lginnotek.png" alt="lginnotek">
        </h1>
        <p><span><?=$ADMIN_NAME_?></span> 관리자님 좋은 하루 되세요</p>
        <div class="user-menu">
            <a href="#" class="btn btn-small-gray-1">HOME</a>
            <a href="#" class="btn btn-small-gray-2">LOGOUT</a>
        </div>
    </header>

    <nav class="gnb">
        <ul>
        </ul>
    </nav>

    <div class="container">
        <section class="lnb">
            <h2>Product</h2>
            <nav>
                <ul>
                </ul>
            </nav>
        </section>

        <section class="content">
            <div>
                <header id="sub-header" class="top-area">
                    <h3 class="sub-title"></h3>
                    <div class="breadcrumbs">
                        <ol>
                        </ol>
                    </div>
                </header>

                <div class="writing">
                        <form name="form_account_modify" id="form_account_modify" method="post" action="account-ajax.php">
                        <table>
                            <colgroup>
                                <col width="120">
                                <col width="*">
                            </colgroup>
                            <tbody>
                                <input type="hidden" id="work" name="work" value="update">
                                <input type="hidden" id="seq" name="seq" value="<?=$seq?>">
                                <tr>
                                    <th>등록일</th>
                                    <td><?=date("y-m-d",strtotime($result['reg_date']))?></td>
                                </tr>
                                <tr>
                                    <th>아이디</th>
                                    <td>
                                        <?=$result['admin_id']?>
                                    </td>
                                </tr>
                                <tr>
                                    <th>비밀번호</th>
                                    <td>
                                        <input type="password" class="width-200" name="admin_pw" id="admin_pw" minlength="10" >
                                    </td>
                                </tr>
                                <tr>
                                    <th>이름</th>
                                    <td>
                                        <input type="text" class="width-200" name="admin_name" id="admin_name" value="<?=$result['admin_name']?>">
                                    </td>
                                </tr>
                                <tr>
                                    <th>전화번호</th>
                                    <td>
                                        <div class="tel">
                                            <input type="text" class="width-200" name="phone1" id="phone1" maxlength="3" value="<?=$phone1?>">
                                            -
                                            <input type="text" class="width-200" name="phone2" id="phone2" maxlength="4" value="<?=$phone2?>">
                                            -
                                            <input type="text" class="width-200" name="phone3" id="phone3" maxlength="4" value="<?=$phone3?>">
                                        </div>
                                    </td>
                                </tr>
                                <tr>
                                    <th>이메일</th>
                                    <td>
                                        <input type="text" class="width-200" name="email" id="email" value="<?=$result['email']?>">
                                    </td>
                                </tr>
                                <tr>
                                    <th>부서</th>
                                    <td>
                                        <input type="text" class="width-200" name="department" id="department" value="<?=$result['department']?>" >
                                    </td>
                                </tr>
                                <tr>
                                    <th>IP</th>
                                    <td>
                                        <input type="text" class="width-200" name="ip" id="ip" value="<?=$result['ip']?>">
                                    </td>
                                </tr>
                                <tr>
                                    <th>비고</th>
                                    <td>
                                        <textarea cols="30" rows="10" name="note" id="note" ><?=$result['note']?></textarea>
                                    </td>
                                </tr>
                                <tr>
                                    <th>권한</th>
                                    <td>
                                        <div>
                                            <label for="account-super">
                                                <input type="radio" name="admin_lv" id="account-super" value="L1" <?=$result['admin_lv']=='L1'? "checked" : ""?>>
                                                슈퍼관리자
                                            </label>
                                            <label for="account-agency">
                                                <input type="radio" name="admin_lv" id="account-agency" value="L2" <?=$result['admin_lv']=='L2'? "checked" : ""?>>
                                                대행사
                                            </label>
                                            <label for="account-dev">
                                                <input type="radio" name="admin_lv" id="account-dev" value="L3" <?=$result['admin_lv']=='L3'? "checked" : ""?>>
                                                개발사
                                            </label>
                                        </div>
                                    </td>
                                </tr>
                                <tr>
                                    <th>사용여부</th>
                                    <td colspan="3">
                                        <div>
                                            <label for="use-y">
                                                <input type="radio" name="use_YN" id="use-y" checked value="Y" <?=$result['use_YN']=='Y'? "checked" : ""?>>
                                                사용
                                            </label>
                                            <label for="use-n">
                                                <input type="radio" name="use_YN" id="use-n" value="N" <?=$result['use_YN']=='N'? "checked" : ""?>>
                                                미사용
                                            </label>
                                        </div>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                        <div class="control-1">
                            <div>
                                <a href="#" class="btn btn-small2-red-1">초기화</a>
                                <button type="submit" id="formSubmit" class="btn btn-small2-red-1">수정</button>
                                <a href="/sitemanager/admin/account-list.php" class="btn btn-small2-gray-1" >목록</a>
                            </div>
                        </div>
                    </form>
                </div>
            </div>

            <footer>
                <p class="footer">Copyrightⓒ 2017 LG Innotek. All Rights Reserved</p>
            </footer>
        </section>
    </div>
</article>

<script>
    var isValidPassword = (function () {
        var reverseCharacter = function (string) {
                return string.split('').reverse().join('');
            },
            equalsCharacter = function (string) {
                for (var i = 0; i < string.length - 1; i++) {
                    if (string[i] != string[i + 1]) {
                        return false;
                    }
                }

                return true;
            },
            returnResult = function (message) {
                return {
                    message: message,
                    isFail: message ? true : false
                }
            };

        var character = {
                special: '`~!@#$%^&*()_+-=[]{};:\'\"\\<>?,./',
                number: '0123456789',
                lower: 'abcdefghijklmnopqrstuvwxyz',
                upper: 'ABCDEFGHIJKLMNOPQRSTUVWXYZ',
                keyboard1: '~!@#$%^&*()_+',
                keyboard2: '`1234567890-=',
            	keyboard3: 'QWERTYUIOP{}|',
            	keyboard4: 'ASDFGHJKL:\"',
            	keyboard5: 'ZXCVBNM<>?',
            	keyboard6: 'qwertyuiop[]\\',
            	keyboard7: 'asdfghjkl\;\'',
            	keyboard8: 'zxcvbnm,./',
            };

        var checkData = [
            [character.number, '비밀번호는 012처럼 연속된 숫자를 입력할 수 없습니다.'],
            [character.lower, '비밀번호는 abc처럼 연속된 문자를 입력할 수 없습니다.'],
            [character.upper, '비밀번호는 ABC처럼 연속된 문자를 입력할 수 없습니다.'],
            [character.keyboard1, '비밀번호는 ~!@처럼 키보드에 연속된 문자를 입력할 수 없습니다.'],
            [reverseCharacter(character.keyboard1), '비밀번호는 @!~처럼 키보드에 연속된 문자를 입력할 수 없습니다.'],
            [character.keyboard2, '비밀번호는 `12처럼 키보드에 연속된 문자나 숫자를 입력할 수 없습니다.'],
            [reverseCharacter(character.keyboard2), '비밀번호는 21`처럼 키보드에 연속된 문자나 숫자를 입력할 수 없습니다.'],
            [character.keyboard3, '비밀번호는 QWE처럼 키보드에 연속된 문자를 입력할 수 없습니다.'],
            [reverseCharacter(character.keyboard3), '비밀번호는 EWQ처럼 키보드에 연속된 문자를 입력할 수 없습니다.'],
            [character.keyboard4, '비밀번호는 ASD처럼 키보드에 연속된 문자를 입력할 수 없습니다.'],
            [reverseCharacter(character.keyboard4), '비밀번호는 DSA처럼 키보드에 연속된 문자를 입력할 수 없습니다.'],
            [character.keyboard5, '비밀번호는 ZXC처럼 키보드에 연속된 문자를 입력할 수 없습니다.'],
            [reverseCharacter(character.keyboard5), '비밀번호는 CXZ처럼 키보드에 연속된 문자를 입력할 수 없습니다.'],
            [character.keyboard6, '비밀번호는 qwe처럼 키보드에 연속된 문자를 입력할 수 없습니다.'],
            [reverseCharacter(character.keyboard6), '비밀번호는 ewq처럼 키보드에 연속된 문자를 입력할 수 없습니다.'],
            [character.keyboard7, '비밀번호는 asd처럼 키보드에 연속된 문자를 입력할 수 없습니다.'],
            [reverseCharacter(character.keyboard7), '비밀번호는 dsa처럼 키보드에 연속된 문자를 입력할 수 없습니다.'],
            [character.keyboard8, '비밀번호는 zxc처럼 키보드에 연속된 문자를 입력할 수 없습니다.'],
            [reverseCharacter(character.keyboard8), '비밀번호는 cxz처럼 키보드에 연속된 문자를 입력할 수 없습니다.']
        ];

        character.otherMessage = {
            minlength: function (length) {
                return '비밀번호는 ' + length + '문자 이상이여야 합니다.';
            },
            equals: function (length) {
                return '같은 문자 ' + length + '자리가 올수 없습니다.';
            },
        };

        var isValidPassword = function (password) {
            var i, j, tempString;

            // minlength 체크
            var minlength = password.getAttribute('minlength') || password.getAttribute('data-minlength'),
                value = password.value.trim();

            if (minlength && (value.length < minlength)) {
                return returnResult(character.otherMessage.minlength(minlength));
            }


            // 같거나 연속된 문자
            for (i = 0; i < value.length - 2 ; i++) {
                // tempString = password.charAt(i) + password.charAt(i + 1) + password.charAt(i + 2);
                tempString = value.slice(0, 3);

                // 같은 문자
                if (equalsCharacter(tempString)) {
                    return returnResult(character.otherMessage.equals(3));
                }

                // 연속된 문자
                for (j = 0 ; j < checkData.length; j++) {
                    if (checkData[j][0].indexOf(tempString) != -1) {
                        return returnResult(checkData[j][1]);
                    }
                }
            }

            return returnResult();
        };

        return isValidPassword;
    })();

    var regExp = {
            email: /^[0-9a-zA-Z]([-_\.]?[0-9a-zA-Z])*@[0-9a-zA-Z]([-_\.]?[0-9a-zA-Z])*\.[a-zA-Z]{2,3}$/i,
            ip: /^(\d+\.){3}\d+$/,
            number: /\d/g
        };

    var form = $('#form_account_modify'),
        id   = $('#admin_id'),
        pwd  = $('#admin_pw'),
        name = $('#admin_name'),
        phone1 = $('#phone1'),
        phone2 = $('#phone2'),
        phone3 = $('#phone3'),
        email  = $('#email'),
        department = $('#department'),
        accessIp   = $('#ip'),
        bigo  = $('#note'),
        level = $('[name="admin_lv"]'),
        useYN = $('[name="use_YN"]')


    var isValid = function () {

            if ( pwd.val()!=""){
                var checkPassword = isValidPassword(pwd[0]);
                if (checkPassword.isFail) {
                    alert(checkPassword.message);
                    pwd.focus();
                    return false;
                }
            }

            if (!regExp.email.test(email.val())) {
                alert('이메일 형식을 확인해주세요');
                email.focus();
                return false;
            }

            if (!regExp.ip.test(accessIp.val())) {
                alert('IP를 확인해주세요');
                accessIp.focus();
                return false;
            }

            if (!level.is(':checked')) {
                alert('권한을 선택해주세요');
                level[0].focus();
                return false;
            }

            return true;
        },

        checkId = function (fn) {
            $.ajax({
                async: false,
                type: 'post',
                url: '/sitemanager/admin/account-ajax.php',
                data: {
                    work: 'check_exist_id',
                    admin_id: $.trim(id.val)
                },
                success: function (res) {
                    (typeof fn === 'function') && fn(res);
                    console.log( res );
                },
                error: function (jqXHR, textStatus, errorThrown) {
                    console.log('계정 관리 아이디 중복 체크 에러');
                }
            });
        }

    $(document)
        // 전화번호 숫자만
        .on('keyup', '#phone1, #phone2, #phone3', function () {
            var $this = $(this);

            $this.val($this.val().replace(/\D/g, ''));
        })

        // 폼 등록
        .on('submit', '#form_account_modify', function (e) {
            console.log('폼 등록');
            e.preventDefault();
            var form = $(this);
            if (confirm('수정 하시겠습니까?')){

                if (isValid()) {
                    $.ajax({
                        async: false,
                        type: form.attr('method'),
                        url: form.attr('action'),
                        dataType: "json",
                        data: form.serialize(),
                        success: function (res) {
                            // 성공시
                            console.log(res);
                            alert(res.message);
                            if(res.result){
                                window.location = '/sitemanager/admin/account-list.php';
                            }
                        },
                        error: function (jqXHR, textStatus, errorThrown) {
                            console.log('계정 관리 폼 전송 에러');
                        }
                    });
                }
            }
            return false;
        })

</script>
</body>
</html>
