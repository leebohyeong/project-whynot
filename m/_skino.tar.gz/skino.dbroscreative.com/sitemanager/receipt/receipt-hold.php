<?php
require_once $_SERVER['DOCUMENT_ROOT'] . "/vendor/autoload.php";

use \Groupidd\Model\ModelBase;
use \Groupidd\Common\CommonFunc;

$db = new ModelBase();
$action = isset($_GET['action'])?$_GET['action'] : '';
$arrSeq	= $_POST['idx'];

if($action == 'hold'){
	$data['hold_YN']='Y';
}elseif ($action == 'cancel') {
	$data['hold_YN']='N';
}else{
	CommonFunc::jsAlert('정싱적인 경로가 아닙니다.',"location.href='receipt-list.php';");

}

$db->from('RECEIPT');
$db->whereIn('seq', $arrSeq);


if($db->update($data)){
	CommonFunc::jsAlert('보류 처리 되었습니다.',"location.href='receipt-list.php';");
}else{
	CommonFunc::jsAlert('보류 처리에 실패하였습니다. 다시 시도해주세요.',"location.href='receipt-list.php';");
}
