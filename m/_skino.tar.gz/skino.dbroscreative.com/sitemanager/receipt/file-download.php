<?php 
require_once $_SERVER['DOCUMENT_ROOT'] . "/vendor/autoload.php";

use \Groupidd\Model\ModelBase;

$seq = $_GET['seq'];

$db = new ModelBase();
$db->from('RECEIPT_FILE');
$db->where('receipt_seq',2);
$db->select('original_name, hash_name');
$file = $db->getOne();

print_r($file);
die();

// $filename = "chu.jpg"; 
$reail_filename = urldecode($file[0]); //파일 명이 한글일 경우 떄문에 original name
$file_dir = "../file/".$file[1]; //실제 저장되 있는 장소 + 저장된 hash name

// header('Content-Type: application/x-octetstream');
// header('Content-Length: '.filesize($file_dir));
// header('Content-Disposition: attachment; filename='.$reail_filename);
// header('Content-Transfer-Encoding: binary');

// $fp = fopen($file_dir, "r");
// fpassthru($fp);
// fclose($fp);
