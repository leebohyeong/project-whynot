<?php 
require_once $_SERVER['DOCUMENT_ROOT'] . "/vendor/autoload.php";

use \Groupidd\Model\ModelBase;
use \Groupidd\Common\CommonFunc;
use \Groupidd\Library\Validator;

$PageNo	= isset($_GET["Page"]) ? (int)$_GET["Page"] : 1;	

//이부분은 config에 있어도 되지않을까
if ($ADMIN_ID_ == ''){ 
    CommonFunc::jsAlert('잘못된 접근입니다.', "location.href='login.php';");
	exit();
}

if(preg_match("/[^0-9]/",$PageNo)){
	CommonFunc::jsAlert('잘못된 접근입니다.','history.back()');
	exit();
};

//database connect
$db = new ModelBase();

//get으로 넘어오는 데이터 4개! 전체 = A(all) /신청자 = P(pending) / 파일제출 = F(file)/ 보류 = H(hold)
$selected = 'A';
switch ($selected) {
	case 'P':
		$db->where('r.hold_YN','N');
		$db->where('f.original_name',NULL,'is');
		break;
	case 'F':
		$db->where('r.hold_YN','N');
		$db->where('f.original_name',NULL,'is not');
		break;
	case 'H':
		$db->where('r.hold_YN','Y');
		break;
	default:
		
		break;
}

//인젝션 검사
$adminInfo = array(
	'search'     => isset($_GET['search'])? $_GET['search'] : '', 				// 검색
	'searchText' => isset($_GET['searchText'])? $_GET['searchText'] : '',   	// 검색어
);

$validator = new Validator($adminInfo);
$validation_data = $validator->data();

//search 구문 적용
if(!empty($validation_data['search']) && !empty($validation_data['searchText'])){
	$db->like('r.'.$validation_data['search'], $validation_data['searchText']);
}

//database
$db->from('RECEIPT as r');
$db->join('RECEIPT_FILE as f', 'r.seq = f.receipt_seq', 'LEFT');
$countList= $db->getCountAll('r.seq');	//총 갯수 카운트-pagination
$db->orderby('r.seq','DESC');
$db->select('r.seq, r.receipt_members, r.hold_YN, f.original_name',true);
//pagination
$perPage = 15;
$currentPage = ($PageNo-1) * $perPage; 				
$pageSize = ceil($countList /$perPage);
// $pageSize = intval($countList /$perPage);
$db->limit($perPage, $currentPage ); 	// limit 추가 query
//결과 가져오기
$receiptLists = $db->getAll();
$db->init();

?>
<!DOCTYPE html>
<html>
<head>

<?php require_once $ROOT_PATH_.'/sitemanager/assets/include/head.php'; ?>

	<script>
	var search = $('#search');
	var searchText = $('#searchText');


	jQuery(document).ready(function($) {
		$("#check_all").on('change', function(e){
			var is_checked = $(this)[0].checked;
			$("#form2").find("input[type='checkbox']").not(this).prop('checked', is_checked);
		});
		
	});
	function FnHold(){
	  if (confirm('보류 하시겠습니까?')){
			$('#form2').attr('action', 'receipt-hold.php?action=hold');
			$('#form2').submit();
		}
	}
	function FnHoldCancel(){
	  if (confirm('보류 취소 하시겠습니까?')){
			$('#form2').attr('action', 'receipt-hold.php?action=cancel');
			$('#form2').submit();
		}
	}
	</script>
</head>
<body class="lginnotek-admin-body">

	<article class="lginnotek-admin-wrap">
	

	    <?php require_once $ROOT_PATH_.'/sitemanager/assets/include/gnb.php'; ?>

	<div class="container">

	    <?php require_once $ROOT_PATH_.'/sitemanager/assets/include/lnb.php'; ?>
	
	<section class="content">
	<div class="setting">
	
		<form id="form1" action="" method="get">
			<ul>
				<li class="even">
					<div>
						<select name="search" id="search">
							<option value="">전체</option>
							<option value="seq">접수번호</option>
							<option value="receipt_members">참여자</option>
						</select>
						<input type="text" name="searchText" value="">
					</div>
				</li>
			</ul>
			<div class="btn-area">
			<input type="submit" class="btn btn-big-gray-1" value="검색">
			<!-- <a href="#" class="btn btn-big-gray-1" onclick="Fn_Search();">검색</a> -->
			</div>
		</form>
		</div>
		
		<div class="notice-list">
			<form id="form2" action="" method="post">
				<div class="control-1">
					<p>총 <span><?=$countList?></span>건이 검색 되었습니다.</p>

					<div>
						<?php if( $selected == 'H'){ ?>
						<a href="#" class="btn btn-small2-gray-3" onclick="FnHoldCancel();">선택보류취소</a>
						<?php }else{ ?>
						<a href="#" class="btn btn-small2-gray-3" onclick="FnHold();">선택보류이동</a>
						<?php }?>
					</div>
				</div>
				<div class="table-style-1">
					<table>
						<colgroup>
							<col width="45">
							<col width="100">
							<col width="100">
							<col width="300">
							<col width="100">
						</colgroup>
						<thead>
							<tr>
								<th><input type="checkbox" id="check_all"></th>
								<th>no.</th>
								<th>접수번호</th>
								<th>참여자</th>
								<th>분류</th>
							</tr>
						</thead>
						<tbody>
						<?php 
						if($receiptLists){
							foreach ($receiptLists as $row) {
								if($row['hold_YN']=='Y'){
									$status = '보류';
								}elseif($row['original_name']){
									$status = '파일제출';
								}else{
									$status = '신청';
								}
								echo '<tr>';
								echo '<td><input type="checkbox" name="idx[]" value="'.$row['seq'].'"></td>';
								// echo '<td><input type="checkbox"></td>';
								echo '<td>'.$row['seq'].'</td>';
								echo '<td><a href="/sitemanager/receipt/receipt-modify.php?seq='.$row['seq'].'">'.sprintf('%06d',$row['seq']).'</a></td>';
								// echo '<td>'.sprintf('%06d',$row['seq']).'</td>';
								echo '<td>'.$row['receipt_members'].'</td>';
								echo '<td>'.$status.'</td>';
								echo '</tr>';
							}
						}else{
							echo '<tr><td colspan="14">데이터가 없습니다.</td></tr>';
						}

						?>
						</tbody>
					</table>
				</div>
			</form>
			<div class="page-nav">
				<?php 
				$page = CommonFunc::getPaging($PageNo, $perPage, $pageSize,'&search='.$validation_data['search'].'&searchText='.$validation_data['searchText'].'&selected='.$selected);
				echo $page;
				?>
			</div>
			</div>
			<?php require_once $ROOT_PATH_.'/sitemanager/assets/include/footer.php'; ?>
			</section>
		</div>
	</article>
</body>
</html>