<?php 
require_once $_SERVER['DOCUMENT_ROOT'] . "/vendor/autoload.php";
use \Groupidd\Model\ModelBase;
$db = new ModelBase();

//가져올데이터의 seq 번호
$seq = $_GET['seq'];  //번호인지 확인하기

//database
$db->from('RECEIPT as r');
$db->join('RECEIPT_MEMBER as m', 'r.seq = m.receipt_seq');
$db->where('r.seq',$seq);
$db->select('r.seq, r.group_name, r.group_captain, r.group_name, r.mod_date, r.title, r.content, m.name, m.tel, m.tel2, m.email, m.school, m.student_num, m.circle_name, m.circle_captain',true);
$receip = $db->getAll();

?>
<!DOCTYPE html>
<html>
<head>
<?php require_once $ROOT_PATH_.'/sitemanager/assets/include/head.php'; ?>
</head>
<body class="lginnotek-admin-body">
    <article class="lginnotek-admin-wrap">  
    <?php require_once $ROOT_PATH_.'/sitemanager/assets/include/gnb.php'; ?>
        <div class="container">
    <?php require_once $ROOT_PATH_.'/sitemanager/assets/include/lnb.php'; ?>
            <section class="content">
                <div class="writing">
                    <form name="form_modify" id="formt_modify" method="post" action="">

                    <table>
                    	<colgroup>
                            <col width="120">
                            <col width="200">
                            <col width="120">
                            <col width="*">
                        </colgroup>
                    	<tbody>
                    		<tr>
                    			<th>접수번호</th>
                    	        <td><?=$receip[0]['seq']?></td>

                    			<th>접수일시</th>
                    	        <td><?=$receip[0]['mod_date']?></td>
                    		</tr>
                    		
                    	</tbody>
                    </table>
                    <table>
                        <colgroup>
                            <col width="120">
                            <col width="*">
                        </colgroup>
                        <tbody>
                        <?php  if($receip){  
                        		foreach ($receip as $row) {
                        	?>
                            <tr>
                                <th>*성명</th>
                                <td><?=$row['name']?> </td>
                            </tr>
                            <tr>
                                <th>*연락처</th>
                                <td>
                                    <?=$row['tel']?> 
                                </td>
                            </tr>
                            <tr>
                                <th>비상연락처</th>
                                <td><?=$row['tel2']?> </td>
                            </tr>
                            <tr>
                                <th>이메일</th>
                                <td><?=$row['email']?> </td>
                            </tr>
                            <tr>
                                <th>학교</th>
                                <td><?=$row['school']?> </td>
                            </tr>
                            <tr>
                                <th>학번</th>
                                <td><?=$row['student_num']?> </td>
                            </tr>
                            <tr>
                                <th>소속동아리 명</th>
                                <td><?=$row['circle_name']?> </td>
                            </tr>
                            <tr>
                                <th>회장 또는 팀장이름</th>
                                <td><?=$row['circle_captain']?> </td>
                            </tr>
                            <?php  } //foreach  
                            	}else{
                    				echo '<tr><td colspan="14">데이터가 없습니다.</td></tr>';
                    			}//if
                            ?>
                        </tbody>
                    </table>
                    <div class="control-1">
                        <div>
                            <!-- <a href="#" class="btn btn-small2-red-1">초기화</a> -->
                            <a href="#" class="btn btn-small2-red-1">파일 다운로드</a>
                            <a href="#" class="btn btn-small2-red-1">보류</a>
                            <a href="/sitemanager/receipt/receipt-list.php" class="btn btn-small2-gray-1" >목록</a>
                        </div>
                    </div>
                    </form>
                </div>
            </section>
        </div>
    </article>
</body>
</html>
