<?php
require_once $_SERVER['DOCUMENT_ROOT'] . "/vendor/autoload.php";

use Groupidd\Model\ModelBase as DB;
use Groupidd\Common\CommonFunc as FN;

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

$db = new DB();
$db->beginTransaction();

$team = array();
// $team['']
$team['group_name'] = $_POST['group_name'];
$team['group_captain'] = $_POST['group_captain'];
$team['group_tel'] = $_POST['group_tel'];
$team['receipt_pw'] = isset($_POST['pw']) ? $_POST['pw'] : 'pw';
$team['receipt_members'] = "members, members";

// 테이블 지정
$db->table('RECEIPT');
$result = $db->insert( $team );
if( !$result ) {
	$db->rollBack();
	echo 'rollBack';
	die();
}

$usersTemp = array();
$usersTemp['name'] = $_POST['name'];
$usersTemp['tel'] = $_POST['tel'];
$usersTemp['tel2'] = $_POST['tel2'];
$usersTemp['email'] = $_POST['email'];
$usersTemp['school'] = $_POST['school'];
$usersTemp['student_num'] = $_POST['student_num'];
$usersTemp['circle_name'] = $_POST['circle_name'];
$usersTemp['circle_captain'] = $_POST['circle_captain'];
// $usersTemp['receipt_pw_confirm'] = $_POST['receipt_pw_confirm'];
// $usersTemp['receipt_num'][] = $db->lastInsertId();
// $usersTemp['receipt_num'][] = $db->lastInsertId();

$users = FN::multipleFormReorder($usersTemp);

$teamSeq = $db->lastInsertId();

// 다른 데이터를 넣기 위해 DB객체 초기화
$db->init();

// 다른 테이블 설정
$db->table('RECEIPT_MEMBER');
// 세 번째 파라미터로 참조할 컬럼 지정
$result = $db->insert_batch($users, $teamSeq, 'receipt_seq');

if ( $result ) {
	$reulst = $db->executeTransaction();
	// echo 'commit <br>';
} else {
	$reulst = $db->rollBack();
	// echo 'rollBack <br>';
}
$db->close();
?>