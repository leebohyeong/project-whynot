<?php
require_once $_SERVER['DOCUMENT_ROOT'] . "/vendor/autoload.php";

?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title></title>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
	<style>
	</style>
</head>
<body>
	<div class="container">
		<form action="/receipt/receipt-proc.php" method="POST" id="form-receipt">
			<!-- <input type="text" name="receipt_num"> -->
			<div id="form-team">
				<div class="form-group row">
					<label for="group_name" class="col-xs-2">group_name</label>
					<!-- <input type="text" name="group_name" class="col-xs-6"> -->
					<input type="text" name="group_name" class="col-xs-6" value="group_name">
				</div>
				<div class="form-group row">
					<label for="group_captain" class="col-xs-2">group_captain</label>
					<!-- <input type="text" name="group_captain" class="col-xs-6"> -->
					<input type="text" name="group_captain" class="col-xs-6" value="group_captain">
				</div>
				<div class="form-group row">
					<label for="group_tel" class="col-xs-2">group_tel</label>
					<!-- <input type="text" name="group_tel" class="col-xs-6"> -->
					<input type="text" name="group_tel" class="col-xs-6" value="group_tel">
				</div>
				<!-- <input type="text" name="receipt_members"> -->
			</div>
			<hr>
			<div class="members">
				<div class="row">
					<div class="col col-xs-2">
						<p>참여자</p>
						<a href="#" class="btn btn-primary btn-sm btn-add-user">참여자 추가</a>
					</div>
					<div class="col col-xs-10">
						<div class="form-group row">
							<label for="name" class="col-xs-3">name</label>
							<!-- <input type="text" name="name" class="col-xs-6"> -->
							<input type="text" name="name[]" class="col-xs-6" value="이혁">
						</div>
						<div class="form-group row">
							<label for="tel" class="col-xs-3">tel</label>
							<!-- <input type="text" name="tel" class="col-xs-6"> -->
							<input type="text" name="tel[]" class="col-xs-6" value="01028016532">
						</div>
						<div class="form-group row">
							<label for="tel2" class="col-xs-3">tel2</label>
							<!-- <input type="text" name="tel2" class="col-xs-6"> -->
							<input type="text" name="tel2[]" class="col-xs-6" value="07046594367">
						</div>
						<div class="form-group row">
							<label for="email" class="col-xs-3">email</label>
							<!-- <input type="text" name="email" class="col-xs-6"> -->
							<input type="text" name="email[]" class="col-xs-6" value="hyuk.lee@groupidd.com">
						</div>
						<div class="form-group row">
							<label for="school" class="col-xs-3">school</label>
							<!-- <input type="text" name="school" class="col-xs-6"> -->
							<input type="text" name="school[]" class="col-xs-6" value="groupidd">
						</div>
						<div class="form-group row">
							<label for="student_num" class="col-xs-3">student_num</label>
							<!-- <input type="text" name="student_num" class="col-xs-6"> -->
							<input type="text" name="student_num[]" class="col-xs-6" value="20140501">
						</div>
						<div class="form-group row">
							<label for="circle_name" class="col-xs-3">circle_name</label>
							<!-- <input type="text" name="circle_name" class="col-xs-6"> -->
							<input type="text" name="circle_name[]" class="col-xs-6" value="개발팀">
						</div>
						<div class="form-group row">
							<label for="circle_captain" class="col-xs-3">circle_captain</label>
							<!-- <input type="text" name="circle_captain" class="col-xs-6"> -->
							<input type="text" name="circle_captain[]" class="col-xs-6" value="정태운">
						</div>
						<!-- <input type="text" name="receipt_num"> -->
					</div>
				</div>
			</div>
			<div id="form-password">
				<div class="form-group row">
					<label for="receipt_pw" class="col-xs-2">비밀번호</label>
					<input type="password" name="receipt_pw" class="col-xs-6">
				</div>
				<div class="form-group row">
					<label for="receipt_pw" class="col-xs-2">비밀번호 확인</label>
					<input type="password" name="receipt_pw_confirm" class="col-xs-6">
				</div>
			</div>
			<div class="form-group row">
				<button class="btn btn-info">다음</button>				
			</div>
		</form>
	</div>
	<script src="https://code.jquery.com/jquery-1.12.4.min.js" type="text/javascript" charset="utf-8"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" type="text/javascript" charset="utf-8"></script>
	<script>
		jQuery(document).ready(function($) {
			$('#form-receipt').on('click', '.btn-add-user', function(event) {
				event.preventDefault();
				if ( $('.members > .row').size() < 4 ) {
					var userGroup = $('.members .row:eq(0)').clone();
					$('.members').append(userGroup);
					console.log(userGroup);
				}
			});
		});
	</script>
</body>
</html>