<?php
require_once $_SERVER['DOCUMENT_ROOT'] . "/vendor/autoload.php";

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

//database connect
use \Groupidd\Model\ModelBase;
$db = new ModelBase();

print_r($_FILES);


//접수번호 , 파일 첨부 , 기획의도, 작품제목
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title></title>
	<link rel="stylesheet" href="">
</head>
<body>
	<form action="" method="post" enctype="multipart/form-data">
		<input type="file" name="upload_file" id="upload_file">
		<input type="submit">
	</form>
</body>
</html>