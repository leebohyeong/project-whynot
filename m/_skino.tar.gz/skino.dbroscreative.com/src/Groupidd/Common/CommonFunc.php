<?php
namespace Groupidd\Common;

class CommonFunc {

    // 자바스크립트(alert & location)
    public static function jsAlert($msg = "", $action){
        $jsStr =	"<script>" . chr(13);

    	if( $msg != "" ){
    		$jsStr = $jsStr ."alert('" . $msg . "');".chr(13);
    	}

    	$jsStr = $jsStr.$action.chr(13);
    	$jsStr = $jsStr."</script>".chr(13);
    	echo $jsStr;
    }

    // 자바스크립트(confirm box & location)
    public static function jsConfirm($msg, $action){
        $jsStr = "<script>".chr(13);
    	$jsStr = $jsStr."if(confirm('{$msg}')==true){".chr(13);
    	$jsStr = $jsStr.$action.chr(13);
    	$jsStr = $jsStr."}else{".chr(13);
        $jsStr = $jsStr."history.go(-1);".chr(13);
        $jsStr = $jsStr."}</script>".chr(13);

        echo $jsStr;
    }

    // select box value compare
    public static function getSelected($strValue1, $strValue2){
    	if(strtoupper(trim($strValue1)) == strtoupper(trim($strValue2))){
    		return "selected";
    	}
    }

    // check box value compare
    public static function getChecked($strValue1, $strValue2){
    	if(strtoupper(trim($strValue1)) == strtoupper(trim($strValue2))){
    		return "checked";
    	}
    }

    // XSS & Injection
    public static function verifyValue($str){
        $str = ($str != "") ? trim($str):"";

    	$str = str_replace("<object", "<x-object", $str);
    	$str = str_replace("</object", "</x-object", $str);
    	$str = str_replace("<style", "<x-style", $str);
    	$str = str_replace("</style", "</x-style", $str);
    	$str = str_replace("<script", "<x-script", $str);
    	$str = str_replace("</script", "</x-script", $str);
    	$str = str_replace("<embed", "<x-embed", $str);
    	$str = str_replace("</embed", "</x-embed", $str);

    //	$str = str_replace("\"", "˝", $str);
    //	$str = str_replace("/*", "", $str);
    //	$str = str_replace("*/", "", $str);

    	$str = str_replace("IcxMarcos", "", $str);
    	$str = str_replace("gb2312", "", $str);
    	$str = str_replace("encode", "", $str);
    	$str = str_replace("session", "", $str);
    	$str = str_replace("request", "", $str);

    	$str = str_replace("and ","", $str);
    	$str = str_replace("or ","", $str);
    	$str = str_replace("delete ","", $str);
    	$str = str_replace("drop ","", $str);
    	$str = str_replace("insert ","", $str);
    	$str = str_replace("select ","", $str);
    	$str = str_replace("union ","", $str);
    	$str = str_replace("update ","", $str);

    	$str = str_replace("xp_cmdshell ","", $str);
    	$str = str_replace("xp_dirtree ","", $str);
    	$str = str_replace("xp_regread ","", $str);
    	$str = str_replace("exec ","", $str);
    	$str = str_replace("Openrowset ","", $str);
    	$str = str_replace("sp_","", $str);

        /*
        if(preg_match('/\s/', $str))
            exit('attack'); // no whitespaces
        if(preg_match('/[\'"]/', $str))
            exit('attack'); // no quotes
        if(preg_match('/[\/\\\\]/', $str))
            exit('attack'); // no slashes
        if(preg_match('/(and|or|null|not)/i', $str))
            exit('attack'); // no sqli boolean keywords
        if(preg_match('/(union|select|from|where)/i', $str))
            exit('attack'); // no sqli select keywords
        if(preg_match('/(group|order|having|limit)/i', $str))
            exit('attack'); //  no sqli select keywords
        if(preg_match('/(into|file|case)/i', $str))
            exit('attack'); // no file operation
        if(preg_match('/(benchmark|sleep)/i', $str))
            exit('attack'); // no timing
        */

    	//$pattern = "/\"|'|:|-|<|>|%|\(|\)|\+|;|#|&/";
    	$pattern = "/\"|'|:|--|<|>|%|\(|\)|\+|;|&/";

    	$lastTxt	= preg_replace_callback($pattern, 'self::replacePattern', $str);
        /*
        $lastTxt	= preg_replace_callback($pattern, function ($matches){
            switch ($matches[0]) {
        		case '"': return "&quot;"; break;
        		case "'": return "´"; break;
        		case ":": return "&#58;"; break;
        		case "--": return "&#45;&#45;"; break;
        		case "<": return "&lt;"; break;
        		case ">": return "&gt;"; break;
        		case "%": return "&#37;"; break;
        		case "(": return "&#40;"; break;
        		case ")": return "&#41;"; break;
        		case "+": return "&#43;"; break;
        		case ";": return "&#59;"; break;
        		case "#": return "&#35;"; break;
        		case "&": return "&amp;"; break;
            }
        }, $str);
        */
    	return $lastTxt;
    }

    // injection pattern
    private static function replacePattern($matches){
        switch ($matches[0]) {
    		case '"': return "&quot;"; break;
    		case "'": return "´"; break;
    		case ":": return "&#58;"; break;
    		case "--": return "&#45;&#45;"; break;
    		case "<": return "&lt;"; break;
    		case ">": return "&gt;"; break;
    		case "%": return "&#37;"; break;
    		case "(": return "&#40;"; break;
    		case ")": return "&#41;"; break;
    		case "+": return "&#43;"; break;
    		case ";": return "&#59;"; break;
    		case "#": return "&#35;"; break;
    		case "&": return "&amp;"; break;
    	}
    }

    // replace htmlcode
    public static function replaceHtmlDecode($str, $script = ""){
    	//기존 치환문자 땜에 넣어놨음.
    	$str = str_replace("&amp;lt;", "<", $str);
    	$str = str_replace("&amp;gt;", ">", $str);

    	$str = str_replace("&amp;", "&", $str);

    	$str = str_replace("&quot;", '"', $str);
    	$str = str_replace("´", "'", $str);
    	$str = str_replace("˝", "\"", $str);
    	$str = str_replace("&#58;", ":", $str);
    	$str = str_replace("&#59;", ";", $str);
    	$str = str_replace("&#45;&#45;", "--", $str);
    	$str = str_replace("&lt;", "<", $str);
    	$str = str_replace("&gt;", ">", $str);
    	$str = str_replace("&#37;", "%", $str);
    	$str = str_replace("&#40;", "(", $str);
    	$str = str_replace("&#41;", ")", $str);
    	$str = str_replace("&#43;", "+", $str);
    	$str = str_replace("&#59;", ";", $str);
    	$str = str_replace("&#35;", "#", $str);
    	$str = str_replace("&amp;", "&", $str);


    	if ($script == "script"){
    		$str = str_replace("<x-style", "<style", $str);
    		$str = str_replace("</x-style", "</style", $str);
    	}

    	return $str;
    }

    // remove Tag
    public static function stripTag($str){
    	$str	= strip_tags($str);
    	$str	= str_replace("&nbsp;"," ",$str);
    	return $str;
    }

    // string reduction
    public static function cutUtf8Str($str,$len,$tail=''){
    	$len = $len*2;
    	$c = substr(str_pad(decbin(ord($str{$len})),8,'0',STR_PAD_LEFT),0,2);
    	if ($c == '10')
    	for (;$c != '11' && $c{0} == 1;$c = substr(str_pad(decbin(ord($str{--$len})),8,'0',STR_PAD_LEFT),0,2));

    	return substr($str,0,$len) . (strlen($str)-strlen($tail) >= $len ? $tail : '');
    }


    // paging (Page:현재페이지, pageSize : 페이지 사이즈, totalPage:페이지 전체갯수, param : 검색파라미터, pagingMax : 한페이지 페이지네이션 개수)
    public static function getPaging($Page,$PageSize,$TotalPage,$Param, $pagingMax = ""){
    	if ($TotalPage > 1){
    		$intBlockPage;
    		$i;

    		if(!$pagingMax) $pagingMax = 10;	//노출 페이지 수
    		$intBlockPage=(int)(($Page-1)/$pagingMax)*$pagingMax+1;
            $prev = $Page-1;
            $next = $Page+1;

    		$sRtnDiv = "<nav class=\"pagination\">".chr(13);
    		$sRtnDiv = $sRtnDiv . "<ul>".chr(13);

    		if($intBlockPage == 1){
    			//$sRtnDiv = $sRtnDiv."<li><a href='#' class=\"bu prev\">◀</a></li>".chr(13);
                if($Page>1 && $Page<=$TotalPage){
                    $sRtnDiv = $sRtnDiv."<li><a href='?page=".$prev.$Param."' class=\"bu prev\"><span>이전</span></a></li>".chr(13);
                }
    		}else{
                //$sRtnDiv = $sRtnDiv."<li><a href='?Page=".($intBlockPage-$pagingMax).$Param."' class=\"prev\">◀</a></li>".chr(13);
    			$sRtnDiv = $sRtnDiv."<li><a href='?page=".$prev.$Param."' class=\"bu prev\"><span>이전</span></a></li>".chr(13);
    		}

    		$i = 1;

    		do
    		{
    			if ((int)$intBlockPage == (int)$Page){
    				$sRtnDiv = $sRtnDiv."<li><strong>".$intBlockPage."</strong></li>".chr(13);
    			}else{
    				$sRtnDiv = $sRtnDiv."<li><a href='?page=".$intBlockPage.$Param."'>".$intBlockPage."</a></li>".chr(13);
    			}

    		  $intBlockPage=$intBlockPage + 1;
    		  $i = $i+1;
    		}
    		while($i  <= $pagingMax && $intBlockPage <= $TotalPage);


    		if($intBlockPage > $TotalPage){
                if($Page>=1 && $Page<$TotalPage){
                    $sRtnDiv = $sRtnDiv."<li><a href='?page=".$next.$Param."' class=\"bu next\"><span>다음</span></a></li>".chr(13);
                }
    			//$sRtnDiv = $sRtnDiv."	<li><a href='#' class=\"next\">▶</a></li>".chr(13);
    		}else{
                $sRtnDiv = $sRtnDiv."<li><a href='?page=".$next.$Param."' class=\"bu next\"><span>다음</span></a></li>".chr(13);
    			//$sRtnDiv = $sRtnDiv."	<li><a href='?Page=".$intBlockPage.$Param."' class=\"next\">▶</a></li>".chr(13);
    		}

    		$sRtnDiv = $sRtnDiv."</ul>".chr(13);
    		$sRtnDiv = $sRtnDiv."</nav>".chr(13);
    	}
    	return $sRtnDiv;
    }

    // ajax paging (Page:현재페이지, pageSize : 페이지 사이즈, totalPage:페이지 전체갯수, param : 검색파라미터, pagingMax : 한페이지 페이지네이션 개수)
    public static function getPagingAjax($Page,$PageSize,$TotalPage,$Param, $pagingMax = ""){
    	if ($TotalPage > 1){
    		$intBlockPage;
    		$i;

    		if(!$pagingMax) $pagingMax = 10;	//노출 페이지 수
    		$intBlockPage=(int)(($Page-1)/$pagingMax)*$pagingMax+1;


    		$sRtnDiv = "		<nav class=\"pagination\">".chr(13);
    		$sRtnDiv = $sRtnDiv . "			<ul>".chr(13);

    		if($intBlockPage == 1){
    			$sRtnDiv = $sRtnDiv."	<li class=\"bu prev\"><a href='#'>◀</a>".chr(13);
    		}else{
    			$sRtnDiv = $sRtnDiv."	<li class=\"bu prev\"><a href='#none' data-page=\"".($intBlockPage-$pagingMax)."\">◀</a>".chr(13);
    		}

    		$i = 1;

    		do
    		{
    			if ((int)$intBlockPage == (int)$Page){
    				$sRtnDiv = $sRtnDiv."<li><strong>".$intBlockPage."</strong></li>".chr(13);
    			}else{
    				$sRtnDiv = $sRtnDiv."<li><a href='#none' data-page='".$intBlockPage."'>".$intBlockPage."</a></li>".chr(13);
    			}

    		  $intBlockPage=$intBlockPage + 1;
    		  $i = $i+1;
    		}
    		while($i  <= $pagingMax && $intBlockPage <= $TotalPage);


    		if($intBlockPage > $TotalPage){
    			$sRtnDiv = $sRtnDiv."	<li class=\"bu next\"><a href='#'>▶</a>".chr(13);
    		}else{
    			$sRtnDiv = $sRtnDiv."	<li class=\"bu next\"><a href='#' data-page='".$intBlockPage."'>▶</a>".chr(13);
    		}

    		$sRtnDiv = $sRtnDiv."		</ul>".chr(13);
    		$sRtnDiv = $sRtnDiv."	</nav>".chr(13);
    	}
    	return $sRtnDiv;
    }

    // fileupload function (jpeg|jpg|gif|png) , filetype:image/doc
    public static function uploadFile($upfile_ipname, $upfile_dir, $max_filesize = "", $filetype = "", $ori_filename = false){
        if ($max_filesize == "")
    		$max_filesize = 1024*1024*5;		//최대파일 업로드(5MB 제한)

    	$upfile_temp	= $_FILES[$upfile_ipname]['tmp_name'];
    	$upfile_name	= $_FILES[$upfile_ipname]['name'];
    	$file_size		= $_FILES[$upfile_ipname]['size'];
    	$file_type		= $_FILES[$upfile_ipname]['type'];

    	if (is_uploaded_file($upfile_temp)){
    		if($file_size > $max_filesize) {
    			echo 'filesize is over. (size:$file_size)';
    			exit();
    		}

    		$current_file=$upfile_name;

    		$upfile_name=substr($current_file,0,strrpos($current_file,"."));
    		$file_ex=strtolower(strrchr($current_file,"."));

    		//확장자 검사
    		if ($filetype == "") $filetype = "image";
    		if ($filetype == "doc"){
    			if (!(preg_match("/doc|docx|ppt|pptx|xls|xlsx|xml/i", $file_ex))) {
    				echo 'filetype is wrong.';
    				exit();
    			}
    		}else if ($filetype == "image"){
    			if (!(preg_match("/jpeg|jpg|gif|png/i", $file_ex))) {
    				echo 'filetype is wrong.';
    				exit();
    			}
    		}else if ($filetype == "all"){
    			if (!(preg_match("/doc|docx|ppt|pptx|xls|xlsx|zip|jpeg|jpg|gif|png/i", $file_ex))) {
    				echo 'filetype is wrong.';
    				exit();
    			}
    		}

    		//중복파일 검사 - 중복된 파일이 w있을경우 인덱스를 붙인다.
    		$new_file_name .= mktime(date("H"),date("i"),date("s"),date("d"),date("m"),date("y"));
    		if ($ori_filename == true){
    			$new_file_name .=  "__" . $upfile_name;
    		}

    		$fn_t=$new_file_name;
    		$fileindex=0;

    		while(file_exists(DIR_PATH.$upfile_dir . "/" . $fn_t . $file_ex)){
    			$fn_t=$fn_t . "(" . $fileindex . ")";
    			$fileindex++;
    		};

    		$realfile = $fn_t. $file_ex; //실제파일명
    		$dest = DIR_PATH.$upfile_dir."/".$realfile;
    		$srcf = $upfile_temp;
    		if(!move_uploaded_file($srcf,$dest));

    		return $realfile;

    	}else{
    		return "";
    	}
    }

    public static function multipleFormReorder($array)
    {
        $newArray = [];
        foreach ($array as $key => $tempArray) {
            $index = 0;
            foreach ($tempArray as $newKey => $value) {
                # code...
                $newArray[$index][$key] = $value;
                $index++;
            }
        }

        return $newArray;
    }
}
