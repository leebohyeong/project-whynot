<?php
namespace Groupidd\Common;

class Setting {
    private static $instance;
    private $settings;

    private function __construct($envtype){
        $this->settings = parse_ini_file(__DIR__.'../../property.'.$envtype.'.php', TRUE);
    }

    public static function getInstance($envtype){
        if (!isset(self::$instance)) {
            self::$instance = new Setting($envtype);
        }
        return self::$instance;
    }

    public function __get($setting){
        if (array_key_exists($setting, $this->settings)){
            return $this->settings[$setting];
        } else {
            foreach ($this->settings as $section) {
                # code...
                if (array_key_exists($setting, $search)){
                    return $section[$setting];
                }
            }
        }
    }
}
