;<?php return;?>
; REAL 환경입니다. 
[SITE]
SITE_NAME       = "SK 이노베이션"
OG_KEYWORDS     = "SK 이노베이션"
OG_TITLE        = "[SK 이노베이션]"
OG_DESCRIPTION  = "설명문구"
OG_IMAGE        = "/assets/images/logo.png"

[DOMAIN]
HOST_HTTP       = "http://summer.dbroscreative.com"
HOST_SSL        = "https://summer.dbroscreative.com"
HOST_HTTP_M     = "http://summer.dbroscreative.com/m"

[DB]
DB_HOST         = "210.205.6.157"
DB_USER         = "ebizdev"
DB_PASSWORD     = "dlqlwmWkd1!"
DB_NAME         = "DB_FHKVISIT_2016"
DB_ENCODING     = "utf8"

[API]
API_FACEBOOK    = ""
API_DAUM        = ""
API_KAKAO       = ""
