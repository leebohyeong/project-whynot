<?php
/**
 * Database 객체
 *
 * 객체를 생성하고 from 명령어로 테이블을 연결합니다.
 * insert, update, delete 명령어로 쿼리문을 실행합니다.
 *
 * init() 으로 초기화 합니다.
 * close() 도 최기화 합니다. (연결도 끊고 PDO 객체도 소멸합니다.)
 *
 * 작성일: 2017-04-27
 * 수정일: 2017-04-27
 *
 **/
namespace Groupidd\Model;

use PDO;
use PDOException;
use Groupidd\Common\Log;
use Groupidd\Common\Setting;

class ModelBase
{
  protected $setting;
  protected $pdo;
  protected $user;
  protected $pass;
  protected $mode;
  protected $select;
  protected $from;
  protected $table;
  protected $join;
  protected $where;
  protected $whereIn;
  protected $orderby;
  protected $limit;
  protected $whereParam = array();
  private $log;

  protected static $instance = null;

  function __construct()
  {
    $this->setting    = Setting::getInstance('dev');     // 개발환경:dev, 운영환경 : real
    $this->log        = new Log();
    $this->connect();
  }

  /**
   * @param
   *
   * @return void
   */
  public function connect()
  {
    $host      = $this->setting->DB['DB_HOST'];
    $user      = $this->setting->DB['DB_USER'];
    $pass      = $this->setting->DB['DB_PASSWORD'];
    $db        = $this->setting->DB['DB_NAME'];
    $charset   = $this->setting->DB['DB_ENCODING'];
    $dsn       = "mysql:host=$host;dbname=$db;charset=$charset";
    try {
      $this->pdo = new PDO($dsn, $user , $pass , array(
        PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8"
      ));
      $this->pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
      $this->pdo->setAttribute(PDO::ATTR_EMULATE_PREPARES, false);
    }
    catch (PDOException $e) {
      $this->exceptionLog( $e->getMessage() );
    }

  }

  /**
   * @param string $mode "test"라고 입력하면 쿼리를 실행하지 않는다
   *
   * @return void
   */
  public function mode($mode)
  {
    $available = array('test', 'public');
    if ( !in_array($mode, $available) ) {
        return false;
    }
    $this->mode = $mode;
  }

  /**
   * SELECT 쿼리를 위한 내부함수
   * @param
   *
   * @return void
   */
  protected function _get()
  {
    if ( is_null($this->select) ) {
        $this->select = "SELECT * ";
    }

    $sql = $this->select.$this->from;
    if ( $this->join ) {
        $sql .= $this->join;
    }
    if ( $this->where ) {
        $sql .= $this->where;
    }
    if ( $this->orderby ) {
        $sql .= $this->orderby;
    }
    if ( $this->limit ) {
        $sql .= $this->limit;
    }
    return $sql;
  }

  /**
   * @param PDOStatement $stmt
   * PDO prepare를 위한 parameter 값 연결
   *
   * @return void
   */
  private function bindParams($stmt)
  {
    foreach ($this->whereParam as $key => $value) {
        $type = PDO::PARAM_STR;
        switch ($value) {
          case is_int($value):
              $type = PDO::PARAM_INT;
              break;
          case is_bool($value):
              $type = PDO::PARAM_INT;
              break;
          case is_null($value):
              $type = PDO::PARAM_NULL;
              break;
        }
        $stmt->bindValue(":{$key}", $value, $type);
    }
  }

  /**
   * 쿼리문 실행
   *
   * @param string $sql
   * 쿼리문(내부함수에서 생성된다)
   *
   * @return array | int SELECT 일 경우 array, insert/update/delete 일 경우 int
   */
  protected function run($sql)
  {
    try {
      $stmt = $this->pdo->prepare($sql);
    } catch( PDOException $e ) {
      $result = $this->exceptionLog($e->getMessage());
    }
    $isSelect = strpos( $stmt->queryString, 'SELECT' );

    $this->bindParams($stmt);


    if ( $this->mode == "test" ) {
        return $stmt->debugDumpParams();
    }

    try {
        $result = $stmt->execute();
        if ( $isSelect !== false ) {
            $result = $stmt;
        }
    } catch(PDOException $e) {
      $this->exceptionLog($e->getMessage(), $sql);
      return false;
    }

    return $result;
  }

  /**
   * 여러 행의 결과를 가져올 때 사용
   * @param
   *
   * @return array
   */
  public function getAll()
  {
    $sql = $this->_get();

    $result = $this->run($sql);

    if ( is_string($result) ) {
        return $result;
    }

    return $result->fetchAll();
  }

  /**
   * 한 행의 결과를 가져올 때 사용
   * @param
   *
   * @return array
   */
  public function getOne()
  {
    $sql = $this->_get();

    $result = $this->run($sql);

    if ( is_string($result) ) {
        return $result;
    }
    return $result->fetch();
  }


  /**
   * 준비된 쿼리의 전체행의 개수를 가져올 때 사용
   *
   * @param string $seq
   * 기준이 되는 컬럼의 이름 (기본값 seq)
   *
   * @return int
   */
  public function getCountAll($seq = 'seq')
  {
    $this->select = "SELECT COUNT($seq)";
    $sql = $this->_get();

    $result = $this->run($sql);

    if ( is_string($result) ) {
        return $result;
    }
    return $result->fetchColumn();
  }

  /**
   * @param string $select
   * SELECT 컬럼. ,로 붙여서 줄 수 있다
   * 반복해서 실행하면 콤마(,)가 자동으로 붙는다.
   * @param boolean $replace
   * true 일 경우 SELECT 구문 초기화
   *
   * @return void
   */
  public function select($select='', $replace = false)
  {
    if ( is_null($this->select) || $replace ) {
        $this->select = "SELECT {$select}";
    } else {
        $this->select .= ", {$select}";
    }
  }

  /**
   * from 이지만 insert/update/delete에도 쓰임
   *
   * @param string $from
   * 테이블 이름
   *
   * @return void
   */
  public function table($table='')
  {
    $this->from($table);
  }

  /**
   * from 이지만 insert/update/delete에도 쓰임
   *
   * @param string $from
   * 테이블 이름
   *
   * @return void
   */
  public function from($from='')
  {
    $this->table = "{$from}";
    $this->from = " FROM {$from}";
  }

  /**
   * @param string $table
   * 테이블명
   * @param string $condition
   * 조건절
   * @param string $type
   * left|right 등
   *
   * @return void
   */
  public function join($table, $condition, $type='')
  {
    $sql = '';
    if ($type) {
      $sql = " {$type}";
    }
    $this->join = $sql .= " JOIN {$table} ON {$condition}";

  }

  /**
   * @param string $column
   * 컬럼명
   * @param string $paramKey
   * 파리미터 키
   * @param string $oprator
   * 조건절
   * @param boolean $setParam
   * 파라미터 세팅( 삭제예정 )
   *
   *
   * @return void
   */
  public function where($column='', $paramKey='', $operator='=', $setParam = true)
  {
    $shortColumn = "";
    if ( strpos( $column, '.' ) ) {
        $shortColumn = explode('.', $column)[1];
    } else {
        $shortColumn = $column;
    }
    if ( is_null($this->where) )
    {
      $this->where = " WHERE ";
    }
    else
    {
      $this->where .= " AND ";
    }
    if ( is_null($paramKey) ) {
      $this->where .= "{$column} {$operator} NULL";
    } else {
      $this->where .= "{$column} {$operator} :{$shortColumn}";
      $this->whereParam[$shortColumn] = $paramKey;
    }

  }

  /**
   * @param array $array
   * where 절을 배열로 전달
   *
   * @return void
   */
  public function whereArray($array)
  {
    foreach ($array as $key => $value) {
        $this->where($key, $value);
    }
  }

  /**
   * @param string $column
   * 컬럼명
   * @param array $array
   * 배열로 where in 구문 작성
   *
   * @return void
   */
  public function whereIn($column='', $array)
  {
    $whereArrayValue = "'";
    $whereArrayValue .= implode("', '", $array);
    $whereArrayValue .= "'";
    if ( is_null($this->where) )
    {
      $this->where = " WHERE {$column} IN ({$whereArrayValue})";
    }
    else
    {
      $this->where .= " AND {$column} IN ({$whereArrayValue})";
    }
  }

  /**
   * BETWEEN 구문 작성
   * @param string $column
   * 컬럼명
   * @param string $start
   * 시작값
   * @param string $end
   * 끝값
   *
   * @return void
   */
  public function between($column='', $start='', $end='')
  {
    # code...
    if ( is_null($this->where) )
    {
      $this->where = " WHERE {$column} $column {$start} BETWEEN {$end})";
    }
    else
    {
      $this->where .= " AND {$column} $column {$start} BETWEEN {$end})";
    }
  }

  /**
   * LIKE 구문 작성 (내부용)
   * @param string $column
   * 컬럼명
   * @param string $value
   * 값
   * @param string $andOr
   * 연결부호
   *
   * @return void
   */
  public function _like($column='', $value='', $andOr = 'AND', $like = 'LIKE')
  {
    $shortColumn = "";
    if ( strpos( $column, '.' ) ) {
        $shortColumn = explode('.', $column)[1];
    } else {
        $shortColumn = $column;
    }
    if ( is_null($this->where) )
    {
      $this->where = " WHERE {$column} {$LIKE} CONCAT(:$shortColumn, '%')";
    }
    else
    {
      $this->where .= " {$andOr} {$column} {$LIKE} CONCAT(:$shortColumn, '%')";
    }

    $this->whereParam[$shortColumn] = '%'.$value.'%';
  }

  /**
   * LIKE 구문 작성
   * @param string $column
   * 컬럼명
   * @param string $value
   * 값
   *
   * @return void
   */
  public function like($column='', $value='')
  {
    $shortColumn = "";
    if ( strpos( $column, '.' ) ) {
        $shortColumn = explode('.', $column)[1];
    } else {
        $shortColumn = $column;
    }
    if ( is_null($this->where) )
    {
      $this->where = " WHERE {$column} LIKE CONCAT(:$shortColumn, '%')";
    }
    else
    {
      $this->where .= " AND {$column} LIKE CONCAT(:$shortColumn, '%')";
    }

    $this->whereParam[$shortColumn] = '%'.$value.'%';
  }

  /**
   * @param array $data
   * 배열로 키:값 PDOprepare 구문 작성
   *
   * @return void
   */
  public function insert($data)
  {
    $columns = '';
    $columns = implode(', ', array_keys($data));
    $val = implode(', :', array_keys($data));
    $val = ":".$val."";

    if ( $columns == '0' ) {
      return false;
    }
    $sql = "INSERT INTO {$this->table} ({$columns}) VALUE ({$val})";

    $this->whereParam = array_merge( $this->whereParam, $data);

    $result = $this->run($sql);

    return $result;
  }

  /**
   * @param array $data
   * 배열로 키:값 PDOprepare 구문 작성
   *
   * @return void
   */
  public function insert_batch($data, $teamSeq, $seq = 'seq')
  {
    foreach ($data as $key => $value) {
      $value[$seq] = $teamSeq;
      $result = $this->insert( $value );

      if ( !$result ) {
        return false;
      }
    }
    return true;
  }

  /**
   * @param array $data
   * 교체될 배열 키:값
   * @param string $updatecolumn
   * 현재시간으로 작성될 컬럼명
   *
   * @return int
   */
  public function update($data, $updateColumn = 'mod_date')
  {
    $columns = implode(', ', array_keys($data));
    $val = implode(', :', array_keys($data));
    $val = ":".$val."";

    $out = array();
    $extra = ' ';
    foreach ($data as $key => $value) {
        if ( strpos( $value, '+' ) > -1 ) {
            if ( count($out) ) {
                $extra .= ",";
            }
            $extra .= "{$key} = {$value}";
            unset($data[$key]);
        } else {
          array_push($out, "{$key} = :{$key}");
        }
    }
    $keyVal = implode(", ", $out);
    $keyVal .= $extra;

    $keyVal .= $updateColumn == null ? "" : ", {$updateColumn} = now()" ;

    $sql = "UPDATE {$this->table} SET {$keyVal}";

    if ($this->where !== null) {
      $sql .= $this->where;
    }

    $this->whereParam = array_merge( $this->whereParam, $data);

    $result = $this->run($sql);
    return $result;
  }

  /**
   * @param boolean $hard
   * true 일 경우 진짜 삭제
   *
   * @return int
   */
  public function delete($hard=false)
  {
    if ( is_null($this->where) ) {
        return false;
    if ( $hard )
        $sql = "DELETE FROM {$this->table}";
    } else {
        $keyVal = "del_date = now()";
        $sql = "UPDATE {$this->table} SET {$keyVal}";
    }
    $sql .= $this->where;
    $data = $this->whereParam;
    $result = $this->run($sql);

    return $result;
  }

  /**
   * @param string $orderby
   * 정렬 컬럼
   * @param string $direction
   * 정렬순서
   *
   * @return void
   */
  public function orderby($orderby, $direction = 'ASC')
  {
    if ( is_null($this->orderby) )
    {
      $this->orderby = " ORDER BY {$orderby} {$direction}";
    }
    else
    {
      $this->orderby .= " , {$orderby} {$direction}";
    }
    // $this->orderby = $orderby;
  }

  /**
   * @param int $limit
   * limit 제한 개수
   * @param int $offset
   * 건너뛸 offset 값
   *
   * @return void
   */
  public function limit($limit, $offset=0)
  {
    if ( $offset == 0 )
    {
      $this->limit = " LIMIT {$limit}";
    }
    else
    {
      $this->limit = " LIMIT {$offset}, {$limit}";
    }
  }

  /**
   * query 문 바로 실행
   * @param string $query
   * 쿼리문
   *
   * @return array
   */
  public function query($query='')
  {
    $return = $this->run($query);
    return $result;
  }

  /**
   * PDO 종료
   * @param
   *
   * @return void
   */
  public function close()
  {
    $this->init();
    $this->pdo = null;
    $this->from = null;
    $this->table = null;
    $this->join = null;
    $this->where = null;
    $this->whereIn = null;
    $this->orderby = null;
    $this->limit = null;
    $this->whereParam = array();
  }

  /**
   *  Returns the last inserted id.
   *  @return string
   */
  public function lastInsertId()
  {
      return $this->pdo->lastInsertId();
  }

  /**
   * Starts the transaction
   * @return boolean, true on success or false on failure
   */
  public function beginTransaction()
  {
      return $this->pdo->beginTransaction();
  }

  /**
   *  Execute Transaction
   *  @return boolean, true on success or false on failure
   */
  public function executeTransaction()
  {
      return $this->pdo->commit();
  }

  /**
   *  Rollback of Transaction
   *  @return boolean, true on success or false on failure
   */
  public function rollBack()
  {
      return $this->pdo->rollBack();
  }

  /**
   * 객체 초기화
   * @param
   *
   * @return void
   */
  public function init()
  {
    $this->mode = null;
    $this->select = null;
    $this->join = null;
    $this->where = null;
    $this->orderby = null;
    $this->whereParam = array();
  }

  /**
   * 에러로그를 위한 내장함수
   * @param string $message
   * @param string $sql
   *
   * @return void
   */
  private function exceptionLog($message, $sql = "")
  {
    $exception = 'Unhandled Exception. <br />';
    $exception .= $message;
    $exception .= "<br /> You can find the error back in the log.";

    if (!empty($sql)) {
        # Add the Raw SQL to the Log
        $message .= "\r\nRaw SQL : " . $sql;
    }
    # Write into log
    $this->log->write($message);

    return $exception;
  }

}
