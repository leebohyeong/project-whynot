;<?php return;?>
; DEV 환경입니다. 
[SITE]
SITE_NAME       = "SK 이노베이션"
OG_KEYWORDS     = "SK 이노베이션"
OG_TITLE        = "[SK 이노베이션]"
OG_DESCRIPTION  = "설명문구"
OG_IMAGE        = "/assets/images/logo.png"

[DOMAIN]
HOST_HTTP       = "http://skino.dbroscreative.com"
HOST_SSL        = "https://skino.dbroscreative.com"
HOST_HTTP_M     = "http://skino.dbroscreative.com/m"

[DB]
DB_HOST         = "119.207.79.184"
DB_USER         = "sk_innovation"
DB_PASSWORD     = "dlqlwmWkd1!"
DB_NAME         = "SK_INNOVATION"
DB_ENCODING     = "utf8"

[API]
API_FACEBOOK    = ""
API_DAUM        = ""
API_KAKAO       = ""
