<?php
/* ==============================================================================
'   작 성 자 : DEV GROUP - MOJITO
'   날    짜 : 2017-04-10
'   용    도 : config
'   Copyright 2017, Group IDD. All rights are reserved
' ================================================================================= */
use \Groupidd\Common\Setting;
use \Groupidd\Common\CommonFunc;
use \Groupidd\Library\Mobile_Detect;

header('Content-Type:text/html; charset=UTF-8');
header('Cache-control:no-cache');
header('Pragma:no-cache');

ini_set('error_reporting', E_ALL | E_STRICT);
ini_set('display_errors', 'Off');
ini_set('log_errors', 'On');
ini_set('error_log', '/home/ebizdev/summer.dbroscreative.com/logs/error_log');

session_start();

global $SITE_NAME_;
global $HOST_HTTP_, $HOST_SSL_, $HOST_HTTP_M_;
global $DB_HOST_, $DB_USER_, $DB_PASSWORD_, $DB_NAME_, $DB_ENCODING_;
global $OG_KEYWORDS_, $OG_TITLE_, $OG_DESCRIPTION_, $OG_IMAGE_, $OG_URL_;
global $API_FACEBOOK_, $API_DAUM_, $API_KAKAO_;
global $ADMIN_ID_, $ADMIN_NM_, $ADMIN_LV_, $USER_IP_;
global $ROOT_PATH_, $PHP_SELF_, $REQUEST_URI_, $ARR_REQUEST_URI_, $DATE_;

// property setting
$setting            = Setting::getInstance('dev');     // 개발환경:dev, 운영환경 : real
$SITE_NAME_         = $setting->SITE['SITE_NAME'];

$HOST_HTTP_         = $setting->DOMAIN['HOST_HTTP'];
$HOST_SSL_          = $setting->DOMAIN['HOST_SSL'];
$HOST_HTTP_M_       = $setting->DOMAIN['HOST_HTTP_M'];

$DB_HOST_           = $setting->DB['DB_HOST'];
$DB_USER_           = $setting->DB['DB_USER'];
$DB_PASSWORD_       = $setting->DB['DB_PASSWORD'];
$DB_NAME_           = $setting->DB['DB_NAME'];
$DB_ENCODING_       = $setting->DB['DB_ENCODING'];

$OG_KEYWORDS_       = $setting->SITE['OG_KEYWORDS'];
$OG_TITLE_          = $setting->SITE['OG_KEYWORDS'];
$OG_DESCRIPTION_    = $setting->SITE['OG_DESCRIPTION'];
$OG_IMAGE_          = $HOST_HTTP_ . $setting->SITE['OG_IMAGE'];
$OG_URL_            = $HOST_HTTP_;

$API_FACEBOOK_      = $setting->API['API_FACEBOOK'];
$API_DAUM_          = $setting->API['API_DAUM'];
$API_KAKAO_         = $setting->API['API_KAKAO'];

// basic path
$ROOT_PATH_         = $_SERVER['DOCUMENT_ROOT'];

// session & userip
$ADMIN_ID_		    = isset($_SESSION['ADMIN_ID']) ? $_SESSION['ADMIN_ID'] : '';
$ADMIN_NM_		    = isset($_SESSION['ADMIN_NM']) ? $_SESSION['ADMIN_NM'] : '';
$ADMIN_LV_		    = isset($_SESSION['ADMIN_LV']) ? $_SESSION['ADMIN_LV'] : '';
$USER_IP_           = $_SERVER['REMOTE_ADDR'];

// folder path
$PHP_SELF_          = $_SERVER['PHP_SELF'];
$REQUEST_URI_       = $_SERVER['REQUEST_URI'];
$ARR_REQUEST_URI_	= explode('/',$REQUEST_URI_);
array_shift($ARR_REQUEST_URI_);

$DATE_              = date('YmdH', time());


// 관리자 권한 체크(sitemanager 폴더내 login.php 제외하고 모두 강제로 로그인 체크하도록..)
if ($ARR_REQUEST_URI_[0] == 'sitemanager' && ($ARR_REQUEST_URI_[1] != 'login.php' && $ARR_REQUEST_URI_[1] != 'login-proc.php' && $ARR_REQUEST_URI_[1] != 'logout.php' && $ARR_REQUEST_URI_[1] != 'admin-pwd-proc.php')){
	if(empty($ADMIN_ID_)){
		CommonFunc::jsAlert('로그인 후 이용 가능합니다.','location.href=\'/sitemanager/login.php\'');
		exit();
	}
}

// 모바일로 url redirect
$mobile_detect = new Mobile_Detect;
$DEVICE_TYPE_ = "W";

if ($mobile_detect->isMobile() || $mobile_detect->isTablet()) {
	$DEVICE_TYPE_ = "M";
}

if ($DEVICE_TYPE_ == "M" && $ARR_REQUEST_URI_[0] != "sitemanager" && $ARR_REQUEST_URI_[0] != "m" ){	// sitemanager(어드민), 모바일 폴더 제외
	echo "<script>location.href='".$HOST_HTTP_M_.$REQUEST_URI_."';</script>";
	exit();
}


// include 정의 : S =========================================
//// require_once ROOT_PATH.'/src/function/common.php';          // 공통함수
// require_once ROOT_PATH.'/src/Class/PDO.class.php';          // DB access class
// require_once ROOT_PATH.'/src/Class/Query.class.php';        // Common class
// require_once ROOT_PATH.'/src/Library/Mobile_Detect.php';    // access device check
//// require_once ROOT_PATH.'/src/Library/Validator.php';    		// validation check

// require_once ROOT_PATH.'/src/include/device-check.php';     // 웹/모바일 체크
//// require_once ROOT_PATH.'/src/include/admin-check.php';      // 어드민 체크
// require_once ROOT_PATH.'/src/include/parameter-check.php';  // 파라미터 체크
// require_once ROOT_PATH.'/src/array/array-info.php';         // array config
// include 정의 : E =========================================
