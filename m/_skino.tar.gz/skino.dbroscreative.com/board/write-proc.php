<?php
/* ==============================================================================
'   작 성 자 : DEV GROUP - JUHYUN
'   날    짜 : 2017-05-08
'   용    도 : 프론트 > Q&A 게시물 쓰기 proc (write-proc.php)
'   Copyright 2017, Group IDD. All rights are reserved
' =============================================================================== */
require_once $_SERVER['DOCUMENT_ROOT']."/vendor/autoload.php";

use \Groupidd\Model\ModelBase;
use \Groupidd\Common\CommonFunc;
use \Groupidd\Library\Validator;

$boardInfo['title']         = isset($_POST['title']) ? $_POST['title'] : '';
$boardInfo['reg_name']      = isset($_POST['reg_name']) ? $_POST['reg_name'] : '';
$boardInfo['content']       = isset($_POST['content']) ? $_POST['content'] : '';
$boardInfo['board_type']    = 'qna';

//validation 검사
$validator = new Validator($boardInfo);
$validator->rule('required', 'title')->message('제목은 필수 입력값입니다.');
$validator->rule('required', 'reg_name')->message('작성자는 필수 입력값입니다.');
$validator->rule('required', 'content')->message('내용은 필수 입력값입니다.');

$db = new ModelBase();

if($validator->validate()) {       		// validation 성공
    $boardInfo = $validator->data(); 	//데이터 받아오기
    $boardInfo['reg_date']  = date('Y-m-d H:i:s');      // 게시물 등록일
	// database 처리
	$db->from('BOARD');
	if ( $db->insert($boardInfo) ) {
		$resultData['result'] = true;
        $resultData['msg'] = '등록 되었습니다.';
	} else {
		$resultData['result'] = false;
        $resultData['msg'] = '게시물 저장에 실패했습니다.';
	}
} else {        // validation 실패
	$resultData['result'] = false;
    $resultData['msg'] = '누락된 데이터가 있습니다.';
}
$db->close();

echo json_encode($resultData);
exit;
