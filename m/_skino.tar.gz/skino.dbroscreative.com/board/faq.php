<?php
/* =============================================================================
'   작 성 자 : DEV GROUP - JUHYUN
'   날    짜 : 2017-05-08
'   용    도 : 프론트 > faq 게시판 리스트 (faq.php)
'   Copyright 2017, Group IDD. All rights are reserved
' =============================================================================*/
require_once $_SERVER['DOCUMENT_ROOT']."/vendor/autoload.php";
?>
<!DOCTYPE html>
<html lang="ko">
<head>
    <?php require_once $ROOT_PATH_.'/assets/include/head.php'; ?>
</head>
<body id="board-faq">
<article class="global-wrap">
    <?php require_once $ROOT_PATH_.'/assets/include/gnb.php'; ?>
    <div class="global-container">
        <div class="global-content">
            <?php require_once $ROOT_PATH_.'/assets/include/gnb-board.php'; ?>
            <section class="faq-list">
                <dl>
                    <dt class="title">
                        <a href="#">
                            <span>Q.</span>
                            제목 테스트입니다.
                        </a>
                    </dt>
                    <dd class="cont">
                        <span>A.</span>
                        <P>컨텐츠 내용입니다.</P>
                    </dd>
                    <dt class="title">
                        <a href="#">
                            <span>Q.</span>
                            제목 테스트입니다.
                        </a>
                    </dt>
                    <dd class="cont">
                        <span>A.</span>
                        <P>컨텐츠 내용입니다.</P>
                    </dd>
                    <dt class="title">
                        <a href="#">
                            <span>Q.</span>
                            제목 테스트입니다.
                        </a>
                    </dt>
                    <dd class="cont">
                        <span>A.</span>
                        <P>컨텐츠 내용입니다.</P>
                    </dd>
                    <dt class="title">
                        <a href="#">
                            <span>Q.</span>
                            제목 테스트입니다.
                        </a>
                    </dt>
                    <dd class="cont">
                        <span>A.</span>
                        <P>컨텐츠 내용입니다.</P>
                    </dd>
                </dl>
            </section>
        </div>
    </div>

    <footer class="global-footer">
        <p class="copyright">COPYRIGHT &copy;SKINNOVATION CO.,LTD ALL RIGHTS RESERVED.</p>
    </footer></article>
</body>
</html>
