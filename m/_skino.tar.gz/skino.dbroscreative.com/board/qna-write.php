<?php
/* ==============================================================================
'   작 성 자 : DEV GROUP - JUHYUN
'   날    짜 : 2017-05-08
'   용    도 : 프론트 > Q&A 게시물 쓰기 (write-qna.php)
'   Copyright 2017, Group IDD. All rights are reserved
' =============================================================================== */
require_once $_SERVER['DOCUMENT_ROOT']."/vendor/autoload.php";

use \Groupidd\Model\ModelBase;
use \Groupidd\Common\CommonFunc;
use \Groupidd\Library\Validator;

$pageNo     = isset($_GET['page']) && $_GET['page'] != '' ? $_GET['page'] : 1;

?>
<!DOCTYPE html>
<html lang="ko">
<head>
    <?php require_once $ROOT_PATH_.'/assets/include/head.php'; ?>
</head>
<body id="board-qna-write">
<article class="global-wrap">
    <?php require_once $ROOT_PATH_.'/assets/include/gnb.php'; ?>
    <div class="global-container">
        <div class="global-content">
            <?php require_once $ROOT_PATH_.'/assets/include/gnb-board.php'; ?>
            <form id="form_qna_write" method="post" action="write-proc.php">
            <div class="board-write">
                <dl class="list-write">
                    <dt>
                        <label for="title">제목</label>
                    </dt>
                    <dd>
                        <input type="text" name="title" value="" maxlength="50">
                    </dd>
                    <dt>
                        <label for="writer">작성자</label>
                    </dt>
                    <dd>
                        <input type="text" name="reg_name" value="" maxlength="10">
                    </dd>
                    <dt>
                        <label for="desc">문의 내용</label>
                    </dt>
                    <dd>
                        <textarea name="content" rows="15"></textarea>
                    </dd>
                </dl>
                <div class="board-bottom">
                    <p>
                        ※ 욕설이나 비방 등 게시판 성격에 맞지 않는 내용의 글은 관리자에 의해 임의로 삭제될 수 있습니다.<br>
                        ※ Q&amp;A 내용은 전체 공개 되며 작성자가 수정이나 삭제를 할 수 없습니다.
                    </p>
                    <div class="group-button">
                        <a href="javascript:;" class="btn"><img src="/assets/images/board/btn_board_cancel.png" alt="취소"></a>
                        <a href="jabascript:;" class="btn"><img src="/assets/images/board/btn_board_register.png" alt="등록"></a>
                    </div>
                </div>
            </div>
            </form>
        </div>
    </div>
    <?php require_once $ROOT_PATH_.'/assets/include/footer.php'; ?>
</article>

<script>
$(function() {

    var isValid = function () {
        if (!$.trim($('[name=title]').val())) {
            alert('제목을 입력해 주세요');
            $('[name=title]').focus();
            return false;
        }

        if (!$.trim($('[name=reg_name]').val())) {
            alert('작성자를 입력해 주세요');
            $('[name=reg_name]').focus();
            return false;
        }

        if (!$.trim($('[name=content]').val())) {
            alert('내용을 입력해 주세요');
            $('[name=content]').focus();
            return false;
        }
        return true;
    }

    $('.group-button a:first').on('click', function () {
        if(confirm('글 작성을 취소하시겠습니까?')) {
            location.href = "qna-list.php?page=<?=$pageNo?>";
        }
        return;
    })

    // 폼 등록
    $('.group-button a:last').on('click', function () {
        var form = $('#form_qna_write');
        if (isValid()) {
            if (confirm('등록 하시겠습니까?')){
                $.ajax({
                    async: false,
                    type: form.attr('method'),
                    url: form.attr('action'),
                    dataType: "json",
                    data:  form.serialize(),
                    success: function (res) {
                        // 성공시
                        alert( res.msg );
                        if(res.result){
                            window.location = '/board/qna-list.php';
                        }
                    },
                    error: function (jqXHR, textStatus, errorThrown) {
                        console.log('Q&A 글 작성 폼 전송 에러');
                    }
                });
            }
        }
        return false;
    })
})

</script>

</body>
</html>
