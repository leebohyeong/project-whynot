<?php
/* =============================================================================
'   작 성 자 : DEV GROUP - JUHYUN
'   날    짜 : 2017-05-08
'   용    도 : 프론트 > Q&A 게시판 리스트 (list-qna.php)
'   Copyright 2017, Group IDD. All rights are reserved
' =============================================================================*/
require_once $_SERVER['DOCUMENT_ROOT']."/vendor/autoload.php";

use \Groupidd\Model\ModelBase;
use \Groupidd\Common\CommonFunc;
use \Groupidd\Library\Validator;

$pageNo             = isset($_GET['page']) && $_GET['page'] != '' ? $_GET['page'] : 1;
$searchType         = isset($_GET['search_type']) ? $_GET['search_type'] : 'title';
$searchInfo['text'] = isset($_GET['search_text']) ? $_GET['search_text'] : '';

$db = new ModelBase();

if ( $searchInfo['text'] != '' ) {
    $validator = new Validator($searchInfo);
    $validator->rule('required', 'text');
    if($validator->validate()) {       		// validation 성공
        $searchInfo = $validator->data();
        $searchType = $searchType == 'title' ? 'title' : 'reg_name';
        $db->like($searchType, $searchInfo['text']);
    }
}

$db->from('BOARD');
$db->where('board_type', 'qna');
$db->where('del_date', NULL, 'IS');

$countList = $db->getCountAll();    // 전체 게시물 수
$db->init();

// paging
$perPage = 7;      // 한 페이지에 보여질 리스트 수
$pageSize	= intval($countList/$perPage);
if($pageSize * $perPage != $countList) $pageSize = $pageSize+1;
$currentPage = $pageNo == 1 ? 0 : ($pageNo*$perPage)-$perPage;

if ( $searchInfo['text'] != '' ) {
    $searchInfo['type'] = str_replace('search_', '', $searchInfo['type']);
    $searchType = $searchType == 'title' ? 'title' : 'reg_name';
    $db->like($searchType, $searchInfo['text']);
}

$db->select('seq, title, reg_name, comment, reg_date');
$db->from('BOARD');
$db->where('board_type', 'qna');
$db->where('del_date', NULL, 'IS');
$db->orderby('seq', 'DESC');
$db->limit($perPage, $currentPage );
$boardList = $db->getAll();
$db->close();
?>
<!DOCTYPE html>
<html lang="ko">
<head>
    <?php require_once $ROOT_PATH_.'/assets/include/head.php'; ?>
</head>
<body id="board-qna-list">
<article class="global-wrap">
    <?php require_once $ROOT_PATH_.'/assets/include/gnb.php'; ?>
    <div class="global-container">
        <div class="global-content">
            <?php require_once $ROOT_PATH_.'/assets/include/gnb-board.php'; ?>
            <section class="board-list">
                <form action="" class="form-board">
                    <input type="hidden" name="board_type" value="qna">
                    <div class="option">
                        <div class="option-select">
                            <select class="select" name="search_type">
                                <option value="title" <?=CommonFunc::getSelected($searchType, 'title')?>>Title</option>
                                <option value="reg_name" <?=CommonFunc::getSelected($searchType, 'reg_name')?>>Writer</option>
                            </select>
                        </div>
                        <div class="option-search">
                            <input type="text" name="search_text" placeholder="Search" value="<?=$searchInfo['text']?>">
                            <button type="submit">검색</button>
                        </div>
                    </div>
                </form>
                <table class="table">
            	    <caption>Q&amp;A 리스트</caption>
            		<tbody>
                        <?php
                        foreach($boardList as $row) {
                        ?>
                        <tr>
                            <td class="date">
                                <small><?=substr($row['reg_date'], 0, 4)?></small>
                                <span><?=number_format(substr($row['reg_date'], 5, 2)).'.'.substr($row['reg_date'], 8, 2)?></span>
                            </td>
                            <td class="content">
                                <a href="/board/qna-view.php?page=<?=$pageNo?>&seq=<?=$row['seq']?>&search_type=<?=$searchType?>&search_text=<?=$searchInfo['text']?>" class="link">
                                    <strong><?=CommonFunc::cutUtf8Str($row['title'], 60, '...')?></strong>
                                    <p><?=$row['reg_name']?></p>
                                </a>
                            </td>
                            <td class="state">
                                <span><?=$row['comment'] ==  null ? '대기중' : '답변완료'?></span>
                            </td>
                        </tr>
                        <?php
                        }
                        ?>
                    </tbody>
                </table>
            </section>
            <div class="board-bottom">
            <?=CommonFunc::getPaging($pageNo, $perPage, $pageSize, '&search_type='.$searchType.'&search_text='.$searchInfo['text'])?>
            <a href="/board/qna-write.php" class="btn-write"><img src="/assets/images/board/btn_board_write.png" alt="질문 작성"></a>
            </div>
        </div>
    </div>
    <?php require_once $ROOT_PATH_.'/assets/include/footer.php'; ?>
</article>
<script>
$(function() {
    // 검색
    $('.option-search button').on('click', function() {
        if(!$.trim($('[name=search_text]').val())) {
            alert('검색어를 입력해 주세요.');
            $('[name=search_text]').focus();
            return false;
        }
    });
})
</script>
</body>
</html>
