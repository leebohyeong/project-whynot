<?php
/* =============================================================================
'   작 성 자 : DEV GROUP - JUHYUN
'   날    짜 : 2017-05-08
'   용    도 : 프론트 > 공지사항 게시판 리스트 (list-notice.php)
'   Copyright 2017, Group IDD. All rights are reserved
' =============================================================================*/
require_once $_SERVER['DOCUMENT_ROOT']."/vendor/autoload.php";

use \Groupidd\Model\ModelBase;
use \Groupidd\Common\CommonFunc;
use \Groupidd\Library\Validator;

$pageNo             = isset($_GET['page']) && $_GET['page'] != '' ? $_GET['page'] : 1;

$searchType         = isset($_GET['search_type']) ? $_GET['search_type'] : 'title';
$searchInfo['text'] = isset($_GET['search_text']) ? $_GET['search_text'] : '';

$db = new ModelBase();

if ( $searchInfo['text'] != '' ) {
    $validator = new Validator($searchInfo);
    $validator->rule('required', 'text');
    if($validator->validate()) {       		// validation 성공
        $searchInfo = $validator->data();
        $searchType = $searchType == 'title' ? 'title' : 'reg_name';
        $db->like($searchType, $searchInfo['text']);
    } else {
        CommonFunc::jsAlert('검색 내용이 없습니다.', 'location.href="/board/notice-list.php";');
        exit();
    }
}

$db->from('BOARD');
$db->where('board_type', 'notice');
$db->where('del_date', NULL, 'IS');

$countList = $db->getCountAll();    // 전체 게시물 수
$db->init();

// 상단 노출 게시물
$db->select('seq, title, content, reg_name, comment, reg_date');
$db->where('board_type', 'notice');
$db->where('del_date', NULL, 'IS');
$db->where('top_YN', 'Y');
$db->orderby('seq');
$topBoardList = $db->getAll();    // 상단 노출 게시물 수
$db->init();

// paging
$perPage = 7-count($topBoardList);      // 한 페이지에 보여질 리스트 수
$pageSize	= intval($countList/$perPage);
if($pageSize * $perPage != $countList) $pageSize = $pageSize+1;
$currentPage = $pageNo == 1 ? 0 : ($pageNo*$perPage)-$perPage;

if ( $searchInfo['text'] != '' ) {
    $searchInfo['type'] = str_replace('search_', '', $searchInfo['type']);
    $searchType = $searchInfo['type'] == 'title' ? 'title' : 'reg_name';
    $db->like($searchType, $searchInfo['text']);
}

$db->select('seq, title, content, reg_name, comment, reg_date');
$db->from('BOARD');
$db->where('board_type', 'notice');
$db->where('del_date', NULL, 'IS');
$db->where('top_YN', 'N');
$db->orderby('seq', 'DESC');
$db->limit($perPage, $currentPage );
$boardList = $db->getAll();
$db->close();
?>
<!DOCTYPE html>
<html lang="ko">
<head>
    <?php require_once $ROOT_PATH_.'/assets/include/head.php'; ?>
</head>
<body id="board-notice-list">
<article class="global-wrap">
    <?php require_once $ROOT_PATH_.'/assets/include/gnb.php'; ?>
    <div class="global-container">
        <div class="global-content">
            <?php require_once $ROOT_PATH_.'/assets/include/gnb-board.php'; ?>
            <section class="board-list">
                <table class="table">
                    <caption>공지사항 리스트</caption>
                    <tbody>
                        <?php
                        foreach($topBoardList as $row) {
                        ?>
                        <tr>
                            <td class="date">
                                <small><?=substr($row['reg_date'], 0, 4)?></small>
                                <span><?=number_format(substr($row['reg_date'], 5, 2)).'.'.substr($row['reg_date'], 8, 2)?></span>
                            </td>
                            <td class="content">
                                <a href="/board/notice-view.php?page=<?=$pageNo?>&seq=<?=$row['seq']?>". class="link">
                                    <strong><?=CommonFunc::cutUtf8Str($row['title'], 60, '...')?></strong>
                                    <p><?=CommonFunc::cutUtf8Str($row['content'], 60, '...')?></p>
                                </a>
                            </td>
                        </tr>
                        <?php
                        }
                        foreach($boardList as $row) {
                        ?>
                        <tr>
                            <td class="date">
                                <small><?=substr($row['reg_date'], 0, 4)?></small>
                                <span><?=number_format(substr($row['reg_date'], 5, 2)).'.'.substr($row['reg_date'], 8, 2)?></span>
                            </td>
                            <td class="content">
                                <a href="/board/notice-view.php?page=<?=$pageNo?>&seq=<?=$row['seq']?>". class="link">
                                    <strong><?=CommonFunc::cutUtf8Str($row['title'], 60, '...')?></strong>
                                    <p><?=CommonFunc::cutUtf8Str($row['content'], 120, '...')?></p>
                                </a>
                            </td>
                        </tr>
                        <?php
                        }
                        ?>
                    </tbody>
                </table>
            </section>
            <div class="board-bottom">
            <?=CommonFunc::getPaging($pageNo, $perPage, $pageSize, '&search_type='.$searchType.'&search_text='.$searchInfo['text'])?>
            </div>
        </div>
    </div>
    <?php require_once $ROOT_PATH_.'/assets/include/footer.php'; ?>
</article>
<script>
$(function() {
    // 검색
    $('.option-search button').on('submit', function() {
        if(!$.trim($('[name=search_text]').val())) {
            alert('검색어를 입력해 주세요.');
            $('[name=search_text]').focus();
            return false;
        }
    });
})
</script>
</body>
</html>
