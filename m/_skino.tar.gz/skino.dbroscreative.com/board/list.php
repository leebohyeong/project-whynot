<?php
/* ==============================================================================
'   작 성 자 : DEV GROUP - JUHYUN
'   날    짜 : 2017-05-08
'   용    도 : 프론트 > 게시판 (list.php)
'   Copyright 2017, Group IDD. All rights are reserved
' ================================================================================= */
require_once $_SERVER['DOCUMENT_ROOT']."/vendor/autoload.php";

use \Groupidd\Model\ModelBase;
use \Groupidd\Common\CommonFunc;
use \Groupidd\Library\Validator;

$pageNo     = isset($_GET['page']) && $_GET['page'] != '' ? $_GET['page'] : 1;
$boardType  = isset($_GET['board_type']) ? $_GET['board_type'] : '';

$searchInfo['type'] = isset($_GET['search_type']) ? $_GET['search_type'] : '';
$searchInfo['text'] = isset($_GET['search_text']) ? $_GET['search_text'] : '';

$BOARD_TYPE_        = array('notice', 'qna', 'event');

if ( !in_array($boardType, $BOARD_TYPE_) ) {
    CommonFunc::jsAlert('게시판 타입이 잘못되었습니다.', 'location.href="list.php?board_type=notice";');
    exit();
}

$db = new ModelBase();

if ( $searchInfo['text'] != '' ) {
    $validator = new Validator($searchInfo);
    $validator->rule('required', 'text');
    if($validator->validate()) {       		// validation 성공
        $searchInfo = $validator->data();
        $searchInfo['type'] = str_replace('search_', '', $searchInfo['type']);
        $db->like($searchInfo['type'], $searchInfo['text']);
    }
}

$db->from('BOARD');
$db->where('board_type', $boardType);
$db->where('del_date', NULL, 'IS');

$countList = $db->getCountAll();    // 전체 게시물 수
$db->init();

// paging
$perPage = 5;      // 한 페이지에 보여질 리스트 수
$pageSize	= intval($countList/$perPage);
if($pageSize * $perPage != $countList) $pageSize = $pageSize+1;
$currentPage = $pageNo == 1 ? 0 : ($pageNo*$perPage)-$perPage;





if ( $searchInfo['text'] != '' ) {
    $searchInfo['type'] = str_replace('search_', '', $searchInfo['type']);
    $searchType = $searchInfo['type'] == 'search_title' ? 'title' : '';
    $db->like($searchType, $searchInfo['text']);
}

$db->select('seq, title, reg_name, comment, reg_date');
$db->from('BOARD');
$db->where('board_type', $boardType);
$db->where('del_date', NULL, 'IS');
$db->orderby('seq', 'DESC');
$db->limit($perPage, $currentPage );
$boardLists = $db->getAll();
$db->init();
?>
<!DOCTYPE html>
<html lang="ko">
<head>
    <?php require_once $ROOT_PATH_.'/assets/include/head.php'; ?>
</head>
<body id="board-<?=$boardType?>-list">
<article class="global-wrap">
    <?php require_once $ROOT_PATH_.'/assets/include/gnb.php'; ?>
    <div class="global-container">
        <div class="global-content">
            <?php require_once $ROOT_PATH_.'/assets/include/gnb-board.php'; ?>
            <?php require_once $ROOT_PATH_.'/board/list-'.$boardType.'.php'; ?>
            <div class="board-bottom">
            <?=CommonFunc::getPaging($pageNo, $perPage, $pageSize, '&search_type='.$searchInfo['type'].'&search_text='.$searchInfo['text'].'&board_type='.$boardType)?>
            <?php
            if ( $boardType == 'qna' ) {
            ?>
            <a href="write-qna.php?board_type=qna" class="btn-write"><img src="/assets/images/board/btn_board_write.png" alt="질문 작성"></a>
            <?php
            }
            ?>
            </div>
        </div>
    </div>
    <?php require_once $ROOT_PATH_.'/assets/include/footer.php'; ?>
</article>
<script>
$(function() {
    // 검색
    $('.option-search button').on('submit', function() {
        if(!$.trim($('[name=search_text]').val())) {
            alert('검색어를 입력해 주세요.');
            $('[name=search_text]').focus();
            return false;
        }
    });
})
</script>
</body>
</html>
