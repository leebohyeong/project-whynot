<?php
/* ==============================================================================
'   작 성 자 : DEV GROUP - JUHYUN
'   날    짜 : 2017-05-08
'   용    도 : 프론트 > 게시판 (view.php)
'   Copyright 2017, Group IDD. All rights are reserved
' ================================================================================= */
require_once $_SERVER['DOCUMENT_ROOT']."/vendor/autoload.php";

use \Groupidd\Model\ModelBase;
use \Groupidd\Common\CommonFunc;
use \Groupidd\Library\Validator;

$pageNo     = isset($_GET['page']) && $_GET['page'] != '' ? $_GET['page'] : 1;
$boardType  = isset($_GET['board_type']) ? $_GET['board_type'] : '';
$seq        = isset($_GET['seq']) ? $_GET['seq'] : '';

if( !$seq ) {
    CommonFunc::jsAlert('잘못된 접근입니다.','location.href="/board/list.php?board_type='.$boardType.'";');
    exit();
}

$db = new ModelBase();
$db->select('seq, title, content, comment, reg_name, reg_date, del_date');
$db->from('BOARD');
$db->where('seq', $seq);
$db->where('del_date', NULL, 'IS');
$boardData = $db->getOne();
$db->init();

if( empty($boardData) ) {
    CommonFunc::jsAlert('게시물이 존재하지 않습니다.','location.href="/board/list.php?board_type='.$boardType.'";');
    exit();
}

// 이전글, 다음글
$db->select('seq');
$db->from('BOARD');
$db->where('seq', $seq, '<');
$db->where('del_date', NULL, 'IS');
$db->where('board_type', $boardType);
$db->orderby('seq', 'DESC');
$db->limit(1);
$prevSeq = $db->getOne();
$db->init();

$db->select('seq');
$db->from('BOARD');
$db->where('seq', $seq, '>');
$db->where('del_date', NULL, 'IS');
$db->where('board_type', $boardType);
$db->orderby('seq');
$db->limit(1);
$nextSeq = $db->getOne();
$db->init();

$boardInfo['view_count'] = 'view_count + 1';
$db->from('BOARD');
$db->where('seq', $seq);
$db->update($boardInfo, null);
$db->close();

?>
<!DOCTYPE html>
<html lang="ko">
<head>
    <?php require_once $ROOT_PATH_.'/assets/include/head.php'; ?>
</head>
<body id="board-<?=$boardType?>-view">
<article class="global-wrap">
    <?php require_once $ROOT_PATH_.'/assets/include/gnb.php'; ?>
    <div class="global-container">
        <div class="global-content">
            <?php require_once $ROOT_PATH_.'/assets/include/gnb-board.php'; ?>
            <?php require_once $ROOT_PATH_.'/board/view-'.$boardType.'.php'; ?>
            <div class="board-bottom">
                <nav class="page-control">
                    <?php
                    if( empty($prevSeq) ) {
                        echo '<a href="javascript:;" onclick="alert(\'처음 글입니다.\');" class="prev">이전 글</a>';
                    } else {
                    ?>
                    <a href="view.php?board_type=<?=$boardType?>&seq=<?=$prevSeq['seq']?>" class="prev">이전 글</a>
                    <?php
                    }
                    if( empty($nextSeq) ) {
                        echo '<a href="javascript:;" onclick="alert(\'마지막 글입니다.\');" class="next">다음 글</a>';
                    } else {
                    ?>
                    <a href="view.php?board_type=<?=$boardType?>&seq=<?=$nextSeq['seq']?>" class="next">다음 글</a>
                    <?php
                    }
                    ?>
                </nav>
                <a href="list.php?board_type=<?=$boardType?>&page=<?=$pageNo?>" class="btn-list"><img src="/assets/images/board/btn_board_list.gif" alt="목록가기"></a>
            </div>
        </div>
    </div>
    <?php require_once $ROOT_PATH_.'/assets/include/footer.php'; ?>
</body>
</html>
