<meta charset="UTF-8">
<meta http-equiv="X-UA-Compatible" content="ie=edge">
<title>SK innovation</title>
<meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1, user-scalable=no">
<meta name="author" content="GROUP IDD">
<meta name="description" content="">
<meta name="keywords" content="">

<meta name="format-detection" content="telephone=no">
<meta name="format-detection" content="address=no">

<meta name="author" content="SK innovation">
<meta property="fb:app_id" content="">
<meta property="og:url" content="https://">
<meta property="og:type" content="website">
<meta property="og:title" content="">
<meta property="og:image" content="https://">
<meta property="og:description" content="">
<meta property="og:site_name" content="">
<meta property="article:author" content="">

<link rel="shortcut icon" type="image/x-icon" href=".ico">

<link rel="stylesheet" href="/assets/css/app.css">

<script src="/assets/js/app.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
