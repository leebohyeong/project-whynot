<footer class="global-footer">
    <p class="copyright">COPYRIGHT &copy;SKINNOVATION CO.,LTD ALL RIGHTS RESERVED.</p>
</footer>
