<header class="global-header">
    <div class="global-header-inner">
        <h1 class="logo">
            <a href="/">
                <span class="sr-only">SK innovation</span>
            </a>
        </h1>

        <button type="button" class="gnb-menu">
            <span class="sr-only">메뉴</span>
        </button>
    </div>
</header>

<nav class="global-navigation">
    <div class="inner">
        <ul>
            <li class="gnb-about">
                <div class="main">
                    <a href="/about/application.php">
                        <span>
                            About the Contest
                        </span>
                    </a>
                </div>

                <div class="sub">
                    <ul>
                        <li>
                            <a href="#">
                                모집요강
                            </a>
                        </li>
                        <li>
                            <a href="#">
                                심사 및 시상안내
                            </a>
                        </li>
                    </ul>
                </div>
            </li>
            <li class="gnb-receipt">
                <div class="main">
                    <a href="#">
                        <span>
                            작품접수
                        </span>
                    </a>
                </div>

                <div class="sub">
                    <ul>
                        <li>
                            <a href="#">
                                작품접수
                            </a>
                        </li>
                        <li>
                            <a href="#">
                                파일제출
                            </a>
                        </li>
                        <li>
                            <a href="#">
                                접수확인
                            </a>
                        </li>
                    </ul>
                </div>
            </li>
            <li class="gnb-awards">
                <div class="main">
                    <a href="#">
                        <span>
                            Awards
                        </span>
                    </a>
                </div>

                <div class="sub">
                    <ul>
                        <li>
                            <a href="#">
                                본선 진출팀 소개
                            </a>
                        </li>
                        <li>
                            <a href="#">
                                본선 투표
                            </a>
                        </li>
                    </ul>
                </div>
            </li>
            <li class="gnb-board">
                <div class="main">
                    <a href="/board/notice-list.php">
                        <span>
                            Board
                        </span>
                    </a>
                </div>

                <div class="sub">
                    <ul>
                        <li>
                            <a href="/board/notice-list.php">
                                공지사항
                            </a>
                        </li>
                        <li>
                            <a href="/board/faq.php">
                                FAQ
                            </a>
                        </li>
                        <li>
                            <a href="/board/qna-list.php">
                                Q&amp;A
                            </a>
                        </li>
                    </ul>
                </div>
            </li>
            <li class="gnb-event">
                <div class="main">
                    <a href="#">
                        <span>
                            Event
                        </span>
                    </a>
                </div>
            </li>
        </ul>
    </div>
</nav>
