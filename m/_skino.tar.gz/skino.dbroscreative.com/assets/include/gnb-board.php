<div class="content-header">
    <h2 class="title">
        <img src="/assets/images/board/h_board.png" alt="Board">
    </h2>
    <nav class="lnb">
        <ul>
            <li class="notice">
                <a href="/board/notice-list.php">
                    NOTICE
                </a>
            </li>
            <li class="faq">
                <a href="/board/faq.php">
                    FAQ
                </a>
            </li>
            <li class="qna">
                <a href="/board/qna-list.php">
                    Q&amp;A
                </a>
            </li>
        </ul>
    </nav>
</div>
